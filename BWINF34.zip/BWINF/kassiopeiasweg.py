#!/usr/bin/python
# -*- coding: <UTF-8> -*-
import pygame
import random
import os
import math
import sys
from pygame.locals import *
from pygame import *
from pygame import gfxdraw
from time import *
from decimal import *
"""def fobjs(pl,pml):
   for p in pl:
      p=pl[0]
      x=p[0]
      y=p[1]
      if pml.get_at((x+1,y))[0]==255:
         ap=True
         hgx=x+1
         hgy=y
         for obj in pl:
            if obj[0]==hgx and obj[1]==hgy:
               ap=False
         if ap==True:
            pl.append([x+1,y])
      if pml.get_at((x-1,y))[0]==255:
         ap=True
         hgx=x-1
         hgy=y
         for obj in pl:
            if obj[0]==hgx and obj[1]==hgy:
               ap=False
         if ap==True:
            pl.append([x-1,y])
      if pml.get_at((x,y+1))[0]==255:
         ap=True
         hgx=x
         hgy=y+1
         for obj in pl:
            if obj[0]==hgx and obj[1]==hgy:
               ap=False
         if ap==True:
            pl.append([x,y+1])
      if pml.get_at((x,y-1))[0]==255:
         ap=True
         hgx=x
         hgy=y-1
         for obj in pl:
            if obj[0]==hgx and obj[1]==hgy:
               ap=False
         if ap==True:
            pl.append([x,y-1])"""
def fobjs(pl,pml):
   True
def error():
   quadrate=[]
   pygame.init()
   dp = pygame.display.set_mode((1000, 1000),pygame.RESIZABLE)
   clock = pygame.time.Clock()
   pml=pygame.image.load("BWINF/kassiopeia.png")
   kap=pygame.image.load("BWINF/kassiopeias.png")
   gn=False
   gn2=False
   checksum=0
   pl=[]
   pli=True
   for x in range(pml.get_rect().width):
      for y in range(pml.get_rect().height):
         si=pml.get_at((x,y))
         if si[0]==255:
            checksum+=1
            if pli==True:
               pl.append([x,y])
               print "Point added"
               pli=False
         if si[1]==255 and si[2]==0:
            print "Kassiopeia"
            kp=(x,y)
   for p in pl:
      print p[0],",",p[1]
   print pl[0]
   gehstring=""
   for o in pl:
      p=o
      x=p[0]
      y=p[1]
      if pml.get_at((x+1,y))[0]==255:
         ap=True
         hgx=x+1
         hgy=y
         for obj in pl:
            if obj[0]==hgx and obj[1]==hgy:
               ap=False
         if ap==True:
            pl.append([x+1,y])
            fobjs(pl,pml)
      if pml.get_at((x-1,y))[0]==255:
         ap=True
         hgx=x-1
         hgy=y
         for obj in pl:
            if obj[0]==hgx and obj[1]==hgy:
               ap=False
         if ap==True:
            pl.append([x-1,y])
            fobjs(pl,pml)
      if pml.get_at((x,y+1))[0]==255:
         ap=True
         hgx=x
         hgy=y+1
         for obj in pl:
            if obj[0]==hgx and obj[1]==hgy:
               ap=False
         if ap==True:
            pl.append([x,y+1])
            fobjs(pl,pml)
      if pml.get_at((x,y-1))[0]==255:
         ap=True
         hgx=x
         hgy=y-1
         for obj in pl:
            if obj[0]==hgx and obj[1]==hgy:
               ap=False
         if ap==True:
            pl.append([x,y-1])
            fobjs(pl,pml)
   kc=0
   for p in pl:
      kc+=1
      #print p[0],",",p[1]
   print checksum
   if kc<=checksum-1:
      print "HAT LEIDER NICHT GEKLAPPT,KASSIOPEIA!"
   else:
      print "HAT GEKLAPPT,KASSIOPEIA!"
   go=True
   spl=[]
   while go==True:
      for e in pygame.event.get():
         if e.type==pygame.QUIT:
            pygame.quit()
         if e.type == pygame.KEYDOWN:
            if e.key == K_ESCAPE:
               pygame.quit()
            if e.key == K_DOWN:
               spl.append([kp[0],kp[1]])
               kp=(kp[0],kp[1]+1)
            if e.key == K_UP:
               kp=(kp[0],kp[1]-1)
               spl.append([kp[0],kp[1]])
            if e.key == K_RIGHT:
               spl.append([kp[0],kp[1]])
               kp=(kp[0]+1,kp[1])
            if e.key == K_LEFT:
               spl.append([kp[0],kp[1]])
               kp=(kp[0]-1,kp[1])
      dp.fill((0,255,0))
      dp.blit(pml,(0,0))
      #for p in pl:
      #   pygame.gfxdraw.pixel(dp,p[0],p[1],(255,0,0))
      pl=[[kp[0],kp[1]]]
      try:
         for o in pl:
            p=o
            x=p[0]
            y=p[1]
            if pml.get_at((x+1,y))[0]==255:
               ap=True
               hgx=x+1
               hgy=y
               for obj in pl:
                  if obj[0]==hgx and obj[1]==hgy:
                     ap=False
               if ap==True:
                  pl.append([x+1,y])
            if pml.get_at((x-1,y))[0]==255:
               ap=True
               hgx=x-1
               hgy=y
               for obj in pl:
                  if obj[0]==hgx and obj[1]==hgy:
                     ap=False
               if ap==True:
                  pl.append([x-1,y])
                  fobjs(pl,pml)
            if pml.get_at((x,y+1))[0]==255:
               ap=True
               hgx=x
               hgy=y+1
               for obj in pl:
                  if obj[0]==hgx and obj[1]==hgy:
                     ap=False
               if ap==True:
                  pl.append([x,y+1])
                  fobjs(pl,pml)
            if pml.get_at((x,y-1))[0]==255:
               ap=True
               hgx=x
               hgy=y-1
               for obj in pl:
                  if obj[0]==hgx and obj[1]==hgy:
                     ap=False
               if ap==True:
                  pl.append([x,y-1])
                  fobjs(pl,pml)
      except:
         True
      for p in pl:
         pygame.gfxdraw.pixel(pml,p[0],p[1],(255,0,0))
      spc=-1
      for ob in spl:
         spc+=1
         pygame.gfxdraw.pixel(pml,ob[0],ob[1],(0,0,0))
         #spl.pop(spc)
      del pl
      pygame.draw.rect(dp,(255,255,0),(kp,(1,1)))
      #ns=pygame.transform.scale(dp,(16000,16000))
      #dp.blit(ns,(0,0))
      #dp.blit(kap,(kp[0]-5,kp[1]-5))
      pygame.display.update()
      clock.tick(25)
error()
   
