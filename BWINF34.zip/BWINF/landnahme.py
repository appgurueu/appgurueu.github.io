#!/usr/bin/python
# -*- coding: <UTF-8> -*-
print "Bundeswettbewerb Informatik Aufgabe 1(Landnahme):"
lf=open("lsl.txt","r")#Das oeffnen der Datei in der die Koordinaten stehen
landstueckliste=[]#Liste fuer die Landstuecke
linecount=0#Die "Linienzahl", mit dieser Zahl sorgt man dafuer das die Werte richtig eingelesen werden.
tup=[]#Ein "Landstueck"
for line in lf:#Fuer Linie in Datei
    linecount+=1#Eine Linie gelesen
    tup.append(float(line.rstrip()))#Landstueck Eckpunktkoordinate hinzufuegen
    if linecount==4:#Alle vier Linien Rechteck hinzufuegen
        landstueckliste.append(tup)
        del tup
        tup=[]
        linecount=0#Linienzahl resetten
lf.close()#Datei wird geschlossen
"""def ir(zahl,start,ende):
    if zahl==start or zahl==ende:
        return True
    else:
        if zahl >= start and zahl <= ende:
            return True
        else:
            return False"""
"""def onrect(position,rect):
    pos=position
    if ir(pos[0],rect[0],rect[0]+rect[2]-1)==True and ir(pos[1],rect[1],rect[1]+rect[3]-1)==True:
        return True
    else:
        return False
def colliderect(rect1,rect2):
    if onrect((rect1[0],rect1[1]),rect2)==True or onrect((rect1[0]+rect1[2]-1,rect1[1]),rect2)==True or onrect((rect1[0],rect1[1]+rect1[3]-1),rect2)==True or onrect((rect1[0]+rect1[2]-1,rect1[1]+rect1[3]-1),rect2)==True :
        return True
    else:
        if onrect((rect2[0],rect2[1]),rect1)==True or onrect((rect2[0]+rect2[2]-1,rect2[1]),rect1)==True or onrect((rect2[0],rect2[1]+rect2[3]-1),rect1)==True or onrect((rect2[0]+rect2[2]-1,rect2[1]+rect2[3]-1),rect1)==True :
            return True
        else:
            return False"""
def ir(zahl,start,ende):#Funktion inrange, bestimmt, ob eine Zahl zwischen zwei Zahlen liegt.
    if zahl==start or zahl==ende:
        return False
    else:
        if start <=ende:
            if zahl in range(int(start),int(ende)):
                return True
        else:
            if zahl in range(int(ende),int(start)):
                return True
def onrect(position,rect):#Funktion onrect, bestimmmt mit Funktion ir ob ein Punkt in einem Rechteck liegt.
    pos=position
    if ir(pos[0],rect[0],rect[0]+rect[2])==True and ir(pos[1],rect[1],rect[1]+rect[3])==True:
        return True
    else:
        return False
def colliderect(rect1,rect2):#Funktion colliderect, bestimmt mit onrect, ob sich zwei Rechtecke ueberschneiden
    if onrect((rect1[0],rect1[1]),rect2)==True or onrect((rect1[0]+rect1[2],rect1[1]),rect2)==True or onrect((rect1[0],rect1[1]+rect1[3]),rect2)==True or onrect((rect1[0]+rect1[2],rect1[1]+rect1[3]),rect2)==True :
        return True
    else:
        if onrect((rect2[0],rect2[1]),rect1)==True or onrect((rect2[0]+rect2[2],rect2[1]),rect1)==True or onrect((rect2[0],rect2[1]+rect2[3]),rect1)==True or onrect((rect2[0]+rect2[2],rect2[1]+rect2[3]),rect1)==True :
            return True
        else:
            return False

gn=[]#Liste mit GENEHMIGTEN oder ABGELEHNTEN Landstuecken
#gn.append([landstueckliste[0][0],landstueckliste[0][1],landstueckliste[0][2],landstueckliste[0][3],"ANGENOMMEN"])
#landstueckliste.pop(0)

for obj in landstueckliste:#Fuer Antrag in Antragliste
    objrect=(obj[0],obj[1],obj[2]-obj[0],obj[3]-obj[1])#Rechteck des Landstueckes
    kol=False#Bool "Ueberschneidung"=Falsch
    for g in gn:#Fuer Landstueck in Liste mit GENEHMIGTEN oder ABGELEHNTEN Landstuecken
        if g[4]=="ANGENOMMEN":#Wenn Landstueck angenommen...
            grect=(g[0],g[1],g[2]-g[0],g[3]-g[1])#Rechteck des Landstueckes
            if colliderect(grect,objrect)==True:#Wenn sich der Antrag mit dem genehmigten Landstueck ueberschneidet...
                kol=True#Bool "Ueberschneidung"=Wahr
                gn.append([obj[0],obj[1],obj[2],obj[3],"ABGELEHNT"])#Liste mit GENEHMIGTEN oder ABGELEHNTEN Landstuecken Landstueck als ABGELEHNT hinzufuegen.
                break#Schleife aufbrechen, da ja schon eine Ueberschneidung besteht
    if kol==False:#Wenn Bool "Ueberschneidung"=Falsch, also keine Ueberschneidung...
        gn.append([obj[0],obj[1],obj[2],obj[3],"ANGENOMMEN"])#... Fuege Landstueck der Liste mit GENEHMIGTEN oder ABGELEHNTEN Landstuecken als ANGENOMMEN hinzu.
writestring=""""""#String, der nachher in die Datei output.txt geschrieben wird.
for gni in gn:#Auslesen der Liste genehmigter Landstuecke
    print gni#Landstueck anzeigen
    writestring+="""
    """+str(gni)#Linie dem String, der nachher in die Datei geschrieben wird hinzufuegen
target=open("output.txt","w")#Oeffnen von output.txt
target.write(writestring)#Beschreiben(Ueberschreiben)von output.txt
target.close()#output.txt wieder schliessen.

