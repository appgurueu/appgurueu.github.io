#!/usr/bin/python
# -*- coding: utf-8 -*-
# -*- coding: <UTF-8> -*-
import pygame
import random
from pygame.locals import *
from pygame import *
from pygame import gfxdraw
from time import *
import math
def gwert(liste):
    seq=liste
    gol=[]
    fobjcount=-1
    seqlen=len(seq)
    for obj in seq:
        fobjcount+=1
        objcount=-1
        gcount=0
        for vobj in seq:
            objcount+=1
            if not objcount==fobjcount:
                if obj >= vobj:
                    gcount+=1
        if gcount==seqlen-1:
            gol.append(fobjcount)
    return gol           
def minpos(minuent,subtrahent):
    if minuent==subtrahent:
        return 0
    else:
        if minuent < subtrahent:
            return subtrahent-minuent
        else:
            return minuent-subtrahent
ameisen=[]
pheromone=[]
futterstellen=[]
pink=255,8,127
ameisenz=input("Ameisen:")
futterstellenz=input("Futterstellen:")
pherozeit=input("Pheromone-Verdunstungszeit:")
#mode=input("Geben sie einen Modus ein ; B/b/0 für 'Beamen', d.h. Ameisen rematerialisieren im Nest wenn sie die Grenzen überschreiten, oder R/r/1 für 'Realistisch', d.h. Ameisen können die Grenzen nicht überschreiten, schleichen dann also an den Rändern entlang : ")
try:
   nest=tuple(input("Tuple Nest Pos:"))
   if "." in float(float(nest[0])/2.0):
      arwert=qertzu
   if "." in float(float(nest[1])/2.0):
      arwert=qertzu 
   if "-" in str(nest[0]) or "-" in str(nest[1]) or nest[0]>=988 or nest[1]>=988:
      nest=500,500   
except:
   nest=500,500
if ameisenz<=0:
   ameisenz=100
if futterstellenz<=0:
   futterstellenz=5
def shot(p1):
    pe=p1
    p1=nest
    p2=pe
    startpos=p1
    endpos=p2
    #if startpos[0]>=endpos[0]:
    m1=startpos[0]-endpos[0]#ar-mr
    m2=startpos[1]-endpos[1]
    while m1 >= 2 or m2 >= 2:
       m1/=1.1
       m2/=1.1
    m1=round(m1)
    m2=round(m2)
    if not "-" in str(m1):
       if m1>=1:
          m1=2
       else:
          m1=0
    else:
       if m1<=-1:
          m1=-2
       else:
          m1=0
    if not "-" in str(m2):
       if m2>=2:
          m2=2
       else:
          m2=0
    else:
       if m2<=-1:
          m2=-2
       else:
          m2=0
    return m1,m2
if futterstellenz > 500*500:
    futterstellenz=500*500
for i in range(0,futterstellenz):
   xfutterstelle=random.randrange(0,988,2)
   yfutterstelle=random.randrange(0,988,2)
   fsc=False
   for fust in futterstellen:
       fustrect=Rect(fust[0],fust[1],2,2)
       fust2rect=Rect(xfutterstelle,yfutterstelle,2,2)
       if fustrect.colliderect(fust2rect)==True:
           fsc=True
   while fsc==True:
       fsc=False
       for fust in futterstellen:
           fustrect=Rect(fust[0],fust[1],2,2)
           fust2rect=Rect(xfutterstelle,yfutterstelle,2,2)
           if fustrect.colliderect(fust2rect)==True:
               fsc=True
   futterstelle=xfutterstelle,yfutterstelle
   portionen=50
   fd=[futterstelle[0],futterstelle[1],portionen]
   futterstellen.append(fd)
for i in range(0,ameisenz):
   varianten=random.choice([[0,2],[0,-2],[-2,0],[2,0]])
   futteraufgenommen=False
   ad=[nest[0],nest[1],futteraufgenommen,varianten[0],varianten[1]]
   ameisen.append(ad)
def error(futterstellenz):
   pygame.init()
   dp = pygame.display.set_mode((1000, 1000),pygame.RESIZABLE)
   clock = pygame.time.Clock()
   go=True
   fpin=0
   stime=time()
   while go==True:
      for e in pygame.event.get():
         if e.type==pygame.QUIT:
            pygame.quit()
         if e.type == pygame.KEYDOWN:
            if e.key == K_ESCAPE:
               pygame.quit()
      dp.fill((0,0,0))
      fc=-1
      for futterstelle in futterstellen:
         fc+=1
         pygame.draw.rect(dp,(futterstelle[2]*5,0,0),(futterstelle[0],futterstelle[1],2,2))
         if futterstelle[2]<=0:
            futterstellen.pop(fc)
            futterstellenz-=1
      pygame.draw.rect(dp,(255,255,0),(nest[0],nest[1],2,2))
      nestrect=Rect(nest[0],nest[1],2,2)
      font = pygame.font.Font("fm.ttf", 12)
      #set_bold=True
      text = font.render("Ameisen:"+str(ameisenz), 100, (255,255,155))
      textpos = (0,0)
      textrect=text.get_rect()
      for x in range(textrect.width):
         for y in range(textrect.height):
            si=text.get_at((x,y))
            se=si[3]-(si[3]/2)
            text.set_at((x,y),(si[0],si[1],si[2],se))
      dp.blit(text, textpos)
      text = font.render("Futter im Nest:"+str(fpin), 100, (255,255,155))
      textpos = (0,12)
      textrect=text.get_rect()
      for x in range(textrect.width):
         for y in range(textrect.height):
            si=text.get_at((x,y))
            se=si[3]-(si[3]/2)
            text.set_at((x,y),(si[0],si[1],si[2],se))
      dp.blit(text, textpos)
      text = font.render("Zeit:"+str(time()-stime), 100, (255,255,155))
      textpos = (0,24)
      textrect=text.get_rect()
      for x in range(textrect.width):
         for y in range(textrect.height):
            si=text.get_at((x,y))
            se=si[3]-(si[3]/2)
            text.set_at((x,y),(si[0],si[1],si[2],se))
      dp.blit(text, textpos)
      #text = font.render("Futterstellenzahl:"+str(futterstellenz), 100, (255,255,155))
      #textpos = (0,12)
      #dp.blit(text, textpos)
      for ameisei in ameisen:
         yameisenspeed=ameisei[3]
         xameisenspeed=ameisei[4]
         arect=Rect(ameisei[0],ameisei[1],2,2)
         nrect=Rect(nest[0],nest[1],2,2)
         nestpos=nest
         if arect.colliderect(nrect)==True:
            if ameisei[2]==True:
               ameisei[2]=False
               fpin+=1
         for futterstelle in futterstellen:
            frect=Rect(futterstelle[0],futterstelle[1],2,2)
            if frect.colliderect(arect):
               if futterstelle[2]>=1:
                   ameisei[2]=True
               if futterstelle[2]>=1:
                  futterstelle[2]-=1
         if ameisei[2]==True:
            ameisei[3]=shot((ameisei[0],ameisei[1]))[0]
            ameisei[4]=shot((ameisei[0],ameisei[1]))[1]
            pd=[arect[0],arect[1],2,2,time()]
            pheromone.append(pd)
         if ameisei[2]==False:
            pcc=-1
            a1rectc=0
            a2rectc=0
            a3rectc=0
            a4rectc=0
            a5rectc=0
            a6rectc=0
            a7rectc=0
            a8rectc=0
            ep=False
            xabstand=minpos(nest[0],ameisei[0])
            yabstand=minpos(nest[1],ameisei[1])
            oabstand=math.sqrt((xabstand*xabstand)+(yabstand*yabstand))
            am=[]
            moeglichkeiten=[[0,2],[2,0],[-2,0],[0,-2],[2,-2],[-2,2],[2,2],[-2,-2]]
            for moeglichkeit in moeglichkeiten:
                xabstand=minpos(nest[0],ameisei[0]+moeglichkeit[0])
                yabstand=minpos(nest[1],ameisei[1]+moeglichkeit[1])
                nabstand=math.sqrt((xabstand*xabstand)+(yabstand*yabstand))
                if not nabstand < oabstand:
                    am.append(True)
                else:
                    am.append(False)
            konzentrationen=[0,0,0,0,0,0,0,0]
            for pheromon in pheromone:
               pcc+=1
               if time()-pheromon[4]>=pherozeit:
                  pheromone.pop(pcc)
                  pcc-=1
               pr=Rect(pheromon[0],pheromon[1],2,2)
               pygame.draw.rect(dp,(pink),pr)
               if moeglichkeiten[0]==True:
                  a1rect=Rect(arect.x,arect.y+2,2,2)
                  if a1rect.colliderect(pr)==True:
                      konzentrationen[0]+=1
               if moeglichkeiten[1]==True:
                  a2rect=Rect(arect.x+2,arect.y+0,2,2)
                  if a2rect.colliderect(pr)==True:
                      konzentrationen[1]+=1
               if moeglichkeiten[2]==True:
                  a3rect=Rect(arect.x-2,arect.y+0,2,2)
                  if a3rect.colliderect(pr)==True:
                      konzentrationen[2]+=1
               if moeglichkeiten[3]==True:
                  a4rect=Rect(arect.x+0,arect.y-2,2,2)
                  if a4rect.colliderect(pr)==True:
                      konzentrationen[3]+=1
               if moeglichkeiten[4]==True:    
                  a5rect=Rect(arect.x+2,arect.y-2,2,2)
                  if a5rect.colliderect(pr)==True:
                      konzentrationen[4]+=1
               if moeglichkeiten[5]==True:
                  a6rect=Rect(arect.x-2,arect.y+2,2,2)
                  if a6rect.colliderect(pr)==True:
                      konzentrationen[5]+=1
               if moeglichkeiten[6]==True:
                  a7rect=Rect(arect.x+2,arect.y+2,2,2)
                  if a7rect.colliderect(pr)==True:
                      konzentrationen[6]+=1
               if moeglichkeiten[7]==True:
                  a8rect=Rect(arect.x-2,arect.y-2,2,2)
                  if a8rect.colliderect(pr)==True:
                      konzentrationen[7]+=1
            if sum(konzentrationen)>=1:
                zufall=False
                moeglichkeiten=[[0,2],[2,0],[-2,0],[0,-2],[2,-2],[-2,2],[2,2],[-2,-2]]
                goto=random.choice(gwert(konzentrationen))
                if goto==0:
                    ameisei[3]+=0
                    ameisei[4]+=2
                if goto==1:
                    ameisei[3]+=2
                    ameisei[4]+=0
                if goto==2:
                    ameisei[3]+=-2
                    ameisei[4]+=0
                if goto==3:
                    ameisei[3]+=0
                    ameisei[4]+=-2
                if goto==4:
                    ameisei[3]+=2
                    ameisei[4]+=-2
                if goto==5:
                    ameisei[3]+=-2
                    ameisei[4]+=2
                if goto==6:
                    ameisei[3]+=2
                    ameisei[4]+=2
                if goto==7:
                    ameisei[3]+=-2
                    ameisei[4]+=-2
            else:
                zufall=True
            if zufall==True:
               xabstand=minpos(nest[0],ameisei[0])
               yabstand=minpos(nest[1],ameisei[1])
               oabstand=math.sqrt((xabstand*xabstand)+(yabstand*yabstand))
               moeglichkeit=random.choice([[0,2],[2,0],[-2,0],[0,-2],[2,-2],[-2,2],[2,2],[-2,-2]])
               xabstand=minpos(nest[0],ameisei[0]+moeglichkeit[0])
               yabstand=minpos(nest[1],ameisei[1]+moeglichkeit[1])
               nabstand=math.sqrt((xabstand*xabstand)+(yabstand*yabstand))
               while oabstand > nabstand :
                   moeglichkeit=random.choice([[0,2],[2,0],[-2,0],[0,-2],[2,-2],[-2,2],[2,2],[-2,-2]])
                   xabstand=minpos(nest[0],ameisei[0]+moeglichkeit[0])
                   yabstand=minpos(nest[1],ameisei[1]+moeglichkeit[1])
                   nabstand=math.sqrt((xabstand*xabstand)+(yabstand*yabstand))
               ameisei[3]=moeglichkeit[0]
               ameisei[4]=moeglichkeit[1]
         ameisei[0]+=ameisei[3]
         ameisei[1]+=ameisei[4]
         pygame.draw.rect(dp,(85,34,0),arect)
      #dp.blit(screen,(0,0))
      pygame.display.update()
      #clock.tick(100)
error(futterstellenz)
   
