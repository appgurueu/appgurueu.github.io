#!/usr/bin/python
# -*- coding: <UTF-8> -*-
global mcount
flaschen=input("Flaschen : ")
behaelter=input("Behaelter : ")
bdict={}
vdict={}
moeg=[]
fmoegen=[]
#mcount=0
insgesamtvmoegen=0
for i in range(0,behaelter):
   behaelterfassungsvermoegen=input("Behaelterfassungsvermögen "+"Behaelter "+str(i+1)+" : ")
   insgesamtvmoegen+=behaelterfassungsvermoegen
   if flaschen < behaelterfassungsvermoegen :
      fmoegen.append(flaschen)
      #mcount+=1
   else:
      fmoegen.append(behaelterfassungsvermoegen)
   adict={str(i):str(behaelterfassungsvermoegen)}
   bdict.update(adict)
   vdict.update({str(i):str(0)})
fmoegen.sort()
print fmoegen
def verteilen(flzahl,fmoegenliste):
    #loesung=0
    if len(fmoegenliste)==1:
        if flzahl <= fmoegenliste[0]:
            loesung=1
            print "add"
            return loesung
        else:
            loesung=1
            return loesung
            print "add"
    if len(fmoegenliste) > 1:
        for i in range(1,fmoegenliste[0]):
            if verteilen(flzahl-i,fmoegenliste[1:])==1:
                #mcount+=1
                print "add"
verteilen(flaschen,fmoegen)

if flaschen==1:
   print "Es gibt "+str(behaelter)+" Möglichkeit/en"
else:
   moeglichkeiten=0
   fv=int(bdict[str(0)])
   if flaschen==insgesamtvmoegen:
       print "Es gibt "+str(behaelter)+"Möglichkeit/en"
   else:
       for fm in fmoegen:
           for fuellen in range(0,fm+1):
               vflaschen=fuellen
               for fm in fmoegen[fm+1:]:
                   for fuellen in range(0,fm+1-vflaschen):
                       vflaschen=fuellen
                   mcount+=1
"""length=fmoegen[0]
for fmoeg in fmoegen[1:]:
    length=length*fmoeg
print "Die aktuelle Ml. ist"," ",length
schritt=length
count=0
for i in range(0,len(fmoegen)+1):
    print "Durchlauf : ",i+1," von ",len(fmoegen)+1
    for i in range(0,length):
        count+=1
        if count <= schritt:
            moeglichkeiten[i].append(1)
        if count > schritt:
            moeglichkeiten[i].append(0)
        if count ==(schritt*2):
            count=0"""
