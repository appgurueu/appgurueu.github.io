# -*- coding: utf-8 -*-
print "34. Bundeswettbewerb Informatik Lösungsprogramme Organisationsprogramm"
inp=-1
while not inp>=7:
    try:
       inp=input("Geben sie 1 fuer 'Landnahme' ein, 2 fuer 'Kassiopeia', 3 fuer 'Kassiopeias Weg', 4 fuer 'Ameisenfutter(Simulation)', 5 fuer 'Flaschenzug, 6 fuer 'Schlüssellöcher', oder eine Zahl >= 7 um das Lösungsprogramme Organisationsprogramm zu beenden : ")
       if inp==1:
           execfile("landnahme.py")
       if inp==2:
           execfile("kassiopeia.py")
       if inp==3:
           execfile("landnahme.py")
    except:
       True
       inp=-1
