#!/usr/bin/python
# -*- coding: <UTF-8> -*-
import pygame
from pygame.locals import *
from pygame import *
from pygame import gfxdraw
import math
def main():
    pygame.init()#Initialisieren von Pygame
    dp = pygame.display.set_mode((200, 200),pygame.RESIZABLE)
    clock = pygame.time.Clock()
    pml=pygame.image.load("kassiopeia.png")#Bild laden
    gn=False
    gn2=False
    checksum=0#Die Pruefsumme
    pl=[]
    pli=True
    for x in range(pml.get_rect().width):
        for y in range(pml.get_rect().height):
            si=pml.get_at((x,y))
            if si[0]==255:
                checksum+=1
                if pli==True:
                    pl.append([x,y])
                    pli=False
    for o in pl:
        p=o
        x=p[0]
        y=p[1]
        try:
            if pml.get_at((x+1,y))[0]==255:
                ap=True
                hgx=x+1
                hgy=y
                for obj in pl:
                    if obj[0]==hgx and obj[1]==hgy:
                        ap=False
                if ap==True:
                    pl.append([x+1,y])
        except:
            True
        try:
            if pml.get_at((x-1,y))[0]==255:
                ap=True
                hgx=x-1
                hgy=y
                for obj in pl:
                    if obj[0]==hgx and obj[1]==hgy:
                        ap=False
                if ap==True:
                    pl.append([x-1,y])
        except:
            True
        try:
            if pml.get_at((x,y+1))[0]==255:
                ap=True
                hgx=x
                hgy=y+1
                for obj in pl:
                    if obj[0]==hgx and obj[1]==hgy:
                        ap=False
                if ap==True:
                    pl.append([x,y+1])
        except:
            True
        try:
            if pml.get_at((x,y-1))[0]==255:
                ap=True
                hgx=x
                hgy=y-1
                for obj in pl:
                    if obj[0]==hgx and obj[1]==hgy:
                        ap=False
                if ap==True:
                    pl.append([x,y-1])
        except:
            True
        
    kc=0
    for p in pl:
        kc+=1
        #print p[0],",",p[1]
    print checksum
    if kc<=checksum-1:
        print "HAT LEIDER NICHT GEKLAPPT,KASSIOPEIA!"
    else:
        print "HAT GEKLAPPT,KASSIOPEIA!"
    go=True
    while go==True:
        for e in pygame.event.get():
            if e.type==pygame.QUIT:
               pygame.quit()
            if e.type == pygame.KEYDOWN:
                if e.key == K_ESCAPE:
                    pygame.quit()
        dp.fill((0,255,0))
        dp.blit(pml,(0,0))
        for p in pl:
            pygame.gfxdraw.pixel(dp,p[0],p[1],(255,0,0))
        dp2=pygame.transform.scale(dp,(2000,2000))
        dp.blit(dp2,(0,0))
        pygame.display.update()
        clock.tick(100)
try:
    main()
except:
    True
   
