# -*- coding: utf-8 -*-
print "Bundeswettbewerb Informatik Schlüssellöcher Teilaufgabe 1 und 2"
schluesselms=[]
def gerade(zahl):
    zahlstring=str(zahl)
    zsl=len(zahlstring)
    if zahlstring[zsl-1]=="1" or zahlstring[zsl-1]=="3" or zahlstring[zsl-1]=="5" or zahlstring[zsl-1]=="7" or zahlstring[zsl-1]=="9" :
        return False
    else:
        return True
def hoch(zahl,faktor):
    fm=faktor-1
    zahl=zahl
    szahl=zahl
    for i in range(0,fm):
        zahl=zahl*szahl
        print zahl
    return zahl
schluessel=hoch(2,25)
reihe=2*2*2*2*2
reihe1=1*2*2*2*1
schluessel=int(reihe*reihe*reihe*reihe*reihe)
print "Es koennen insgesamt ",schluessel," Lochkarten produziert werden."
schluessel=int(reihe1*reihe*reihe*reihe*reihe)
print "Es koennen insgesamt ",schluessel," Lochkarten produziert werden, wenn sie nicht verkehrt herum eingesteckt werden können."
reihe=2*2*2*1*1*1
schluessel=int(reihe*reihe*reihe*reihe*reihe)
print "Es koennen insgesamt ",schluessel," Lochkarten produziert werden, wenn sie spiegelsymmetrisch sein sollen."
schluesselzahl=input("Wie viele Lochkarten ?")
if schluesselzahl==1:
    moeglichkeiten.append([1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1])
if schluesselzahl==2:
    moeglichkeiten.append([1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1])
    moeglichkeiten.append([0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0])
def hoch(zahl,faktor):
    fm=faktor-1
    zahl=zahl
    szahl=zahl
    for i in range(0,fm):
        zahl=zahl*szahl
        print zahl
        if zahl > schluesselzahl:
            if zahl/2 < schluesselzahl:
                return [zahl,i]
            else:
                return [zahl/2,i-1]
            

kfaktor=hoch(2,25)[1]
print "Es koennen : ",kfaktor," Loecher gruppiert werden."
moeglichkeiten=[]
schluessel=hoch(2,25)[0]
length=schluessel
schritt=length/2
print "Startprozess..."
for i in range(0,schritt):
    moeglichkeiten.append([1])
for i in range(0,schritt):
    moeglichkeiten.append([0])
schritt=schritt/2
count=0
print "Generiere..."
for i in range(0,24):
    print "Durchlauf : ",i+1," von 24."
    for i in range(0,length):
        count+=1
        if count <= schritt:
            moeglichkeiten[i].append(1)
        if count > schritt:
            moeglichkeiten[i].append(0)
        if count ==(schritt*2):
            count=0
    schritt=schritt/2
gl=0
print "Fertig  mit Berechnung der Lochkarten!"
for obj in moeglichkeiten[0]:
    if obj==0:
        gl+=1
print "Es koennen : ",gl," Loecher gruppiert werden."
print "Gruppierung wird gestartet."
for i in range(0,gl):
   for var in moeglichkeiten:
       if i <= 25-gl:
          clonevar=moeglichkeiten[i]
          vl=var[i+1:]
          #var.append[]
       else:
          clonevar=moeglichkeiten[i-25-gl]
          vl=moeglichkeiten[i-25-gl+1:]
print "Schluesselausgabe : "
for moeg  in moeglichkeiten[0:schluesselzahl]:
    print moeg
