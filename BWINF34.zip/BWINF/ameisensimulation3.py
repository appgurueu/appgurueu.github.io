#!/usr/bin/python
# -*- coding: <UTF-8> -*-
import pygame
import random
from pygame.locals import *
from pygame import *
from pygame import gfxdraw
from time import *
def gwert(liste):
    seq=liste
    gol=[]
    fobjcount=-1
    seqlen=len(seq)
    for obj in seq:
        fobjcount+=1
        objcount=-1
        gcount=0
        for vobj in seq:
            objcount+=1
            if not objcount==fobjcount:
                if obj >= vobj:
                    gcount+=1
        if gcount==seqlen-1:
            gol.append(fobjcount)
    return gol
def minpos(minuent,subtrahent):
    if minuent==subtrahent:
        return 0
    else:
        if minuent < subtrahent:
            return subtrahent-minuent
        else:
            return minuent-subtrahent
ameisen=[]
pheromone=[]
futterstellen=[]
pink=255,8,127
ameisenz=input("Ameisen:")
futterstellenz=input("Futterstellen:")
pherozeit=input("Pheromone-Verdunstungszeit:")
try:
   nest=tuple(input("Tuple Nest Pos:"))
   print nest[0]
   print nest[1]
   if "-" in str(nest[0]) or "-" in str(nest[1]) or nest[0]>=988 or nest[1]>=988:
      nest=500,500   
except:
   nest=500,500
if ameisenz<=0:
   ameisenz=100
if futterstellenz<=0:
   futterstellenz=5
def shot(p1):
    pe=p1
    p1=nest
    p2=pe
    startpos=p1
    endpos=p2
    #if startpos[0]>=endpos[0]:
    m1=startpos[0]-endpos[0]#ar-mr
    m2=startpos[1]-endpos[1]
    while m1 >= 2 or m2 >= 2:
       m1/=1.1
       m2/=1.1
    m1=round(m1)
    m2=round(m2)
    if not "-" in str(m1):
       if m1>=1:
          m1=2
       else:
          m1=0
    else:
       if m1<=-1:
          m1=-2
       else:
          m1=0
    if not "-" in str(m2):
       if m2>=2:
          m2=2
       else:
          m2=0
    else:
       if m2<=-1:
          m2=-2
       else:
          m2=0
    return m1,m2
for i in range(0,futterstellenz):
   xfutterstelle=random.randint(0,988)
   yfutterstelle=random.randint(0,988)
   futterstelle=xfutterstelle,yfutterstelle
   portionen=50
   fd=[futterstelle[0],futterstelle[1],portionen]
   futterstellen.append(fd)
for i in range(0,ameisenz):
   varianten=random.choice([[0,2],[0,-2],[-2,0],[2,0]])
   futteraufgenommen=False
   ad=[nest[0],nest[1],futteraufgenommen,varianten[0],varianten[1]]
   ameisen.append(ad)
def error(futterstellenz):
   pygame.init()
   dp = pygame.display.set_mode((1000, 1000),pygame.RESIZABLE)
   clock = pygame.time.Clock()
   go=True
   fpin=0
   stime=time()
   while go==True:
      for e in pygame.event.get():
         if e.type==pygame.QUIT:
            pygame.quit()
         if e.type == pygame.KEYDOWN:
            if e.key == K_ESCAPE:
               pygame.quit()
      dp.fill((0,0,0))
      fc=-1
      for futterstelle in futterstellen:
         fc+=1
         pygame.draw.rect(dp,(futterstelle[2]*5,0,0),(futterstelle[0],futterstelle[1],2,2))
         if futterstelle[2]<=0:
            futterstellen.pop(fc)
            futterstellenz-=1
      pygame.draw.rect(dp,(255,255,0),(nest[0],nest[1],2,2))
      nestrect=Rect(nest[0],nest[1],2,2)
      font = pygame.font.Font("fm.ttf", 12)
      #set_bold=True
      text = font.render("Ameisen:"+str(ameisenz), 100, (255,255,155))
      textpos = (0,0)
      textrect=text.get_rect()
      for x in range(textrect.width):
         for y in range(textrect.height):
            si=text.get_at((x,y))
            se=si[3]-(si[3]/2)
            text.set_at((x,y),(si[0],si[1],si[2],se))
      dp.blit(text, textpos)
      text = font.render("Futter im Nest:"+str(fpin), 100, (255,255,155))
      textpos = (0,12)
      textrect=text.get_rect()
      for x in range(textrect.width):
         for y in range(textrect.height):
            si=text.get_at((x,y))
            se=si[3]-(si[3]/2)
            text.set_at((x,y),(si[0],si[1],si[2],se))
      dp.blit(text, textpos)
      text = font.render("Zeit:"+str(time()-stime), 100, (255,255,155))
      textpos = (0,24)
      textrect=text.get_rect()
      for x in range(textrect.width):
         for y in range(textrect.height):
            si=text.get_at((x,y))
            se=si[3]-(si[3]/2)
            text.set_at((x,y),(si[0],si[1],si[2],se))
      dp.blit(text, textpos)
      #text = font.render("Futterstellenzahl:"+str(futterstellenz), 100, (255,255,155))
      #textpos = (0,12)
      #dp.blit(text, textpos)
      for ameisei in ameisen:
         yameisenspeed=ameisei[3]
         xameisenspeed=ameisei[4]
         arect=Rect(ameisei[0],ameisei[1],2,2)
         nrect=Rect(nest[0],nest[1],2,2)
         nestpos=nest
         if arect.colliderect(nrect)==True:
            if ameisei[2]==True:
               ameisei[2]=False
               fpin+=1
         for futterstelle in futterstellen:
            frect=Rect(futterstelle[0],futterstelle[1],2,2)
            if frect.colliderect(arect):
               ameisei[2]=True
               if futterstelle[2]>=1:
                  futterstelle[2]-=1
         if ameisei[2]==True:
            ameisei[3]=shot((ameisei[0],ameisei[1]))[0]
            ameisei[4]=shot((ameisei[0],ameisei[1]))[1]
            pd=[arect[0],arect[1],2,2,time()]
            pheromone.append(pd)
         if ameisei[2]==False:
            pcc=-1
            a1rectc=0
            a2rectc=0
            a3rectc=0
            a4rectc=0
            a5rectc=0
            a6rectc=0
            a7rectc=0
            a8rectc=0
            ep=False
            for pheromon in pheromone:
               pcc+=1
               if time()-pheromon[4]>=pherozeit:
                  pheromone.pop(pcc)
                  pcc-=1
               pr=Rect(pheromon[0],pheromon[1],2,2)
               pygame.draw.rect(dp,(pink),pr)
               a1rect=Rect(arect.x-2,arect.y-2,2,2)
               a2rect=Rect(arect.x+2,arect.y-2,2,2)
               a3rect=Rect(arect.x-2,arect.y+2,2,2)
               a4rect=Rect(arect.x+2,arect.y+2,2,2)
               a5rect=Rect(arect.x+2,arect.y,2,2)
               a6rect=Rect(arect.x-2,arect.y,2,2)
               a7rect=Rect(arect.x,arect.y+2,2,2)
               a8rect=Rect(arect.x,arect.y-2,2,2)
               a1rectwert=0
               wertif=False
               if a1rect.colliderect(pr):
                  wertif=True
                  a1rectc+=1
               if a2rect.colliderect(pr):
                  wertif=True
                  a2rectc+=1
               if a3rect.colliderect(pr):
                  wertif=True
                  a3rectc+=1
               if a4rect.colliderect(pr):
                  wertif=True
                  a4rectc+=1
               if a5rect.colliderect(pr):
                  wertif=True
                  a5rectc+=1
               if a6rect.colliderect(pr):
                  wertif=True
                  a6rectc+=1
               if a7rect.colliderect(pr):
                  wertif=True
                  a7rectc+=1
               if a8rect.colliderect(pr):
                  wertif=True
                  a8rectc+=1
               arectcs=[a1rectc,a2rectc,a3rectc,a4rectc,a5rectc,a6rectc,a7rectc,a8rectc]
               if wertif==True:
                  ep=True
                  arets=gwert(arectcs)
                  try:
                     hingehen=int(random.choice(arets))+1
                  except:
                     hingehen=int(arets[0])+1
                  if hingehen==1:
                     ameisei[3]=-2
                     ameisei[4]=-2
                  if hingehen==2:
                     ameisei[3]=+2
                     ameisei[4]=-2
                  if hingehen==3:
                     ameisei[3]=-2
                     ameisei[4]=+2
                  if hingehen==4:
                     ameisei[3]=+2
                     ameisei[4]=+2
                  if hingehen==5:
                     ameisei[3]=+2
                     ameisei[4]=0
                  if hingehen==6:
                     ameisei[3]=-2
                     ameisei[4]=0
                  if hingehen==7:
                     ameisei[3]=0
                     ameisei[4]=+2
                  if xameisenspeed==0 and yameisenspeed==2:
                     if hingehen==8:
                        ameisei[3]=0
                        ameisei[4]=-2
            if 1==1:
               iabstand=minpos(ameisei[0],nestpos[0]),minpos(ameisei[1],nestpos[1])
               oabstand=iabstand[0]+iabstand[1]
               if ep==False:
                  if xameisenspeed==0 and yameisenspeed==2:
                     varianten=random.choice([[0,2],[2,0],[-2,0]])
                     iabstand=minpos(ameisei[0]+varianten[0],nestpos[0])+minpos(ameisei[1]+varianten[1],nestpos[1])
                     while oabstand < iabstand:
                         varianten=random.choice([[0,2],[2,0],[-2,0]])
                         iabstand=minpos(ameisei[0]+varianten[0],nestpos[0]),minpos(ameisei[1]+varianten[1],nestpos[1])
                         iabstand=iabstand[0]+iabstand[1]
                         print "WHILE1"
                     ameisei[3]=varianten[0]
                     ameisei[4]=varianten[1]
                  if xameisenspeed==0 and yameisenspeed==-2:
                     varianten=random.choice([[0,-2],[2,0],[-2,0]])
                     iabstand=minpos(ameisei[0]+varianten[0],nestpos[0])+minpos(ameisei[1]+varianten[1],nestpos[1])
                     while oabstand < iabstand:
                         varianten=random.choice([[0,-2],[2,0],[-2,0]])
                         iabstand=minpos(ameisei[0]+varianten[0],nestpos[0]),minpos(ameisei[1]+varianten[1],nestpos[1])
                         iabstand=iabstand[0]+iabstand[1]
                         print "WHILE2"
                     ameisei[3]=varianten[0]
                     ameisei[4]=varianten[1]
                  if xameisenspeed==2 and yameisenspeed==0:
                     varianten=random.choice([[2,0],[0,-2],[0,2]])
                     iabstand=minpos(ameisei[0]+varianten[0],nestpos[0])+minpos(ameisei[1]+varianten[1],nestpos[1])
                     while oabstand < iabstand:
                         varianten=random.choice([[2,0],[0,-2],[0,2]])
                         iabstand=minpos(ameisei[0]+varianten[0],nestpos[0]),minpos(ameisei[1]+varianten[1],nestpos[1])
                         iabstand=iabstand[0]+iabstand[1]
                         print "WHILE3"
                     ameisei[3]=varianten[0]
                     ameisei[4]=varianten[1]
                  if xameisenspeed==-2 and yameisenspeed==0:
                     varianten=random.choice([[-2,0],[0,-2],[0,2]])
                     iabstand=minpos(ameisei[0]+varianten[0],nestpos[0])+minpos(ameisei[1]+varianten[1],nestpos[1])
                     while oabstand < iabstand:
                         varianten=random.choice([[-2,0],[0,-2],[0,2]])
                         iabstand=minpos(ameisei[0]+varianten[0],nestpos[0]),minpos(ameisei[1]+varianten[1],nestpos[1])
                         iabstand=iabstand[0]+iabstand[1]
                         print "WHILE4"
                     ameisei[3]=varianten[0]
                     ameisei[4]=varianten[1]
         #if ameisei[0] >=800 or ameisei[1] >=800 or ameisei[0] <= 0-2 or ameisei[1] <= 0-2 :
         #   ameisei[3]=-(ameisei[3])
         #   ameisei[4]=-(ameisei[4])

         ameisei[0]+=ameisei[3]
         ameisei[1]+=ameisei[4]
         pygame.draw.rect(dp,(85,34,0),arect)
      #dp.blit(screen,(0,0))
      pygame.display.update()
      #clock.tick(100)
error(futterstellenz)
   
