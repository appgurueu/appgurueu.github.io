#!/usr/bin/python
# -*- coding: <UTF-8> -*-
import pygame
import random
import os
import math
import sys
from pygame.locals import *
from pygame import *
from pygame import gfxdraw
from time import *
from decimal import *
objcount=input("Menge an Objekten : ")
objekte=[]
def gravity(cp1,cp2,obj):
    entfernung=math.sqrt(((cp1[0]-cp2[0])*(cp1[0]-cp2[0]))+((cp1[1]-cp2[1])*(cp1[1]-cp2[1])))
    if "erde" in obj:
       anziehung=98.1/(entfernung+1)
    return round((cp1[0]-cp2[0])*(anziehung/(entfernung+1))),round((cp1[1]-cp2[1])*(anziehung/(entfernung+1)))
def oncircle(mp,pos,radius):
    if pos[0]>=mp[0]:
       x2=pos[0]-mp[0]
    else:
       x2=mp[0]-pos[0]
    if pos[1]>=mp[1]:
       y2=pos[1]-mp[1]
    else:
       y2=mp[1]-pos[1]
    #x2=mp[0]-pos[0]
    #y2=mp[1]-pos[1]
    ss=math.sqrt((x2*x2)+(y2*y2))
    if ss<=radius:
       return True
def ccollide(pos1,pos2,rad1,rad2):
    x2=pos1[0]-pos2[0]
    y2=pos1[1]-pos2[1]
    ss=math.sqrt(x2*x2+y2*y2)
    if ss<=rad1+rad2 and ss>=-(rad1+rad2):
       return True
    else :
       return False
for i in range(0,objcount):
    center=random.randint(10,390),random.randint(10,390)
    objekte.append([center[0],center[1],10])
    """for obj in objekte:
        if ccollide(center,[obj[0],obj[1]],10,10)==True:
            True
        else:
            objekte.append([center[0],center[1],10])"""
def gwert(liste):
    seq=liste
    gol=[]
    fobjcount=-1
    seqlen=len(seq)
    for obj in seq:
        fobjcount+=1
        objcount=-1
        gcount=0
        for vobj in seq:
            objcount+=1
            if not objcount==fobjcount:
                if obj >= vobj:
                    gcount+=1
        if gcount==seqlen-1:
            gol.append(fobjcount)
    return gol

def minpos(minuent,subtrahent):
    if minuent==subtrahent:
        return 0
    else:
        if minuent < subtrahent:
            return subtrahent-minuent
        else:
            return minuent-subtrahent
screen=pygame.display.set_mode((400,400))
def main():
    screen.fill((0,0,0))
    oc=-1
    for obj in objekte:
        pygame.gfxdraw.filled_circle(screen,int(obj[0]),int(obj[1]),int(obj[2]),(255,255,255))
        oc+=1
        oc2=-1
        testrect=Rect(0,0,obj[2]*2,obj[2]*2)
        testrect.center=obj[0],obj[1]
        for obj2 in objekte:
            oc2+=1
            if not oc2==oc:
                """if ccollide([obj[0],obj[1]],[obj2[0],obj2[1]],obj[2],obj2[2])==True:
                    objekte.pop(oc2)
                    oc2-=1
                    obj[2]=obj[2]+obj2[2]"""
                if 1==1:
                    obj=obj[0]+gravity([obj[0],obj[1]],[obj2[0],obj2[1]],"erde")[0],obj[1]+gravity([obj[0],obj[1]],[obj2[0],obj2[1]],"erde")[1],obj[2]
                    obj2=obj2[0]+gravity([obj[0],obj[1]],[obj2[0],obj2[1]],"erde")[0],obj2[1]+gravity([obj[0],obj[1]],[obj2[0],obj2[1]],"erde")[1],obj2[2]
for i in range(0,10000):
    main()
    pygame.display.update()
#import pygame

"""FPS = 25

pygame.init()
pygame.mixer.quit()
clock = pygame.time.Clock()
movie = pygame.movie.Movie('Sample.mpg')
screen = pygame.display.set_mode((movie.get_size()),pygame.RESIZABLE)
movie_screen = pygame.Surface(movie.get_size()).convert()

movie.set_display(movie_screen)
movie.play()


playing = True
while playing:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            movie.stop()
            playing = False

    screen.blit(movie_screen,(0,0))
    pygame.display.update()
    clock.tick(FPS)

pygame.quit()"""
"""pygame.init()
screen = pygame.display.set_mode((1024, 768))
background = pygame.Surface((1024, 768))

screen.blit(background, (0, 0))
pygame.display.update()

movie = pygame.movie.Movie('outfile.mpg')
mrect = pygame.Rect(0,0,140,113)
movie.set_display(screen, mrect.move(65, 150))
movie.set_volume(0)
movie.play()"""
"""import sys
import pygame as pg

pg.init()
pg.mixer.quit()

filename = 'Sample.mpg'
movie = pg.movie.Movie(filename)
w, h = [size*3 for size in movie.get_size()]
screen = pg.display.set_mode((w+10,h+10))
movie.set_display(screen, pg.Rect((5, 5), (w,h)))
movie.play()
clock = pg.time.Clock()
done = False
while not done:
    for event in pg.event.get():
        if event.type == pg.QUIT:
            movie.stop()
            done = True
    pg.display.update()
    clock.tick(60.0)

pg.quit()
sys.exit()"""

