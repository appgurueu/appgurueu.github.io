# -*- coding: utf-8 -*-
from thread import start_new_thread
import thread
import pygame
import pygame.camera
import random
import os
import sys
from decimal import *
from pygame.locals import *
import pygame.gfxdraw
import math
from time import *
from datetime import datetime
import string
import pygame.tests
import socket
#import pygame.examples.scroll
#pygame.examples.scroll.main()
pygame.init()
import os
#os.environ['PYGAME_CAMERA'] = 'opencv'
"""try:
   pygame.tests.run()
except:
   print Error while testing PYGAME(Fehler beim PYGAME testen)"""
Quelle='192.168.1.55' # Adresse des eigenen Rechners
Port=2011
 
e_udp_sock = socket.socket( socket.AF_INET,  socket.SOCK_DGRAM ) #s.o.
#e_udp_sock.bind( (Quelle,Port) )

def entfernung(p1,p2):
    xe=p1[0]+p2[0]
    ye=p1[1]+p2[1]
    return math.sqrt((xe*xe)+(ye*ye))   
   
def connect(ziel,nachricht,typei):
   Ziel='192.168.1.55'
   # Die Konstante AF_INET steht für Adressfamilie Internet.
   # Die Konstante SOCK_DGRAM steht für das UDP-Protokoll.
   # Dies sind optionale Eingaben für eine Socket-Instanz. 
   # Voreingestellt ist AF_INET und als Protokoll SockStream, dies steht für
   # ein TPC-socket
   if "start" in typei:
      nachricht="Hallo TransferOnLars!"
   s_udp_sock = socket.socket( socket.AF_INET,  socket.SOCK_DGRAM )
   print "Nachricht:", nachricht
   s_udp_sock.sendto( nachricht, (Ziel,Port) )
print '########Dies ist der Empfänger########'    
print 'Neue Verbindung:'
print 'Quelle',Quelle
print 'Port=',Port
 
 
 
 
def empfange():
     #Im IP-Adresse und Port werden
                    # durch bind miteinander verknüpft.
   print '########Dies ist der Empfänger########'    
   print 'Neue Verbindung:'
   print 'Quelle',Quelle
   print 'Port=',Port                                     # Endlosschleife
   data, addr = e_udp_sock.recvfrom( 8192 )# Puffer-Größe ist 1024 Bytes. 
                            # Die Puffergröße muss immer eine Potenz
                            # von 2 sein
   print "empfangene Nachricht:", data
   if "Hallo Defender!" in data:
      print "Verbindungsanfrage von ",addr
   print "Clientadresse:", addr          # Adresse besteht aus IP und Port
   return data,addr
#while True:
#   print empfange()
def explosioni():
   #try:
   #   pygame.mixer.music.load()
   #   pygame.mixer.music.play()
   #except:
   #   True
   True
def wurmen(altpos,neupos):
   if altpos>=neupos:
      abstandx=altpos[0]-neupos[0]
   else:
      abstandx=neupos[0]-altpos[0]
   if altpos>=neupos:
      abstandy=altpos[1]-neupos[1]
   else:
      abstandy=neupos[1]-altpos[1]
   energieverbrauch=math.sqrt((abstandx*abstandx)+(abstandy*abstandy))
   return energieverbrauch
def durchschnittsfarbe(farbe1,farbe2,farbe3,farbe4):
   fw1=farbe1[0]+farbe2[0]+farbe3[0]+farbe4[0]/4
   fw2=farbe1[1]+farbe2[1]+farbe3[1]+farbe4[1]/4
   fw3=farbe1[2]+farbe2[2]+farbe3[2]+farbe4[2]/4
   farbsetwert=(fw1,fw2,fw3)
   return farbsetwert
def scale(faktor,surface,zielsurface):
   for x in range(button.get_rect().width):
      for y in range(button.get_rect().height):
         si=button.get_at((x,y))
         zielsurface.set_at((x,y),(si[0]+50,si[1]+50,si[2]+50,se))
def box(s,r,f):
   pygame.gfxdraw.hline(s,r.x,r.x+r.width,r.y,(f))
   pygame.gfxdraw.hline(s,r.x,r.x+r.width,r.y+r.height,(f))
   pygame.gfxdraw.vline(s,r.x,r.y,r.y++r.height,(f))
   pygame.gfxdraw.vline(s,r.x+r.width,r.y,r.y+r.height,(f))
def fullscreen(wert,aufloesung):
    if wert == True :
       #pygame.display.toggle_fullscreen()
       screen=pygame.display.set_mode((800,400),pygame.FULLSCREEN)
    else :
       #pygame.display.toggle_fullscreen()
       screen=pygame.display.set_mode(aufloesung,pygame.RESIZABLE)
zeit1=int(round(time()))
#a=pygame.cursors.load_xbm("SpaceBattle/Cursor/m.xbm","SpaceBattle/Cursor/mk.xbm")ame.
#pygame.mouse.set_cursor(*a)
def gravity(cp1,cp2,obj):
    entfernung=math.sqrt(((cp1[0]-cp2[0])*(cp1[0]-cp2[0]))+((cp1[1]-cp2[1])*(cp1[1]-cp2[1])))
    if "erde" in obj:
       anziehung=98.1/(entfernung+1)
    if "mond" in obj:
       anziehung=15.0/(entfernung+1)
    if "asteroide" in obj:
       anziehung=7.0/(entfernung+1)
    return round((cp1[0]-cp2[0])*(anziehung/(entfernung+1))),round((cp1[1]-cp2[1])*(anziehung/(entfernung+1)))
def oncircle(mp,pos,radius):
    if pos[0]>=mp[0]:
       x2=pos[0]-mp[0]
    else:
       x2=mp[0]-pos[0]
    if pos[1]>=mp[1]:
       y2=pos[1]-mp[1]
    else:
       y2=mp[1]-pos[1]
    #x2=mp[0]-pos[0]
    #y2=mp[1]-pos[1]
    ss=math.sqrt((x2*x2)+(y2*y2))
    if ss<=radius:
       return True
def crcollide(recter,radius,cp):
   rw=int(recter.width)
   if recter.width>=recter.height:
      x1=recter.center[0]-cp[0]
      y1=recter.center[1]-cp[1]
      strecke=math.sqrt((x1*x1+y1*y1))
      if strecke>=-(recter.height+radius) and strecke<=recter.height+radius:
         return True
   if not recter.width>=recter.height:
      x1=recter.center[0]-cp[0]
      y1=recter.center[1]-cp[1]
      strecke=math.sqrt((x1*x1+y1*y1))
   if strecke>=-(rw+radius) and strecke<=rw+radius:
      return True
def shot(p1,p2):
    pe=p1
    p1=p2
    p2=pe
    startpos=p1
    endpos=p2
    #if startpos[0]>=endpos[0]:
    m1=startpos[0]-endpos[0]#ar-mr
    m2=startpos[1]-endpos[1]
    while m1 >= 5 or m2 >= 5:
       m1/=2
       m2/=2
    return round(m1),round(m2),math.sqrt((round(m1)*round(m1)+round(m2)*round(m2)))/10
def amaterieshot(p1,p2):
    pe=p1
    p1=p2
    p2=pe
    startpos=p1
    endpos=p2
    #if startpos[0]>=endpos[0]:
    m1=startpos[0]-endpos[0]#ar-mr
    m2=startpos[1]-endpos[1]
    m1*=30
    m2*=30
    while m1 >= 30 or m2 >= 30:
       m1/=1.1
       m2/=1.1
    return round(m1),round(m2),math.sqrt((round(m1)*round(m1)+round(m2)*round(m2)))/10
def plasmashot(p1,p2):
    pe=p1
    p1=p2
    p2=pe
    startpos=p1
    endpos=p2
    #if startpos[0]>=endpos[0]:
    m1=startpos[0]-endpos[0]#ar-mr
    m2=startpos[1]-endpos[1]
    m1*=30
    m2*=30
    while m1 >=  35 or m2 >= 35:
       m1/=1.1
       m2/=1.1
    return round(m1),round(m2),math.sqrt((round(m1)*round(m1)+round(m2)*round(m2)))/10
def lichtshot(p1,p2):
    pe=p1
    p1=p2
    p2=pe
    endpos=p1
    startpos=p2
    #if startpos[0]>=endpos[0]:
    m1=startpos[0]-endpos[0]#ar-mr
    m2=startpos[1]-endpos[1]
    m1*=30
    m2*=30
    while m1 >=  20 or m2 >= 20:
       m1/=1.1
       m2/=1.1
    return round(m1),round(m2),math.sqrt((round(m1)*round(m1)+round(m2)*round(m2)))/10
def elektronenshot(p1,p2):
    pe=p1
    p1=p2
    p2=pe
    startpos=p1
    endpos=p2
    #if startpos[0]>=endpos[0]:
    m1=startpos[0]-endpos[0]#ar-mr
    m2=startpos[1]-endpos[1]
    m1*=30
    m2*=30
    while m1 >=  35 or m2 >= 35:
       m1/=1.1
       m2/=1.1
    return round(m1),round(m2),math.sqrt((round(m1)*round(m1)+round(m2)*round(m2)))/10
def startpos(width,height):
    seite=random.choice((1,2,3,4))
    if seite==1:
       px=0-width
       py=random.randint(0,800-height)
    if seite==2:
       py=800-height
       px=random.randint(0,800-width)
    if seite==3:
       px=800
       py=random.randint(0,800-height)
    if seite==4:
       py=0-height
       px=random.randint(0,800-width)
    return px,py
def ccollide(pos1,pos2,rad1,rad2):
    x2=pos1[0]-pos2[0]
    y2=pos1[1]-pos2[1]
    ss=math.sqrt(x2*x2+y2*y2)
    if ss<=rad1+rad2 and ss>=-(rad1+rad2):
       return True
    else :
       return False
#def crcollide(rect,radius,cp):
##    rw=rect.width
#    rh=rect.height
#    rect.center=rect.x+rw/2,rect.y-rh/2
#    try:
#       for x in (rect.x,rect.x+rw):
#          ss=math.sqrt((cp[0]*x)+(cp[1]*rect.y))
#          if ss<=radius and ss>=int(radius-radius*2):
#             return True
#       for x in (rect.x,rect.x+rw):
#          ss=math.sqrt((cp[0]*x)+(cp[1]*(rect.y+rh)))
#          if ss<=radius and ss>=int(radius-radius*2):
#             return True
#       for y in (rect.y,rect.y+rh):
#          ss=math.sqrt((cp[0]*rect.x)+(cp[1]*y))
#          if ss<=radius and ss>=int(radius-radius*2):
#             return True
#       for x in (rect.x,rect.y+rh):
#          ss=math.sqrt((cp[0]*(rect.x+rw))+(cp[1]*y))
#          if ss<=radius and ss>=int(radius-radius*2):
#             return True
#    except:True
    #cp[0]=cp[0]-rect.center.x,cp[1]-rect.center.y
    #ss=math.sqrt(cp[0]+radius*cp[0]+radius+cp[1]+radius*cp[1]+radius)
    #if ss<=32 and ss>=-32:
    #   return True
    #else :
    #   return False
def translate(stringi,sprache):
   if "Englisch" in sprache:
      if "Einstellungen" in stringi:
         return stringi.replace("Einstellungen","Configs")
      if "Beenden" in stringi:
         return stringi.replace("Beenden","Exit")
      if "Anleitung" in stringi:
         return stringi.replace("Anleitung","Manual")
      if "Lautstaerke" in stringi:
         return stringi.replace("Lautstaerke","Tone")
      if "Steuerung" in stringi:
         return stringi.replace("Steuerung","Input")
      if "Sprache" in stringi:
         return stringi.replace("Sprache","Language")
      if "Zeit" in stringi:
         return stringi.replace("Zeit","Time")
      if "Energie" in stringi:
         return stringi.replace("Energie","Energy")
      if "Wiederholen" in stringi:
         return stringi.replace("Wiederholen","Return")
      if "Menue" in stringi:
         return stringi.replace("Menue","Menu")
      if "Laedt" in stringi:
         return stringi.replace("Laedt","Loading")
   if "Franzoesisch" in sprache:
      if "Einstellungen" in stringi:
         return stringi.replace("Einstellungen","Parametres")
      if "Beenden" in stringi:
         return stringi.replace("Beenden","Quittez")
      if "Anleitung" in stringi:
         return stringi.replace("Anleitung","Instructions")
      if "Lautstaerke" in stringi:
         return stringi.replace("Lautstaerke","Volume")
      if "Steuerung" in stringi:
         return stringi.replace("Steuerung","Controle")
      if "Sprache" in stringi:
         return stringi.replace("Sprache","Langue")
      if "Zeit" in stringi:
         return stringi.replace("Zeit","Temps")
      if "Energie" in stringi:
         return stringi.replace("Energie","Energie")
      if "Wiederholen" in stringi:
         return stringi.replace("Wiederholen","Repetition")
      if "Menue" in stringi:
         return stringi.replace("Menue","Menu")
      if "Laedt" in stringi:
         return stringi.replace("Laedt","Charger")
   if "Ruemanisch" in sprache:
      if "Einstellungen" in stringi:
         return stringi.replace("Einstellungen","Setari")
      if "Beenden" in stringi:
         return stringi.replace("Beenden","Lesire")
      if "Anleitung" in stringi:
         return stringi.replace("Anleitung","Instructiuni")
      if "Lautstaerke" in stringi:
         return stringi.replace("Lautstaerke","Volum")
      if "Steuerung" in stringi:
         return stringi.replace("Steuerung","Controle")
      if "Sprache" in stringi:
         return stringi.replace("Sprache","Limba")
      if "Zeit" in stringi:
         return stringi.replace("Zeit","Timp")
      if "Energie" in stringi:
         return stringi.replace("Energie","Energie")
      if "Wiederholen" in stringi:
         return stringi.replace("Wiederholen","Repeta")
      if "Menue" in stringi:
         return stringi.replace("Menue","Meniu")
      if "Laedt" in stringi:
         return stringi.replace("Laedt","Incarca")
   if "Deutsch" in sprache:
      return stringi
def goi():
   clock = pygame.time.Clock()
   screen=pygame.display.set_mode((800,800))
   gof = pygame.font.Font('fm.ttf', 100)
   gs = gof.render('Game', True, (255,255,255))
   os = gof.render('Over', True,(255,255,255))
   gr = gs.get_rect()
   orr = os.get_rect()
   gr.midtop = (800 / 2, 10)
   orr.midtop = (800 / 2, gr.height + 10 + 25)
   #screen.fill((0,0,0))
   screen.blit(gs, gr)
   screen.blit(os, orr)
   pygame.display.update()
   pygame.time.wait(500)
   #raumschiff=pygame.image.load("SpaceBattle/Raumschiff des Spielers.png")
def zpos():
   return random.randint(0, 750),random.randint(0, 750)
def zges():
   return random.randint(-10, 10),random.randint(-10, 10)
def alpharect(rect,colour,alpha):
   s = pygame.Surface((rect.width,rect.height)) 
   s.set_alpha(alpha)                
   s.fill(colour)           
   screen.blit(s, (rect.x,rect.y))
def zrot():
   return random.randint(1,360)
iWert=True
def main(introagain):
   iWert=True
   #Gesamte Bibliothek initialisieren
   pygame.init()
   #Scrollfaktoren
   scrollfaktorx=0
   scrollfaktory=0
   #FPS-Uhr
   clock = pygame.time.Clock()
   #Fenster
   print pygame.display.Info()
   bildschirmgroesse=pygame.display.Info().current_h,pygame.display.Info().current_w
   #if bildschirmgroesse[0]<=799:
   #   screen=pygame.display.set_mode((bildschirmgroesse[0],800),pygame.RESIZABLE)
   #   if bildschirmgroesse[1]<=799:
   #      screen=pygame.display.set_mode((bildschirmgroesse[0],bildschirmgroesse[1]-50),pygame.RESIZABLE)
   screen=pygame.display.set_mode((800,800),pygame.RESIZABLE)
   pygame.display.set_icon(pygame.image.load("Defender/defendericon5.png"))
   #Cursor(deaktiviert)
   a=pygame.cursors.load_xbm("Defender/fadenkreuz.xbm","Defender/fadenkreuz.xbm")
   pygame.mouse.set_cursor(*a)
   lb=pygame.image.load("Defender/ladebalken2.png")
   #lb=pygame.transform.flip(lb,False,True)
   lbh=pygame.image.load("Defender/ladebalken2hintergrund.png")
   lc1=pygame.image.load("Defender/loadcircle1.png")
   lc2=pygame.image.load("Defender/loadcircle2.png")
   lc3=pygame.image.load("Defender/loadcircle3.png")
   lc4=pygame.image.load("Defender/loadcircle4.png")
   lbrect=lb.get_rect()
   lbrect.x=0
   lbrect.y=400-19
   start=False
   def load(a,b):
      datei=open("Defender/sprache.txt","r")
      try:
         sprache=str(datei.read())
      except:
         sprache="Deutsch"
      datei.close()
      loa=1
      lspunkte=1
      font2 = pygame.font.Font("Defender/fm.ttf", 96)
      font2.set_underline(True)
      ueberschrift = font2.render("Defender", 100, (255,255,0))
      usrect=ueberschrift.get_rect()
      usrect.center=(400,48)
      font = pygame.font.Font("Defender/fm.ttf", 20)
      #font.set_underline(True)
      ladeschrift = font.render(translate("Laedt.",sprache), 100, (255,255,0))
      lsrect=ladeschrift.get_rect()
      lsrect.center=(400,440)
      pygame.mouse.set_visible(0)
      pygame.display.set_caption(translate("Defender:Laedt",sprache),translate("Defender:Laedt",sprache))
      while start==False:
         if lbrect.x <= 10:
            move=+20
         if lbrect.x >= 790-lbrect.width:
            move=-20
         lbrect.x+=move
         lbhrect=lbh.get_rect()
         lbhrect.center=(400,400)
         screen.fill((0,200,0))
         screen.blit(lbh,lbhrect)
         screen.blit(lb,lbrect)
         screen.blit(ueberschrift,usrect)
         screen.blit(ladeschrift,lsrect)
         for e in pygame.event.get():
            if e.type == pygame.QUIT:
               pygame.quit()
            if e.type == pygame.KEYDOWN:
               if e.key == K_ESCAPE:
                  pygame.quit()
         if loa==4:
            screen.blit(lc4,pygame.mouse.get_pos())
            loa=1
         if loa==3:
            screen.blit(lc3,pygame.mouse.get_pos())
            loa+=1
         if loa==2:
            screen.blit(lc2,pygame.mouse.get_pos())
            loa+=1
         if loa==1:
            screen.blit(lc1,pygame.mouse.get_pos())
            loa+=1
         if lspunkte==4:
            ladeschrift = font.render(translate("Laedt",sprache)+"...", 100, (255,255,0))
            lspunkte=0
         if lspunkte==3:
            ladeschrift = font.render(translate("Laedt",sprache)+"..", 100, (255,255,0))
         if lspunkte==2:
            ladeschrift = font.render(translate("Laedt",sprache)+".", 100, (255,255,0))
         if lspunkte==1:
            ladeschrift = font.render(translate("Laedt",sprache), 100, (255,255,0))
         lspunkte+=0.0625
         pygame.display.update()
         clock.tick(100)
   arg2=500,500
   thread.start_new_thread(load,arg2)
   #Bilder
   mausi = pygame.image.load(os.path.join("Defender/maus.png"))
   scrolling = pygame.image.load(os.path.join("Defender/scrolling.png"))
   scrolling0 = pygame.image.load(os.path.join("Defender/scrolling.png"))
   scrolling1 = pygame.image.load(os.path.join("Defender/scrolling.png"))
   scrolling2 = pygame.image.load(os.path.join("Defender/scrolling.png"))
   scrolling3 = pygame.image.load(os.path.join("Defender/scrolling.png"))
   scrolling4 = pygame.image.load(os.path.join("Defender/scrolling.png"))
   #Erde und Mond
   erde1 = pygame.image.load(os.path.join("Defender/erde1.png"))
   erde2 = pygame.image.load(os.path.join("Defender/erde2.png"))
   erde3 = pygame.image.load(os.path.join("Defender/erde3.png"))
   erde4 = pygame.image.load(os.path.join("Defender/erde4.png"))
   erde5 = pygame.image.load(os.path.join("Defender/erde5.png"))
   erde6 = pygame.image.load(os.path.join("Defender/erde6.png"))
   erde7 = pygame.image.load(os.path.join("Defender/erde7.png"))
   erde8 = pygame.image.load(os.path.join("Defender/erde8.png"))
   erde9 = pygame.image.load(os.path.join("Defender/erde9.png"))
   erde10 = pygame.image.load(os.path.join("Defender/erde10.png"))
   erde11 = pygame.image.load(os.path.join("Defender/erde11.png"))
   erde12 = pygame.image.load(os.path.join("Defender/erde12.png"))
   erde13 = pygame.image.load(os.path.join("Defender/erde13.png"))
   erde14 = pygame.image.load(os.path.join("Defender/erde14.png"))
   erde15 = pygame.image.load(os.path.join("Defender/erde15.png"))
   erde16 = pygame.image.load(os.path.join("Defender/erde16.png"))
   erde17 = pygame.image.load(os.path.join("Defender/erde17.png"))
   erde18 = pygame.image.load(os.path.join("Defender/erde18.png"))
   erde19 = pygame.image.load(os.path.join("Defender/erde19.png"))
   mond = pygame.image.load(os.path.join("Defender/mond.png"))
   #Raumschiffe,Satelliten und Co.
   iss=pygame.image.load(os.path.join("Defender/rs.png"))
   satellit=pygame.image.load(os.path.join("Defender/satellit.png"))
   abwehrsystem=pygame.image.load(os.path.join("Defender/abwehrsystem.png"))
   starship=random.choice(("Defender/defiant2","Defender/daedalus2","Defender/raumschiff2"))
   enterprise2=pygame.image.load(str(starship+".png"))
   enterprise=enterprise2
   enterprisemitschutzschild=pygame.image.load(str(starship+"mitschutzschild"+".png"))
   enterprisemitluke=pygame.image.load(str(starship+"mitluke"+".png"))
   ktinga=pygame.image.load("Defender/ktinga.png")
   birdofprey=pygame.image.load("Defender/birdofprey.png")
   #Asteroiden/Meteoriten
   asteroide1 = pygame.image.load(os.path.join("Defender/Asteroide1.png"))
   asteroide2 = pygame.image.load(os.path.join("Defender/Asteroide2.png"))
   asteroide3 = pygame.image.load(os.path.join("Defender/Asteroide3.png"))
   asteroide4 = pygame.image.load(os.path.join("Defender/Asteroide4.png"))
   asteroide1 = pygame.transform.rotate(asteroide1,zrot())
   asteroide2 = pygame.transform.rotate(asteroide2,zrot())
   asteroide3 = pygame.transform.rotate(asteroide3,zrot())
   asteroide4 = pygame.transform.rotate(asteroide4,zrot())
   #Antimaterie
   amaterie=pygame.image.load(os.path.join("Defender/amaterie.png"))
   #Explosionen
   explosion=pygame.image.load("Defender/Explosion.png")
   satellitexplosion=pygame.image.load("Defender/satellitexplosion.png")
   mondexplosion=pygame.image.load("Defender/mondexplosion.png")
   erdeexplosion=pygame.image.load("Defender/erdeexplosion.png")
   abwehrsystemexplosion=pygame.image.load("Defender/abwehrsystemexplosion.png")
   issexplosion=pygame.image.load("Defender/rsexplosion.png")
   asteroideexplosion=pygame.image.load("Defender/asteroideexplosion.png")
   #Hintergrundbild
   weltraum=pygame.image.load(random.choice(("Defender/m57.png","Defender/pferdekopfnebel.png","Defender/andromeda.png","Defender/krebsnebel.png","Defender/hantelnebel.png","Defender/m13.png","Defender/supernova.png","Defender/ngc604.png","Defender/ngc6369.png","Defender/up014624.png")))
   for x in range(weltraum.get_rect().width):
      for y in range(weltraum.get_rect().height):
         si4=weltraum.get_at((x,y))
         if si4[0]==166 and si4[1]==185 and si4[2]==255:
            weltraum.set_at((x,y),(si4[0]+1,si4[1]+1,si4[2]+1,255))
            print ; "Fuckooooooooooooooooooooooooooooooooooooooooooov!"
   #Button
   button=pygame.image.load("Defender/button.png")
   button2=pygame.image.load("Defender/button.png")
   buttonc=pygame.image.load("Defender/buttonconnect.png")
   buttonc2=pygame.image.load("Defender/buttonconnect.png")
   buttonglanz=pygame.image.load("Defender/buttonglanz.png")
   buttonglanz2=pygame.image.load("Defender/buttonglanz.png")
   #Energiepaketbilder
   epaket1=pygame.image.load("Defender/energiepaket.png")
   epaket2=pygame.image.load("Defender/energiepaket2.png")
   epaket=epaket1
   #
   plasma=pygame.image.load("Defender/plasmapaket.png")
   licht=pygame.image.load("Defender/lichtpaket.png")
   lichtpaket=pygame.image.load("Defender/lichtpaket.png")
   lichtpaketlight=pygame.image.load("Defender/lichtpaketlight.png")
   #licht=pygame.image.load("Defender/antimateriepaket.png")
   #lichtpaket=pygame.image.load("Defender/antimateriepaket.png")
   #lichtpaketlight=pygame.image.load("Defender/antimateriepaketlight.png")
   licht=pygame.image.load("Defender/r2paket.png")
   lichtpaket=pygame.image.load("Defender/r2paket.png")
   lichtpaketlight=pygame.image.load("Defender/r2light.png")
   elektronen=pygame.image.load("Defender/elektronenpaket.png")
   #Menübuttons
   menubuttonen=pygame.image.load("Defender/menubuttonen.png")
   menubuttonru=pygame.image.load("Defender/menubuttonru.png")
   menubuttonde=pygame.image.load("Defender/menubuttonde.png")
   menubuttonenmo=pygame.image.load("Defender/menubuttonen.png")
   menubuttonrumo=pygame.image.load("Defender/menubuttonru.png")
   menubuttondemo=pygame.image.load("Defender/menubuttonde.png")
   #Logos
   logo1=pygame.image.load("Defender/defenderlogo4.png")
   logo2=pygame.image.load("Defender/defenderlogo3.png")
   plogo=pygame.image.load("Defender/pausiert.png")
   joystick=pygame.image.load("Defender/joystick.png")
   tastatur=pygame.image.load("Defender/keyboard.png")
   maus=pygame.image.load("Defender/mouse.png")
   deutsch=pygame.image.load("Defender/deutsch.png")
   englisch=pygame.image.load("Defender/englisch.png")
   ruemanisch=pygame.image.load("Defender/ruemaenien.png")
   franzoesisch=pygame.image.load("Defender/frankreich.png")
   ja=pygame.image.load("Defender/ja.png")
   nein=pygame.image.load("Defender/nein.png")
   highscore=pygame.image.load("Defender/highscore.png")
   #Smileys :-)
   smileyf=pygame.image.load("Defender/smileyfroehlich.png")
   smileyt=pygame.image.load("Defender/smileytraurig.png")
   smileym=pygame.image.load("Defender/smileymittel.png")
   #Buttons
   zeichen0=pygame.image.load("Defender/zeichen.png")
   zeichen=pygame.image.load("Defender/zeichen.png")
   zeichen1=pygame.image.load("Defender/zeichen.png")
   zeichen2=pygame.image.load("Defender/zeichen.png")
   zeichen3=pygame.image.load("Defender/zeichen.png")
   #Blitz
   blitz=pygame.image.load("Defender/blitz.png")
   #Tonlogos
   ton1=pygame.image.load("Defender/tonscaled.png")
   ton2=pygame.image.load("Defender/ton2scaled.png")
   ton3=pygame.image.load("Defender/ton3scaled.png")
   ton4=pygame.image.load("Defender/ton4scaled.png")
   ton=pygame.image.load("Defender/tonscaled.png")
   #Mixer initialisieren
   pygame.mixer.pre_init(frequency=22050, size=-16, channels=10)
   #pygame.mixer.init()
   #Töne
   gamesound="Defender/sounds/orion2.ogg"
   explosionsound="Defender/sounds/explosion.ogg"
   #Positionen und umfassende Rechtecke
   blitzrect=blitz.get_rect()
   blitzrect.x=128
   blitzrect.y=0
   erderect=erde1.get_rect()
   erderect.center=(400,400)
   amaterierect=amaterie.get_rect()
   amaterierect.center=(10,10)
   mondrect=mond.get_rect()
   mondrect.center=(400,200)
   issrect=iss.get_rect()
   issrect.center=(400,300)
   zeichenrect=zeichen.get_rect()
   zeichenrect.y=0
   zeichenrect.x=740
   exitlogorect=Rect((0,740),(20,20))
   maximierenlogorect=Rect((0,760),(20,20))
   minimierenlogorect=Rect((0,780),(20,20))
   scrollingrect=scrolling.get_rect()
   scrollingrect.y=0
   scrollingrect.x=571
   leftrect=Rect((0,571),(20,20))
   uprect=Rect((0,591),(20,20))
   downrect=Rect((0,611),(20,20))
   rightrect=Rect((0,631),(20,20))
   satellitrect=satellit.get_rect()
   satellitrect2=satellit.get_rect()
   abwehrsystemrect=abwehrsystem.get_rect()
   zeichenrect=Rect(740,0,60,20)
   lukeopos=(0,40)
   lukespos=(40,40)
   tonpos=719,0
   tonrect=Rect(719,0,11,20)
   menubuttonpos=659,2
   menubuttonrect=Rect(659,0,50,16)
   faserpos=(0,66)
   ptpos=(40,66)
   zeichenpos=(740,0)
   raumschiffpos=10,10
   epos=startpos(epaket.get_rect().width,epaket.get_rect().height)
   apos1=startpos(asteroide1.get_rect().width,asteroide1.get_rect().height)
   apos2=startpos(asteroide2.get_rect().width,asteroide2.get_rect().height)
   apos3=startpos(asteroide3.get_rect().width,asteroide3.get_rect().height)
   apos4=startpos(asteroide4.get_rect().width,asteroide4.get_rect().height)
   #Bewegung der Asteroiden auslosen
   ages1=zges()[0],zges()[1]
   ages2=zges()[0],zges()[1]
   ages3=zges()[0],zges()[1]
   ages4=zges()[0],zges()[1]
   #Bewegung der anderen Schiffe
   kges=zges()[0],zges()[1]
   bges=zges()[0],zges()[1]
   ktinga=pygame.transform.rotate(ktinga,(270-math.atan2(kges[1],kges[0])*180/math.pi))
   birdofprey=pygame.transform.rotate(birdofprey,(270-math.atan2(bges[1],bges[0])*180/math.pi))
   ktingapos=startpos(ktinga.get_rect().width,ktinga.get_rect().height)
   birdofpreypos=startpos(birdofprey.get_rect().width,birdofprey.get_rect().height)
   #Bewegung des Energiepaketes auslosen
   eges=zges()[0],zges()[1]
   #Aktuelles Bild der Erde
   ebild=1
   #Anfangswinkel
   be=0
   be2=123
   be3=312
   be4=270
   be5=120
   introrot=0
   #Spielzeit
   zeit1=time()
   #Energie
   energie=100
   #Bools
   satellitexplo=False
   satellitexplo2=False
   truevar=True
   d=False
   el=True
   schuss=False
   schutzschild=False
   luke=False
   fullscreeninfo=False
   if introagain==True:
      introd=False
   else:
      introd=True
   anleitung=False
   b1=False
   b2=False
   b3=False
   b4=False
   pausiert=False
   einstellungen=False
   aktiviert=False
   aktiviert2=False
   aktiviert3=False
   aktiviert4=False
   pbild=True
   highscorebroken=False
   epaket1=True
   a1e=False
   a2e=False
   a3e=False
   a4e=False
   tonaus=False
   menubuttonmo=False
   #Bilder erzeugen
   photonentorpedos = []
   """for photonentorp in photonentorpedos:
       photonentorp[0]+=photonentorp[5]
       photonentorp[1]+=photonentorp[6]
       ptorect=Rect(photonentorp[0,photonentorp[1],photonentorp[2],photonentorp[3])
       if ptorect.colliderect(abwehrsystemrect)==True:
          go=True
          photonentorpedos.pop(photonentorp)
       if ptorect.colliderect(erderect)==True:
          go=True
          photonentorpedos.pop(photonentorp)
       if photonentorp[0] >=800 or photonentorp[1] >=800 or photonentorp[0] <= 0-photonentorp[3] or photonentorp[1] <= 0-photonentorp[4]:
          photonentorpedos.pop(photonentorp)
       screen.blit(lichtpaket,lichtpaketrect)"""
   """for x in range(lukeo2.get_rect().width):
      for y in range(lukeo2.get_rect().height):
         si4=lukeo2.get_at((x,y))
         sw=round((si4[0]+si4[1]+si4[2])/3)
         if not si4[3]==0:
            lukeo2.set_at((x,y),(sw,sw,sw,255))"""
   for x in range(button.get_rect().width):
      for y in range(button.get_rect().height):
         si=button.get_at((x,y))
         se=si[3]-(si[3]/2)
         button2.set_at((x,y),(si[0]+50,si[1]+50,si[2]+50,se))
   for x in range(menubuttonde.get_rect().width):
      for y in range(menubuttonde.get_rect().height):
         si=menubuttonde.get_at((x,y))
         se=si[3]-(si[3]/2)
         menubuttondemo.set_at((x,y),(si[0],si[1],si[2],se))
   for x in range(menubuttonde.get_rect().width):
      for y in range(menubuttonde.get_rect().height):
         si=menubuttonen.get_at((x,y))
         se=si[3]-(si[3]/2)
         menubuttonenmo.set_at((x,y),(si[0],si[1],si[2],se))
   for x in range(menubuttonde.get_rect().width):
      for y in range(menubuttonde.get_rect().height):
         si=menubuttonru.get_at((x,y))
         se=si[3]-(si[3]/2)
         menubuttonrumo.set_at((x,y),(si[0],si[1],si[2],se))
   for x in range(highscore.get_rect().width):
      for y in range(highscore.get_rect().height):
         si=highscore.get_at((x,y))
         se=si[3]-(si[3]/2)
         highscore.set_at((x,y),(si[0],si[1],si[2],se))
   for x in range(0,20):
      for y in range(0,20):
         si=zeichen.get_at((x,y))
         se=si[3]-(si[3]/2)
         zeichen1.set_at((x,y),(si[0],si[1],si[2],se))
   for x in range(20,40):
      for y in range(0,20):
         si=zeichen.get_at((x,y))
         se=si[3]-(si[3]/2)
         zeichen2.set_at((x,y),(si[0],si[1],si[2],se))
   for x in range(40,60):
      for y in range(0,20):
         si=zeichen.get_at((x,y))
         se=si[3]-(si[3]/2)
         zeichen3.set_at((x,y),(si[0],si[1],si[2],se))
   #
   for x in range(0,20):
      for y in range(0,20):
         si=scrolling.get_at((x,y))
         se=si[3]-(si[3]/2)
         scrolling1.set_at((x,y),(si[0],si[1],si[2],se))
   for x in range(20,40):
      for y in range(0,20):
         si=scrolling.get_at((x,y))
         se=si[3]-(si[3]/2)
         scrolling2.set_at((x,y),(si[0],si[1],si[2],se))
   for x in range(40,60):
      for y in range(0,20):
         si=scrolling.get_at((x,y))
         se=si[3]-(si[3]/2)
         scrolling3.set_at((x,y),(si[0],si[1],si[2],se))
   for x in range(60,80):
      for y in range(0,20):
         si=scrolling.get_at((x,y))
         se=si[3]-(si[3]/2)
         scrolling4.set_at((x,y),(si[0],si[1],si[2],se))
   #muster=pygame.image.load("Muster/muster_rot.png")
   #muster2=pygame.image.load("Muster/muster_rot.png")
   #for x in range(0,338):
   #   for y in range(0,338):
   #      muster2.set_at((x,y),(muster.get_at((x,y))[2],muster.get_at((x,y))[0],muster.get_at((x,y))[2],255))
   #pygame.image.save(muster2,"Muster/muster_aaaarolett.png")
   #Joysticks checken
   joystick_count = pygame.joystick.get_count()
   #try:
   pygame.camera.init()
   #cameralist=pygame.camera.list_cameras()[0]
   #camera=pygame.camera.Camera(camera,(400,400))
   if iWert==True:
      try:
         cam = pygame.camera.Camera("/dev/video0",(800,450))
         cam.start()
         image = cam.get_image()
         pygame.image.save(image,"Defender/gamer.png")
         actgamer=pygame.image.load("Defender/gamer.png")
         scaled_gamer=pygame.transform.scale(actgamer,(128,96))
         cam.stop()
         enterbyhand=False
      except:
         try:
            camlist = pygame.camera.list_cameras()
            if camlist:
               cam = pygame.camera.Camera(camlist[0],(640,480))
               cam.start()
               image = cam.get_image()
               pygame.image.save(image,"Defender/gamer.png")
               actgamer=pygame.image.load("Defender/gamer.png")
               scaled_gamer=pygame.transform.scale(actgamer,(128,96))
               cam.stop()
               enterbyhand=False
         except:
             enterbyhand=True
             print ; "NO V4L2 COMPATIBLE CAM!"
   #enterbyhand=True
   iWert=False
   pygame.camera.quit()
   #except:
   #   print "Keine Kamera!"
   #print ("Es sind/ist", joystick_count, "Joystick/s vorhanden")
   starttextcolour=255,255,0
   anleitungtextcolour=255,255,0
   exittextcolour=255,255,0
   etextcolour=255,255,0
   lstextcolour=255,255,0
   stextcolour=255,255,0
   ltextcolour=255,255,0
   itextcolour=255,255,0
   datei=open("Defender/highscore.txt","r")
   try:
      hs=int(datei.read())
   except:
      hs=0
   datei.close()
   datei=open("Defender/steuerung.txt","r")
   try:
      steuerung=str(datei.read())
   except:
      steuerung="Maus"
   datei.close()
   datei=open("Defender/sprache.txt","r")
   try:
      sprache=str(datei.read())
   except:
      sprache="Deutsch"
   datei.close()
   if "Maus" in steuerung:
      mcolour=0,0,255
      tcolour=255,255,0
      jcolour=255,255,0
   if "Tastatur" in steuerung:
      mcolour=255,255,0
      tcolour=0,0,255
      jcolour=255,255,0
   if "Joystick" in steuerung:
      mcolour=255,255,0
      tcolour=255,255,0
      jcolour=0,0,255
   if "Deutsch" in sprache:
      rcolour=255,255,0
      fcolour=255,255,0
      encolour=255,255,0
      decolour=0,0,255
   if "Englisch" in sprache:
      rcolour=255,255,0
      fcolour=255,255,0
      encolour=0,0,255
      decolour=255,255,0
   if "Ruemanisch" in sprache:
      rcolour=0,0,255
      fcolour=255,255,0
      encolour=255,255,0
      decolour=255,255,0
   if "Franzoesisch" in sprache:
      rcolour=255,255,0
      fcolour=0,0,255
      encolour=255,255,0
      decolour=255,255,0
   datei=open("Defender/infos.txt","r")
   try:
      if "False" in datei.read():
         info=False
      else:
         info=True
   except:
      info=True
   datei.close()
   if info==False:
      ncolour=0,0,255
      jacolour=255,255,0
   else:
      ncolour=255,255,0
      jacolour=0,0,255
   level=1
   alinie=0
   lstartpos=(0,100)
   datei=open("Defender/lautstaerke.txt","r")
   try:
      ls=str(int(datei.read()))
   except:
      ls="0"
   datei.close()
   datei=open("Defender/screenshot.txt","r")
   try:
      screenshot=int(datei.read())
   except:
      screenshot=0
   datei.close()
   print ; "START"
   start=True
   pygame.display.set_caption("Defender:Intro","Defender:Intro")
   mauskursor=pygame.cursors.load_xbm("Defender/mausweiss2.xbm","Defender/mausschwarz.xbm")
   pygame.mouse.set_cursor(*mauskursor)
   while introd==False:
      #image = cam.get_image()
      #gamingstar=pygame.transform.scale(image,(40,56))
      #gamingstar=image
      drauf=False
      joysticks = pygame.joystick.get_count()
      pygame.mouse.set_visible(1)
      font = pygame.font.Font("Defender/fm.ttf", 17)
      font2 = pygame.font.Font("Defender/fm.ttf", 96)
      font2.set_underline(True)
      ueberschrift = font2.render("Defender", 100, (255,255,0))
      text = font.render("Start >>", 100, (starttextcolour))
      text2 = font.render(translate("Anleitung >>",sprache), 100, (anleitungtextcolour))
      text3 = font.render(translate("Beenden >>",sprache), 100, (exittextcolour))
      text4 = font.render(translate("Einstellungen >>",sprache), 100, (etextcolour))
      usrect=ueberschrift.get_rect()
      usrect.center=(400,48)
      startrect=text.get_rect()
      startrect.center=(400,390)
      b1rect=button.get_rect()
      b2rect=button.get_rect()
      b3rect=button.get_rect()
      b4rect=button.get_rect()
      b1rect.center=(400,390)
      b2rect.center=(400,420)
      b3rect.center=(400,360)
      b4rect.center=(400,330)
      anleitungrect=text2.get_rect()
      anleitungrect.center=(400,420)
      exitrect=text3.get_rect()
      exitrect.center=(400,360)
      eirect=text4.get_rect()
      eirect.center=(400,330)
      pressed=pygame.mouse.get_pressed()
      pos = pygame.mouse.get_pos()[0]+(scrollfaktorx-scrollfaktorx*2),pygame.mouse.get_pos()[1]+(scrollfaktory-scrollfaktory*2)
      pi=math.pi
      try :
         rgr=raumschiff.get_rect()
      except :
         rgr=enterprise.get_rect()
      d2=pi/180
      h=200
      b=200
      xi=400
      yi=400
      introrot+=2
      if be==360:
         be=0
      rgr.center=(int(xi+math.cos(introrot*d2)*b),int(yi-math.sin(introrot*d2)*h))
      raumschiff = pygame.transform.rotate(enterprise,introrot)
      for e in pygame.event.get():
         if e.type == pygame.QUIT:
            pygame.quit()
            d=True
            introd=True
         if e.type == pygame.KEYDOWN:
            if e.key == K_RETURN:
               introd=True
            if e.key==K_u:
               scrollfaktory-=1
            if e.key==K_d:
               scrollfaktory+=1
            if e.key==K_r:
               scrollfaktorx+=1
            if e.key==K_l:
               scrollfaktorx-=1
            if aktiviert==True:
               if e.key == K_1:
                  ls=ls+"1"
               if e.key == K_2:
                  ls=ls+"2"
               if e.key == K_3:
                  ls=ls+"3"
               if e.key == K_4:
                  ls=ls+"4"
               if e.key == K_5:
                  ls=ls+"5"
               if e.key == K_6:
                  ls=ls+"6"
               if e.key == K_7:
                  ls=ls+"7"
               if e.key == K_8:
                  ls=ls+"8"
               if e.key == K_9:
                  ls=ls+"9"
               if e.key == K_0:
                  ls=ls+"0"
               if e.key == K_DELETE:
                  ls="0"
            if e.key==K_b:
               pygame.image.save(screen,"Defender/Screenshots/Screenshot"+str(screenshot)+".png")
               screenshot+=1
               print ; "Screenshot"
               screen.fill((255,255,255))
      if int(ls) >= 101 :
         ls="0"
      if b3rect.collidepoint(pos)==True:
         exittextcolour=255,0,0
         b2=True
         if pressed[0]==True or pressed[1]==True or pressed[2]==True:
            datei=open("Defender/steuerung.txt","w")
            datei.write(str(steuerung))
            datei.close()
            datei=open("Defender/sprache.txt","w")
            datei.write(str(sprache))
            datei.close()
            datei=open("Defender/lautstaerke.txt","w")
            datei.write(str(ls))
            datei.close()
            datei=open("Defender/infos.txt","w")
            datei.write(str(info))
            datei.close()
            datei=open("Defender/screenshot.txt","w")
            datei.write(str(screenshot))
            datei.close()
            exittextcolour=0,0,255
            introd=True
            pygame.quit()
      else:
         exittextcolour=255,255,0
         b2=False
      if menubuttonrect.collidepoint(pos)==True:
         menubuttonmo=True
         if pressed[0]==True or pressed[1]==True or pressed[2]==True:
            True
      else:
         menubuttonmo=False
      if b1rect.collidepoint(pos)==True:
         starttextcolour=255,0,0
         b1=True
         if pressed[0]==True or pressed[1]==True or pressed[2]==True:
            starttextcolour=0,0,255
            introd=True
      else:
         starttextcolour=255,255,0
         b1=False
      if b4rect.collidepoint(pos)==True:
         etextcolour=255,0,0
         b4=True
         if pressed[0]==True or pressed[1]==True or pressed[2]==True:
            etextcolour=0,0,255
            if einstellungen==False:
               einstellungen=True
            anleitung=False
            #else:
            #   einstellungen=False
      else:
         etextcolour=255,255,0
         b4=False
      if b2rect.collidepoint(pos)==True:
         anleitungtextcolour=255,0,0
         b3=True
         if pressed[0]==True or pressed[1]==True or pressed[2]==True:
            anleitungtextcolour=0,0,255
            if anleitung==False:
               anleitung=True
            einstellungen=False
            #else:
            #   anleitung=False
      else:
         anleitungtextcolour=255,255,0
         b3=False
      screen.fill((255,255,255))
      screen.blit(weltraum,(0,0))
      if b1==True:
         screen.blit(button2,b1rect)
      else:
         screen.blit(button,b1rect)
      if b3==True:
         screen.blit(button2,b2rect)
      else:
         screen.blit(button,b2rect)
      if b2==True:
         screen.blit(button2,b3rect)
      else:
         screen.blit(button,b3rect)
      if b4==True:
         screen.blit(button2,b4rect)
      else:
         screen.blit(button,b4rect)
      if tonrect.collidepoint(pos)==True:
         ton=ton2
         if tonaus==True:
            ton=ton4
         if pressed[0]==True or pressed[1]==True or pressed[2]==True:
            if tonaus==False:
               ton=ton4
               tonaus=True
            else:
               ton=ton2
               tonaus=False
      else:
         ton=ton1
         if tonaus==True:
            ton=ton3
      if zeichenrect.collidepoint(pos)==True :
         if oncircle((750,10),pos,10)==True:
            zeichen=zeichen1
            drauf=True
            if pressed[0]==True or pressed[1]==True or pressed[2]==True:
               datei=open("Defender/steuerung.txt","w")
               datei.write(str(steuerung))
               datei.close()
               datei=open("Defender/sprache.txt","w")
               datei.write(str(sprache))
               datei.close()
               datei=open("Defender/lautstaerke.txt","w")
               datei.write(str(ls))
               datei.close()
               datei=open("Defender/infos.txt","w")
               datei.write(str(info))
               datei.close()
               datei=open("Defender/screenshot.txt","w")
               datei.write(str(screenshot))
               datei.close()
               introd=True
               pygame.quit()
         if oncircle((770,10),pos,10)==True:
            zeichen=zeichen2
            drauf=True
            if pressed[0]==True or pressed[1]==True or pressed[2]==True:
               pygame.display.iconify()
         if oncircle((790,10),pos,10)==True:
            zeichen=zeichen3
            drauf=True
            if pressed[0]==True or pressed[1]==True or pressed[2]==True:
               if fullscreeninfo==False:
                  fullscreen(True,(800,800))
               else:
                  fullscreeninfo(False,(800,800))
      if drauf==False:
         zeichen=zeichen0
      draufscrolling=False
      #scrollingrect.y=0
      #scrollingrect.x=571
      #scrollingrect.y+=scrollfaktory
      #scrollingrect.x+=scrollfaktorx
      #if scrollingrect.collidepoint(pos)==True :
      if 1==1:
         if oncircle((581-scrollfaktorx,10-scrollfaktory),pos,10)==True:
            scrolling=scrolling1
            draufscrolling=True
            if pressed[0]==True or pressed[1]==True or pressed[2]==True:
               scrollfaktorx-=1
         if oncircle((601-scrollfaktorx,10-scrollfaktory),pos,10)==True:
            scrolling=scrolling2
            draufscrolling=True
            if pressed[0]==True or pressed[1]==True or pressed[2]==True:
               scrollfaktory-=1
         if oncircle((621-scrollfaktorx,10-scrollfaktory),pos,10)==True:
            scrolling=scrolling3
            draufscrolling=True
            if pressed[0]==True or pressed[1]==True or pressed[2]==True:
               scrollfaktory+=1
         if oncircle((641-scrollfaktorx,10-scrollfaktory),pos,10)==True:
            scrolling=scrolling4
            draufscrolling=True
            if pressed[0]==True or pressed[1]==True or pressed[2]==True:
               scrollfaktorx+=1
      if draufscrolling==False:
         scrolling=scrolling0
      #scrollingrect.y=0
      #scrollingrect.x=571
      screen.blit(raumschiff,rgr)
      if anleitung==True:
         if "Englisch" in sprache:
            for line in open("Defender/enanleitung.txt","r") :
                 alinie+=1
                 font = pygame.font.Font("Defender/fm.ttf", 14)
                 aline = font.render(line.rstrip(), 100, (255,255,0))
                 for x in range(aline.get_rect().width):
                     for y in range(aline.get_rect().height):
                        si=aline.get_at((x,y))
                        se=si[3]-(si[3]/2)
                        aline.set_at((x,y),(si[0],si[1],si[2],se))
                 screen.blit(aline,(lstartpos[0],lstartpos[1]+(14*alinie)))
            screen.blit(epaket,(125,188))
            screen.blit(abwehrsystem,(195,193))
            screen.blit(amaterie,(135,218))
            if alinie == 19 :
               alinie=0
         if "Deutsch" in sprache:
            for line in open("Defender/anleitung.txt","r") :
                 alinie+=1
                 font = pygame.font.Font("Defender/fm.ttf", 14)
                 aline = font.render(line.rstrip(), 100, (255,255,0))
                 for x in range(aline.get_rect().width):
                     for y in range(aline.get_rect().height):
                        si=aline.get_at((x,y))
                        se=si[3]-(si[3]/2)
                        aline.set_at((x,y),(si[0],si[1],si[2],se))
                 screen.blit(aline,(lstartpos[0],lstartpos[1]+(14*alinie)))
            screen.blit(epaket,(110,188))
            screen.blit(abwehrsystem,(140,193))
            screen.blit(amaterie,(135,218))
            if alinie == 21 :
               alinie=0
      if blitzrect.collidepoint(pos)==True and enterbyhand==False:
         if pressed[1] ==True or pressed[0]==True or pressed[2]==True:
            #try:
            #pygame.camera.quit()
            #pygame.camera.init()
            cam = pygame.camera.Camera("/dev/video0",(800,450))
            cam.start()
            image = cam.get_image()
            pygame.image.save(image,"Defender/gamer.png")
            actgamer=pygame.image.load("Defender/gamer.png")
            scaled_gamer=pygame.transform.scale(actgamer,(128,96))
            cam.stop()
            #except:
               #print "NO CAM"
      if enterbyhand==False:
         screen.blit(blitz,blitzrect)
      if einstellungen==True:
         font = pygame.font.Font("Defender/fm.ttf", 14)
         lstext = font.render(translate("Lautstaerke : ",sprache)+ls, 100, (lstextcolour))
         stext = font.render(translate("Steuerung : ",sprache), 100, (stextcolour))
         ltext = font.render(translate("Sprache : ",sprache), 100, (ltextcolour))
         itext = font.render("Infos : ", 100, (itextcolour))
         if aktiviert==True:
            lstextcolour=0,0,255
            lstext = font.render(translate("Lautstaerke : ",sprache)+ls+"|", 100, (lstextcolour))
         if aktiviert2==True:
            stextcolour=0,0,255
            stext = font.render(translate("Steuerung : ",sprache), 100, (stextcolour))
            if mausrect.collidepoint(pos)==True:
               if not "Maus" in steuerung:
                  mcolour=255,0,0
               if pressed[0]==True or pressed[1]==True or pressed[2]==True:
                  steuerung="Maus"
                  mcolour=0,0,255
            else:
               if not "Maus" in steuerung:
                  mcolour=255,255,0
            if tastaturrect.collidepoint(pos)==True:
               if not "Tastatur" in steuerung:
                  tcolour=255,0,0
               if pressed[0]==True or pressed[1]==True or pressed[2]==True:
                  steuerung="Tastatur"
                  tcolour=0,0,255
            else:
               if not "Tastatur" in steuerung:
                  tcolour=255,255,0
            if joysticks>=1:
               if joystickrect.collidepoint(pos)==True:
                  if not "Joystick" in steuerung:
                     jcolour=255,0,0
                  if pressed[0]==True or pressed[1]==True or pressed[2]==True:
                     steuerung="Joystick"
                     jcolour=0,0,255
               else:
                  if not "Joystick" in steuerung:
                     jcolour=255,255,0
         mausrect=maus.get_rect()
         mausrect.center=(200,130)
         tastaturrect=tastatur.get_rect()
         tastaturrect.center=(222,130)
         if joysticks>=1:
            joystickrect=joystick.get_rect()
            joystickrect.center=(244,130)
         screen.blit(maus,mausrect)
         screen.blit(tastatur,tastaturrect)
         if joysticks>=1:
            screen.blit(joystick,joystickrect)
         box(screen,mausrect,(mcolour))
         box(screen,tastaturrect,(tcolour))
         if joysticks>=1:
            box(screen,joystickrect,(jcolour))
         if aktiviert3==True:
            ltextcolour=0,0,255
            ltext = font.render(translate("Sprache : ",sprache), 100, (ltextcolour))
            if deutschrect.collidepoint(pos)==True:
               if not "Deutsch" in sprache:
                  decolour=255,0,0
               if pressed[0]==True or pressed[1]==True or pressed[2]==True:
                  sprache="Deutsch"
                  decolour=0,0,255
            else:
               if not "Deutsch" in sprache:
                  decolour=255,255,0
            if englischrect.collidepoint(pos)==True:
               if not "Englisch" in sprache:
                  encolour=255,0,0
               if pressed[0]==True or pressed[1]==True or pressed[2]==True:
                  sprache="Englisch"
                  encolour=0,0,255
            else:
               if not "Englisch" in sprache:
                  encolour=255,255,0
         if aktiviert4==True:
            itextcolour=0,0,255
            itext = font.render("Infos : ", 100, (itextcolour))
            if jarect.collidepoint(pos)==True:
               if info==False:
                  jacolour=255,0,0
               if pressed[0]==True or pressed[1]==True or pressed[2]==True:
                  info=True
                  jacolour=0,0,255
            else:
               if info==False:
                  jacolour=255,255,0
            if neinrect.collidepoint(pos)==True:
               if info==True:
                  ncolour=255,0,0
               if pressed[0]==True or pressed[1]==True or pressed[2]==True:
                  info=False
                  ncolour=0,0,255
            else:
               if info==True:
                  ncolour=255,255,0 
         deutschrect=deutsch.get_rect()
         deutschrect.center=(200,160)
         englischrect=deutsch.get_rect()
         englischrect.center=(222,160)
         screen.blit(deutsch,deutschrect)
         screen.blit(scaled_gamer,(0,0))
         screen.blit(englisch,englischrect)
         box(screen,deutschrect,(decolour))
         box(screen,englischrect,(encolour))
         jarect=deutsch.get_rect()
         jarect.center=(200,190)
         neinrect=deutsch.get_rect()
         neinrect.center=(222,190)
         screen.blit(ja,jarect)
         screen.blit(nein,neinrect)
         box(screen,neinrect,(ncolour))
         box(screen,jarect,(jacolour))
         lstextrect=lstext.get_rect()
         lstextrect.center=(100,100)
         stextrect=stext.get_rect()
         stextrect.center=(100,130)
         ltextrect=ltext.get_rect()
         ltextrect.center=(100,160)
         itextrect=itext.get_rect()
         itextrect.center=(100,190)
         if lstextrect.collidepoint(pos)==True:
            lstextcolour=255,0,0
            if pressed[0]==True or pressed[1]==True or pressed[2]==True:
               if aktiviert==False:
                  aktiviert=True
                  aktiviert2=False
                  aktiviert3=False
                  aktiviert4=False
               #else:
               #   aktiviert=False
         else:
            lstextcolour=255,255,0
         screen.blit(lstext,lstextrect)
         if itextrect.collidepoint(pos)==True:
            itextcolour=255,0,0
            if pressed[0]==True or pressed[1]==True or pressed[2]==True:
               if aktiviert4==False:
                  aktiviert4=True
                  aktiviert=False
                  aktiviert2=False
                  aktiviert3=False
               #else:
               #   aktiviert=False
         else:
            itextcolour=255,255,0
         screen.blit(itext,itextrect)
         if stextrect.collidepoint(pos)==True:
            stextcolour=255,0,0
            if pressed[0]==True or pressed[1]==True or pressed[2]==True:
               if aktiviert2==False:
                  aktiviert2=True
                  aktiviert=False
                  aktiviert3=False
                  aktiviert4=False
               #else:
               #   aktiviert2=False
         else:
            stextcolour=255,255,0
         screen.blit(stext,stextrect)
         if ltextrect.collidepoint(pos)==True:
            ltextcolour=255,0,0
            if pressed[0]==True or pressed[1]==True or pressed[2]==True:
               if aktiviert3==False:
                  aktiviert3=True
                  aktiviert=False
                  aktiviert2=False
                  aktiviert4=False
               #else:
               #   aktiviert2=False
         else:
            ltextcolour=255,255,0
         screen.blit(ltext,ltextrect)
      if info==True:
         font = pygame.font.Font("Defender/fm.ttf", 14)
         hstext = font.render("Highscore : "+str(hs), 100, (255,255,0))
         hstextrect=hstext.get_rect()
         hstextrect.center=(700,100)
         screen.blit(hstext,hstextrect)
         hstext = font.render(str(screenshot)+" Screenshots", 100, (255,255,0))
         hstextrect=hstext.get_rect()
         hstextrect.center=(700,130)
         screen.blit(hstext,hstextrect)
      #screen.blit(gamingstar,(0,0))
      screen.blit(text,startrect)
      screen.blit(text2,anleitungrect)
      screen.blit(text3,exitrect)
      screen.blit(text4,eirect)
      screen.blit(logo2,(0,744))
      screen.blit(logo1,(700,744))
      screen.blit(ueberschrift,usrect)
      screen.blit(scaled_gamer,(0,0))
      box(screen,startrect,(starttextcolour))
      box(screen,exitrect,(exittextcolour))
      box(screen,anleitungrect,(anleitungtextcolour))
      box(screen,eirect,(etextcolour))
      screen.blit(zeichen,zeichenrect)
      screen.blit(ton,tonpos)
      if "Deutsch" in sprache:
         if menubuttonmo==False:
            screen.blit(menubuttonde,menubuttonpos)
         if menubuttonmo==True:
            screen.blit(menubuttondemo,menubuttonpos)
      if "Englisch" in sprache or "Franzoesisch" in sprache:
         if menubuttonmo==False:
            screen.blit(menubuttonen,menubuttonpos)
         if menubuttonmo==True:
            screen.blit(menubuttonenmo,menubuttonpos)
      if "Ruemaenisch" in sprache:
         if menubuttonmo==False:
            screen.blit(menubuttonru,menubuttonpos)
         if menubuttonmo==True:
            screen.blit(menubuttonrumo,menubuttonpos)
      screen.scroll(scrollfaktorx,scrollfaktory)
      screen.blit(scrolling,scrollingrect)
      #screen.blit(mausi,pos)
      pygame.display.update()
      pygame.display.flip()
      isi=100
      clock.tick(isi)
      #if tonaus==True:
      #   pygame.mixer.music.set_volume(0)
      #else:
      #   pygame.mixer.music.set_volume(ls)
   #Spielmusik wiedergeben
   pygame.mixer.music.load(open(gamesound,"rb"))
   pygame.mixer.music.set_volume(int(ls))
   pygame.mixer.music.play(3600)
   pygame.mouse.set_visible(0)
   jpos=100,100
   pygame.mouse.set_pos(jpos)
   if "Joystick" in steuerung:
      joystick = pygame.joystick.Joystick(0)
      joystick.init()
   datei=open("Defender/steuerung.txt","w")
   datei.write(str(steuerung))
   datei.close()
   datei=open("Defender/sprache.txt","w")
   datei.write(str(sprache))
   datei.close()
   datei=open("Defender/lautstaerke.txt","w")
   datei.write(str(ls))
   datei.close()
   datei=open("Defender/infos.txt","w")
   datei.write(str(info))
   datei.close()
   datei=open("Defender/screenshot.txt","w")
   datei.write(str(screenshot))
   datei.close()
   pygame.display.set_caption("Defender","Defender")
   while  d==False:
      if "Joystick" in steuerung:
         joysticks = pygame.joystick.get_count()
         if not joysticks>=1:
            steuerung="Maus"
      a1rect=Rect(apos1,(asteroide1.get_rect().width,asteroide1.get_rect().height))
      a2rect=Rect(apos2,(asteroide2.get_rect().width,asteroide2.get_rect().height))
      a3rect=Rect(apos3,(asteroide3.get_rect().width,asteroide3.get_rect().height))
      a4rect=Rect(apos4,(asteroide4.get_rect().width,asteroide4.get_rect().height))
      epaketrect=Rect(epos,(epaket.get_rect().width,epaket.get_rect().height))
      zeit2=time()
      szeit=zeit2-zeit1
      pos = pygame.mouse.get_pos()[0]+12,pygame.mouse.get_pos()[1]+12
      if "Maus" in steuerung:
         jpos=pos
      if "Joystick" in steuerung:
         ys = joystick.get_axis(1)
         xs = joystick.get_axis(0)
         jpos=jpos[0]+(xs*100),jpos[1]+(ys*100)
      for e in pygame.event.get():
         if e.type == pygame.QUIT:
            if highscorebroken==True:
               datei=open("Defender/highscore.txt","w")
               datei.write(str(szeit))
               datei.close()
            d=True
            pygame.quit()
         if e.type == pygame.KEYDOWN:
            if "Tastatur" in steuerung:
               if e.key==K_LEFT:
                  jpos=jpos[0]-50,jpos[1]
               if e.key==K_UP:
                  jpos=jpos[0],jpos[1]-50
               if e.key==K_RIGHT:
                  jpos=jpos[0]+50,jpos[1]
               if e.key==K_DOWN:
                  jpos=jpos[0],jpos[1]+50
            if e.key == K_ESCAPE:
               if highscorebroken==True:
                  datei=open("Defender/highscore.txt","w")
                  datei.write(str(szeit))
                  datei.close()
               d=True
               pygame.quit()
            if e.key==K_b:
               pygame.image.save(screen,"Defender/Screenshots/Screenshot"+str(screenshot)+".png")
               screenshot+=1
               print ; "Screenshot"
               screen.fill((255,255,255))
            if e.key == K_SPACE:
               pausiert=True
               az1=time()#Anfang----az1=Pausieren---------------az2Weiter--------------------------Jetzt
               pygame.mixer.pause()
               pygame.mouse.set_visible(1)
               while pausiert==True:
                  for e in pygame.event.get():
                     if e.type == pygame.KEYDOWN:
                        if e.key == K_SPACE:
                           pausiert=False
                        if e.key == K_ESCAPE:
                           d=True
                           pygame.quit()
                  drauf=False
                  pressed=pygame.mouse.get_pressed()
                  if tonrect.collidepoint(pos)==True:
                     ton=ton2
                     if tonaus==True:
                        ton=ton4
                     if pressed[0]==True or pressed[1]==True or pressed[2]==True:
                        if tonaus==False:
                           ton=ton4
                           tonaus=True
                        else:
                           ton=ton2
                           tonaus=False
                  else:
                     ton=ton1
                  if tonaus==True:
                     ton=ton3
                  if menubuttonrect.collidepoint(pos)==True:
                     menubuttonmo=True
                     if pressed[0]==True or pressed[1]==True or pressed[2]==True:
                        True
                  else:
                     menubuttonmo=False
                  if zeichenrect.collidepoint(pos)==True :
                     if oncircle((750,10),pos,10)==True:
                        zeichen=zeichen1
                        drauf=True
                        if pressed[0]==True or pressed[1]==True or pressed[2]==True:
                           if highscorebroken==True:
                              datei=open("Defender/highscore.txt","w")
                              datei.write(str(szeit))
                              datei.close()
                           d=True
                           pygame.quit()
                     if oncircle((770,10),pos,10)==True:
                        zeichen=zeichen2
                        drauf=True
                        if pressed[0]==True or pressed[1]==True or pressed[2]==True:
                           fullscreen(False,(800,800))
                     if oncircle((790,10),pos,10)==True:
                        zeichen=zeichen3
                        drauf=True
                        if pressed[0]==True or pressed[1]==True or pressed[2]==True:
                           fullscreen(True,(800,800))
                  if drauf==False:
                     zeichen=zeichen0
                  #screen.fill((255,255,255,0))
                  #zeit1+=az1-szeit
                  if pbild==True:
                     screen.blit(plogo,(0,0))
                  pbild=False
                  pygame.display.update()
                  pygame.display.flip()
                  isi=100
                  clock.tick(isi)
               az2=time()
               zeit1+=az2-az1
            pygame.mouse.set_visible(0)
            pygame.mixer.unpause()
            pbild=True
            #if e.key == K_a:
            #   schuss=True
            #   movepos=amaterieshot((raumschiffpos[0]+(rgr.width/2),raumschiffpos[1]+(rgr.height/2)),pos)[0],amaterieshot((raumschiffpos[0]+(rgr.width/2),raumschiffpos[1]+(rgr.height/2)),pos)[1]
            if e.key == K_s:
               if schutzschild==False:
                  schutzschild=True
               else:
                  schutzschild=False
            if e.key == K_p:
               photonentorp = [(raumschiffpos[0]+(rgr.width/2)),(raumschiffpos[1]+(rgr.height/2)),lichtpaket.get_width(),lichtpaket.get_height(),lichtshot((pos),((raumschiffpos[0]+(rgr.width/2)),(raumschiffpos[1]+(rgr.height/2))))[0],lichtshot((pos),((raumschiffpos[0]+(rgr.width/2)),(raumschiffpos[1]+(rgr.height/2))))[1]]
               photonentorpedos.append(photonentorp)
               energie-=0.1
            if e.key == K_l:
               if luke==False:
                  luke=True
               else:
                  luke=False
            if e.key == K_t:
               a=pygame.cursors.load_xbm("Defender/wurmloch.xbm","Defender/wurmloch.xbm")
               pygame.mouse.set_cursor(*a)
               pygame.mouse.set_visible(1)
               az1=time()
               pausiert=True
               while pausiert==True:
                  for e in pygame.event.get():
                      if e.type==pygame.KEYDOWN:
                         if e.key == K_SPACE:
                            pausiert=False
                         if e.key == K_ESCAPE:
                            d=True
                            pygame.quit()
                      pressed=pygame.mouse.get_pressed()
                      if pressed[0]==True or pressed[1]==True or pressed[2]==True:
                         pausiert=False
                         energie-=wurmen(raumschiffpos,pygame.mouse.get_pos())/100
                         raumschiffpos=pygame.mouse.get_pos()
                  pygame.display.update()
                  pygame.display.flip()
                  isi=100
                  clock.tick(isi)
               az2=time()
               zeit1+=az2-az1
               a=pygame.cursors.load_xbm("Defender/fadenkreuz.xbm","Defender/fadenkreuz.xbm")
               pygame.mouse.set_cursor(*a)
               pygame.mouse.set_visible(0)
      drauf=False
      pressed=pygame.mouse.get_pressed()
      if zeichenrect.collidepoint(pos)==True :
         if oncircle((750,10),pos,10)==True:
            zeichen=zeichen1
            drauf=True
            if pressed[0]==True or pressed[1]==True or pressed[2]==True:
               if highscorebroken==True:
                  datei=open("Defender/highscore.txt","w")
                  datei.write(str(szeit))
                  datei.close()
               d=True
               pygame.quit()
         if oncircle((770,10),pos,10)==True:
            zeichen=zeichen2
            drauf=True
            if pressed[0]==True or pressed[1]==True or pressed[2]==True:
               fullscreen(False,(800,800))
         if oncircle((790,10),pos,10)==True:
            zeichen=zeichen3
            drauf=True
            if pressed[0]==True or pressed[1]==True or pressed[2]==True:
               fullscreen(True,(800,800))
      if drauf==False:
         zeichen=zeichen0
      pi=math.pi
      try :
         rgr=raumschiff.get_rect()
      except :
         rgr=enterprise.get_rect()
      if schuss==True:
         amaterierect.center=(amaterierect.center[0]+raumschiffpos[0]+movepos[0],amaterierect.center[1]+raumschiffpos[1]+movepos[1])
         xp=int(amaterierect.x)
         yp=int(amaterierect.y)
         if xp >=800 or yp >=800 or xp <= -5 or yp <= -5 :
            schuss=False
      else:
         amaterierect.center=(raumschiffpos[0]+(rgr.width/2),raumschiffpos[1]+(rgr.height/2))
      d2=pi/180
      h=200
      b=200
      xi=400
      yi=400
      be+=2
      if be==360:
         be=0
      mondrect.center=(int(xi+math.cos(be*d2)*b),int(yi-math.sin(be*d2)*h))
      h=550/2
      b=150
      xi=400
      yi=400
      be2+=2
      if be2==360:
         be2=0
      issrect.center=(int(xi+math.cos(be2*d2)*b),int(yi-math.sin(be2*d2)*h))
      h=45
      b=45
      xi=mondrect.center[0]
      yi=mondrect.center[1]
      be3+=2
      if be3==360:
         be3=0
      satellitrect.center=(int(xi+math.cos(be3*d2)*b),int(yi-math.sin(be3*d2)*h))
      h=200
      b=300
      xi=400
      yi=400
      be4+=2
      if be4==360:
         be4=0
      abwehrsystemrect.center=(int(xi+math.cos(round(be4)*d2)*b),int(yi-math.sin(round(be4)*d2)*h))#
      h=360
      b=360
      xi=400
      yi=400
      be5+=2
      if be5==360:
         be5=0
      satellitrect2.center=(int(xi+math.cos(be5*d2)*b),int(yi-math.sin(be5*d2)*h))
      if ebild==1:
         erde=erde1
      if ebild==2:
         erde=erde2
      if ebild==3:
         erde=erde3
      if ebild==4:
         erde=erde4
      if ebild==5:
         erde=erde5
      if ebild==6:
         erde=erde6
      if ebild==7:
         erde=erde7
      if ebild==8:
         erde=erde8
      if ebild==9:
         erde=erde9
      if ebild==10:
         erde=erde10
      if ebild==11:
         erde=erde11
      if ebild==12:
         erde=erde12
      if ebild==13:
         erde=erde13
      if ebild==14:
         erde=erde14
      if ebild==15:
         erde=erde15
      if ebild==16:
         erde=erde16
      if ebild==17:
         erde=erde17
      if ebild==18:
         erde=erde18
      if ebild==19:
         erde=erde19
      ebild+=1
      if ebild==19:
         ebild=1
      if epaket1==True:
         epaket1=False
      else:
         epaket1=True
      if epaket1==True:
         epaket=pygame.image.load("Defender/energiepaket.png")
      if epaket1==False:
         epaket=pygame.image.load("Defender/energiepaket2.png")
      if pygame.mouse.get_pressed()[0]==True:
         photonentorp = [(raumschiffpos[0]+(rgr.width/2)),(raumschiffpos[1]+(rgr.height/2)),lichtpaket.get_width(),lichtpaket.get_height(),lichtshot((pos),((raumschiffpos[0]+(rgr.width/2)),(raumschiffpos[1]+(rgr.height/2))))[0],lichtshot((pos),((raumschiffpos[0]+(rgr.width/2)),(raumschiffpos[1]+(rgr.height/2))))[1]]
         photonentorpedos.append(photonentorp)
         energie-=0.1
      for x in range(int(raumschiffpos[0]),int((raumschiffpos[0]+rgr.width-1))):
          for y in range(int(raumschiffpos[1]),int(raumschiffpos[1]+rgr.height-1)):
              if luke==True:
                 try:
                    if screen.get_at((x,y))[0]<=150 and screen.get_at((x,y))[0]>=100 and screen.get_at((x,y))[1]<=150 and screen.get_at((x,y))[1]>=100 and screen.get_at((x,y))[2]<=150 and screen.get_at((x,y))[2]>=100 :
                    #if screen.get_at((x,y))[3]>=200 and (screen.get_at((x-1,y))[3]<=150 or screen.get_at((x+1,y))[3]<=150 or screen.get_at((x,y-1))[3]<=150 or screen.get_at((x,y+1))[3]<=150):
                       if epaketrect.collidepoint(x,y)==True:
                          energie+=100
                          epos=startpos(epaket.get_rect().width,epaket.get_rect().height)
                          eges=zges()[0],zges()[1]
                 except:True
              #if screen.get_at((x,y))[0]<=150 and screen.get_at((x,y))[0]>=100 and screen.get_at((x,y))[1]<=150 and screen.get_at((x,y))[1]>=100 and screen.get_at((x,y))[2]<=150 and screen.get_at((x,y))[2]>=100 :
              try:
                 if screen.get_at((x,y))[0]<=150 and screen.get_at((x,y))[0]>=100 and screen.get_at((x,y))[1]<=150 and screen.get_at((x,y))[1]>=100 and screen.get_at((x,y))[2]<=150 and screen.get_at((x,y))[2]>=100 :
                 #if screen.get_at((x,y))[3]>=200 and (screen.get_at((x-1,y))[3]<=150 or screen.get_at((x+1,y))[3]<=150 or screen.get_at((x,y-1))[3]<=150 or screen.get_at((x,y+1))[3]<=150):
                    if mondrect.collidepoint(x,y)==True:
                       if oncircle((mondrect.center),(x,y),23)==True:
                          d=True
                          mond=mondexplosion
                          explosioni()
                    if erderect.collidepoint(x,y)==True:
                       if oncircle((x,y),(400,400),90)==True:
                          d=True
                          erde=erdeexplosion
                          explosioni()
                    if epaketrect.collidepoint(x,y)==True:
                       if schutzschild==False:
                          d=True
                       epos=900,900
                       explosioni()
                    if satellitrect.collidepoint(x,y)==True:
                       d=True
                       satellitexplo=True
                       explosioni()
                    if satellitrect2.collidepoint(x,y)==True:
                       d=True
                       satellitexplo2=True
                       explosioni()
                    if abwehrsystemrect.collidepoint(x,y)==True:
                       d=True
                       abwehrsystem=abwehrsystemexplosion
                       explosioni()
                    if schutzschild==False:
                       if a2rect.collidepoint(x,y)==True:
                          d=True
                          asteroide2=asteroideexplosion
                          a2e=True
                          explosioni()
                       if a1rect.collidepoint(x,y)==True:
                          d=True
                          asteroide1=asteroideexplosion
                          a1e=True
                          explosioni()
                       if a3rect.collidepoint(x,y)==True:
                          d=True
                          asteroide3=asteroideexplosion
                          a3e=True
                          explosioni()
                       if a4rect.collidepoint(x,y)==True:
                          d=True
                          asteroide4=asteroideexplosion
                          a4e=True
                          explosioni()
                    if schutzschild==True:
                       if a2rect.collidepoint(x,y)==True:
                          asteroide2=asteroideexplosion
                          a2e=True
                          explosioni()
                       if a1rect.collidepoint(x,y)==True:
                          asteroide1=asteroideexplosion
                          a1e=True
                          explosioni()
                       if a3rect.collidepoint(x,y)==True:
                          asteroide3=asteroideexplosion
                          a3e=True
                          explosioni()
                       if a4rect.collidepoint(x,y)==True:
                          asteroide4=asteroideexplosion
                          a4e=True
                          explosioni()
                    if issrect.collidepoint(x,y)==True:
                       if oncircle((x,y),(issrect.center),23)==True:
                          d=True
                          iss=issexplosion
                          explosioni()
              except:True
      
      if a1rect.colliderect(abwehrsystemrect):
         d=True
         abwehrsystem=abwehrsystemexplosion
         asteroide1=asteroideexplosion
         explosioni()
      if a2rect.colliderect(abwehrsystemrect):
         d=True
         abwehrsystem=abwehrsystemexplosion
         asteroide2=asteroideexplosion
         explosioni()
      if a3rect.colliderect(abwehrsystemrect):
         d=True
         abwehrsystem=abwehrsystemexplosion
         asteroide3=asteroideexplosion
         explosioni()
      if a4rect.colliderect(abwehrsystemrect):
         d=True
         abwehrsystem=abwehrsystemexplosion
         asteroide4=asteroideexplosion
         explosioni()
      if a1rect.colliderect(satellitrect):
         d=True
         satellitexplo=True
         asteroide1=asteroideexplosion
         explosioni()
      if a2rect.colliderect(satellitrect):
         d=True
         satellitexplo=True
         asteroide2=asteroideexplosion
         explosioni()
      if a3rect.colliderect(satellitrect):
         d=True
         satellitexplo=True
         asteroide3=asteroideexplosion
         explosioni()
      if a4rect.colliderect(satellitrect):
         d=True
         satellitexplo=True
         asteroide4=asteroideexplosion
         explosioni()
      if a1rect.colliderect(satellitrect2):
         d=True
         satellitexplo2=True
         asteroide1=asteroideexplosion
         explosioni()
      if a2rect.colliderect(satellitrect2):
         d=True
         satellitexplo2=True
         asteroide2=asteroideexplosion
         explosioni()
      if a3rect.colliderect(satellitrect2):
         d=True
         satellitexplo2=True
         asteroide3=asteroideexplosion
         explosioni()
      if a4rect.colliderect(satellitrect2):
         d=True
         satellitexplo2=True
         asteroide4=asteroideexplosion
         explosioni()
      #Kollisionen untereinander
      if a1rect.colliderect(a3rect)==True :
         asteroide1=asteroideexplosion
         asteroide3=asteroideexplosion
         a1e=True
         a3e=True
         explosioni()
      if a1rect.colliderect(a4rect)==True :
         asteroide1=asteroideexplosion
         asteroide4=asteroideexplosion
         a1e=True
         a4e=True
         explosioni()
      if a2rect.colliderect(a1rect)==True :
         asteroide1=asteroideexplosion
         asteroide2=asteroideexplosion
         a1e=True
         a2e=True
         explosioni()
      if a2rect.colliderect(a3rect)==True :
         asteroide3=asteroideexplosion
         asteroide2=asteroideexplosion
         a2e=True
         a3e=True
         explosioni()
      if a3rect.colliderect(a4rect)==True :
         asteroide4=asteroideexplosion
         asteroide3=asteroideexplosion
         a3e=True
         a4e=True
         explosioni()
      if a4rect.colliderect(a2rect)==True :
         asteroide4=asteroideexplosion
         asteroide2=asteroideexplosion
         a2e=True
         a4e=True
         explosioni()
      if luke==True:
         enterprise=enterprisemitluke
      if schutzschild==True:
         enterprise=enterprisemitschutzschild
         energie=energie-0.1
      if not luke==True and not schutzschild==True:
         enterprise=enterprise2
      try:
         lwinkel=winkel
         if not lwinkel==(270-math.atan2(jpos[1]-raumschiffpos[1]-(rgr.height/2),jpos[0]-raumschiffpos[0]-(rgr.width/2))*180/math.pi):
            if lwinkel>=(270-math.atan2(jpos[1]-raumschiffpos[1]-(rgr.height/2),jpos[0]-raumschiffpos[0]-(rgr.width/2))*180/math.pi):
               True
               aw=((lwinkel-(270-math.atan2(jpos[1]-raumschiffpos[1]-(rgr.height/2),jpos[0]-raumschiffpos[0]-(rgr.width/2))*180/math.pi))/1000)
               energie=energie-aw
            else:
               True
               energie=energie-(((270-math.atan2(pos[1]-raumschiffpos[1]-(rgr.height/2),pos[0]-raumschiffpos[0]-(rgr.width/2))*180/math.pi)-lwinkel)/1000)
      except :True
      winkel = 270-math.atan2(jpos[1]-raumschiffpos[1]-(rgr.height/2),jpos[0]-raumschiffpos[0]-(rgr.width/2))*180/math.pi
      raumschiffpos=raumschiffpos[0]+gravity(mondrect.center,(raumschiffpos[0]-(rgr.width/2),raumschiffpos[1]-(rgr.height/2)),"mond")[0],raumschiffpos[1]+gravity(mondrect.center,(raumschiffpos[0]-(rgr.width/2),raumschiffpos[1]-(rgr.height/2)),"mond")[1]
      raumschiffpos=raumschiffpos[0]+gravity(erderect.center,(raumschiffpos[0]-(rgr.width/2),raumschiffpos[1]-(rgr.height/2)),"erde")[0],raumschiffpos[1]+gravity(erderect.center,(raumschiffpos[0]-(rgr.width/2),raumschiffpos[1]-(rgr.height/2)),"erde")[1]
      raumschiffpos=raumschiffpos[0]+gravity((apos1[0]+asteroide1.get_rect().width,apos1[1]+asteroide1.get_rect().height),(raumschiffpos[0]-(rgr.width/2),raumschiffpos[1]-(rgr.height/2)),"asteroide")[0],raumschiffpos[1]+gravity((apos1[0]+asteroide1.get_rect().width,apos1[1]+asteroide1.get_rect().height),(raumschiffpos[0]-(rgr.width/2),raumschiffpos[1]-(rgr.height/2)),"asteroide")[1]
      raumschiffpos=raumschiffpos[0]+gravity((apos2[0]+asteroide2.get_rect().width,apos2[1]+asteroide2.get_rect().height),(raumschiffpos[0]-(rgr.width/2),raumschiffpos[1]-(rgr.height/2)),"asteroide")[0],raumschiffpos[1]+gravity((apos2[0]+asteroide2.get_rect().width,apos2[1]+asteroide2.get_rect().height),(raumschiffpos[0]-(rgr.width/2),raumschiffpos[1]-(rgr.height/2)),"asteroide")[1]
      raumschiffpos=raumschiffpos[0]+gravity((apos3[0]+asteroide3.get_rect().width,apos3[1]+asteroide3.get_rect().height),(raumschiffpos[0]-(rgr.width/2),raumschiffpos[1]-(rgr.height/2)),"asteroide")[0],raumschiffpos[1]+gravity((apos3[0]+asteroide3.get_rect().width,apos3[1]+asteroide3.get_rect().height),(raumschiffpos[0]-(rgr.width/2),raumschiffpos[1]-(rgr.height/2)),"asteroide")[1]
      raumschiffpos=raumschiffpos[0]+gravity((apos4[0]+asteroide4.get_rect().width,apos4[1]+asteroide4.get_rect().height),(raumschiffpos[0]-(rgr.width/2),raumschiffpos[1]-(rgr.height/2)),"asteroide")[0],raumschiffpos[1]+gravity((apos4[0]+asteroide4.get_rect().width,apos4[1]+asteroide4.get_rect().height),(raumschiffpos[0]-(rgr.width/2),raumschiffpos[1]-(rgr.height/2)),"asteroide")[1]
      raumschiff = pygame.transform.rotate(enterprise,winkel)
      apos1=apos1[0]+gravity(erderect.center,apos1,"erde")[0]+gravity(mondrect.center,apos1,"mond")[0],apos1[1]+gravity(erderect.center,apos1,"erde")[1]+gravity(mondrect.center,apos1,"mond")[1]
      apos2=apos2[0]+gravity(erderect.center,apos2,"erde")[0]+gravity(mondrect.center,apos2,"mond")[0],apos2[1]+gravity(erderect.center,apos2,"erde")[1]+gravity(mondrect.center,apos2,"mond")[1]
      apos3=apos3[0]+gravity(erderect.center,apos3,"erde")[0]+gravity(mondrect.center,apos3,"mond")[0],apos3[1]+gravity(erderect.center,apos3,"erde")[1]+gravity(mondrect.center,apos3,"mond")[1]
      apos4=apos4[0]+gravity(erderect.center,apos4,"erde")[0]+gravity(mondrect.center,apos4,"mond")[0],apos4[1]+gravity(erderect.center,apos4,"erde")[1]+gravity(mondrect.center,apos4,"mond")[1]
      screen.fill((255,255,255))
      screen.blit(weltraum,(0,0))
      if entfernung(abwehrsystemrect.center,a1rect.center)<=200:
         photonentorp = [abwehrsystemrect.center[0],abwehrsystemrect.center[1],lichtpaket.get_width(),lichtpaket.get_height(),lichtshot((abwehrsystemrect.center),())[0],lichtshot((pos),((raumschiffpos[0]+(rgr.width/2)),(raumschiffpos[1]+(rgr.height/2))))[1]]
         photonentorpedos.append(photonentorp)
      screen.blit(abwehrsystem,abwehrsystemrect)
      ptc=-1
      for photonentorp in photonentorpedos:
         ptc+=1
         photonentorp[0]+=photonentorp[4]
         photonentorp[1]+=photonentorp[5]
         ptorect=Rect(photonentorp[0]-(photonentorp[2]/2),photonentorp[1]-(photonentorp[3]/2),photonentorp[2],photonentorp[3])
         ptolightrect=Rect(photonentorp[0]-(14),photonentorp[1]-(14),28,28)
         if ptorect.colliderect(abwehrsystemrect)==True:
            go=True
            d=True
            abwehrsystem=abwehrsystemexplosion
            photonentorpedos.pop(ptc)
         if ptorect.colliderect(satellitrect)==True:
            go=True
            d=True
            satellitexplo=True
            photonentorpedos.pop(ptc)
         if ptorect.colliderect(satellitrect2)==True:
            go=True
            d=True
            satellitexplo2=True
            photonentorpedos.pop(ptc)
         if crcollide(ptorect,90,(400,400))==True:
            erde=erdeexplosion
            go=True
            d=True
            photonentorpedos.pop(ptc)
         if crcollide(ptorect,22,(issrect.center))==True:
            iss=issexplosion
            go=True
            d=True
            photonentorpedos.pop(ptc)
         if crcollide(ptorect,23,(mondrect.center))==True:
            mond=mondexplosion
            go=True
            d=True
            photonentorpedos.pop(ptc)
         if ptorect.colliderect(a1rect)==True:
            asteroide1=asteroideexplosion
            a1e=True
            #explosioni()
            photonentorpedos.pop(ptc)
         if ptorect.colliderect(a2rect)==True:
            asteroide2=asteroideexplosion
            a2e=True
            #explosioni()
            photonentorpedos.pop(ptc)
         if ptorect.colliderect(a3rect)==True:
            a3e=True
            asteroide3=asteroideexplosion
            a3e=True
            #explosioni()
            photonentorpedos.pop(ptc)
         if ptorect.colliderect(epaketrect):
            epos=900,900
            photonentorpedos.pop(ptc)
         if ptorect.colliderect(a4rect)==True:
            asteroide4=asteroideexplosion
            a4e=True
            #explosioni()
            photonentorpedos.pop(ptc)
         if photonentorp[0] >=800 or photonentorp[1] >=800 or photonentorp[0] <= 0-photonentorp[2] or photonentorp[1] <= 0-photonentorp[4]:
            photonentorpedos.pop(ptc)
         screen.blit(lichtpaketlight,ptolightrect)
         screen.blit(lichtpaket,ptorect)
      if epaketrect.colliderect(a1rect)==True:
         epos=900,900
         a1e=True
         explosioni()
      if epaketrect.colliderect(a2rect)==True:
         epos=900,900
         a2e=True
         explosioni()
      if epaketrect.colliderect(a3rect)==True:
         epos=900,900
         a3e=True
         explosioni()
      if epaketrect.colliderect(a4rect)==True:
         epos=900,900
         a4e=True
         explosioni()
      if crcollide(epaketrect,90,erderect.center)==True:
         d=True
         erde=erdeexplosion
         explosioni()
      if crcollide(epaketrect,23,mondrect.center)==True:
         d=True
         mond=mondexplosion
         explosioni()
      if crcollide(epaketrect,23,issrect.center)==True:
         d=True
         iss=issexplosion
         explosioni()
      if crcollide(a1rect,90,erderect.center)==True:
         d=True
         erde=erdeexplosion
         asteroide1=asteroideexplosion
         explosioni()
      if crcollide(a2rect,90,erderect.center)==True:
         d=True
         erde=erdeexplosion
         asteroide2=asteroideexplosion
         explosioni()
      if crcollide(a3rect,90,erderect.center)==True:
         d=True
         erde=erdeexplosion
         asteroide3=asteroideexplosion
         explosioni()
      if crcollide(a4rect,90,erderect.center)==True:
         d=True
         erde=erdeexplosion
         asteroide4=asteroideexplosion
         explosioni()
      if crcollide(a1rect,23,mondrect.center)==True:
         d=True
         mond=mondexplosion
         asteroide1=asteroideexplosion
         explosioni()
      if crcollide(a2rect,23,mondrect.center)==True:
         d=True
         mond=mondexplosion
         asteroide2=asteroideexplosion
         explosioni()
      if crcollide(a3rect,23,mondrect.center)==True:
         d=True
         mond=mondexplosion
         asteroide3=asteroideexplosion
         explosioni()
      if crcollide(a4rect,23,mondrect.center)==True:
         d=True
         mond=mondexplosion
         asteroide4=asteroideexplosion
         explosioni()
      if crcollide(a1rect,22,issrect.center)==True:
         d=True
         iss=issexplosion
         asteroide1=asteroideexplosion
         explosioni()
      if crcollide(a2rect,22,issrect.center)==True:
         d=True
         iss=issexplosion
         asteroide2=asteroideexplosion
         explosioni()
      if crcollide(a3rect,22,issrect.center)==True:
         d=True
         iss=issexplosion
         asteroide3=asteroideexplosion
         explosioni()
      if crcollide(a4rect,22,issrect.center)==True:
         d=True
         iss=issexplosion
         asteroide4=asteroideexplosion
         explosioni()
      #if not joystick_count == 0:
      #      ya = js.get_axis(1)
      #      xa = js.get_axis(0)
      #      raumschiffpos=(xa*400,ya*400)
      raumschiffpos=raumschiffpos[0]+shot(raumschiffpos,jpos)[0],raumschiffpos[1]+shot(raumschiffpos,jpos)[1]
      energie=energie-shot(raumschiffpos,jpos)[2]
      screen.blit(erde,erderect)
      screen.blit(zeichen,zeichenpos)
      screen.blit(mond,mondrect)
      screen.blit(iss,issrect)
      screen.blit(raumschiff,raumschiffpos)
      ktingapos=ktingapos[0]+kges[0],ktingapos[1]+kges[1]
      birdofpreypos=birdofpreypos[0]+bges[0],birdofpreypos[1]+bges[1]
      epos=epos[0]+eges[0],epos[1]+eges[1]
      apos1=apos1[0]+ages1[0],apos1[1]+ages1[1]
      apos2=apos2[0]+ages2[0],apos2[1]+ages2[1]
      apos3=apos3[0]+ages3[0],apos3[1]+ages3[1]
      apos4=apos4[0]+ages4[0],apos4[1]+ages4[1]
      screen.blit(asteroide1,apos1)
      screen.blit(asteroide2,apos2)
      screen.blit(asteroide3,apos3)
      screen.blit(asteroide4,apos4)
      screen.blit(epaket,epos)
      screen.blit(ktinga,ktingapos)
      screen.blit(birdofprey,birdofpreypos)
      screen.blit(ton,tonpos)
      aier3="""if tonaus==True:
         pygame.mixer.music.set_volume(0)
      else:
         pygame.mixer.music.set_volume(int(ls))"""
      if satellitexplo==False:
         screen.blit(satellit,satellitrect)
      else:
         screen.blit(satellitexplosion,satellitrect)
      if satellitexplo2==False:
         screen.blit(satellit,satellitrect2)
      else:
         screen.blit(satellitexplosion,satellitrect2)
      if a1e==True:
         apos1=900,900
         a1e=False
      if a2e==True:
         apos2=900,900
         a2e=False
      if a3e==True:
         apos3=900,900
         a3e=False
      if a4e==True:
         apos4=900,900
         a4e=False
      if apos1[0] >=800 or apos1[1] >=800 or apos1[0] <= 0-asteroide1.get_rect().width or apos1[1] <= 0-asteroide1.get_rect().height :
         apos1=startpos(asteroide1.get_rect().width,asteroide1.get_rect().height)
         ages1=zges()[0],zges()[1]
         asteroide1 = pygame.image.load(os.path.join("Defender/Asteroide1.png"))
         asteroide1 = pygame.transform.rotate(asteroide1,zrot())
      if apos2[0] >=800 or apos2[1] >=800 or apos2[0] <= 0-asteroide2.get_rect().width or apos2[1] <= 0-asteroide2.get_rect().height :
         apos2=startpos(asteroide2.get_rect().width,asteroide2.get_rect().height)
         ages2=zges()[0],zges()[1]
         asteroide2 = pygame.image.load(os.path.join("Defender/Asteroide2.png"))
         asteroide2 = pygame.transform.rotate(asteroide2,zrot())
      if apos3[0] >=800 or apos3[1] >=800 or apos3[0] <= 0-asteroide3.get_rect().width or apos3[1] <= 0-asteroide3.get_rect().height :
         apos3=startpos(asteroide3.get_rect().width,asteroide3.get_rect().height)
         ages3=zges()[0],zges()[1]
         asteroide3 = pygame.image.load(os.path.join("Defender/Asteroide3.png"))
         asteroide3 = pygame.transform.rotate(asteroide3,zrot())
      if apos4[0] >=800 or apos4[1] >=800 or apos4[0] <= 0-asteroide4.get_rect().width or apos4[1] <= 0-asteroide4.get_rect().height :
         apos4=startpos(asteroide4.get_rect().width,asteroide4.get_rect().height)
         ages4=zges()[0],zges()[1]
         asteroide4 = pygame.image.load(os.path.join("Defender/Asteroide4.png")) 
         asteroide4 = pygame.transform.rotate(asteroide4,zrot())
      if epos[0] >=800 or epos[1] >=800 or epos[0] <= 0-epaket.get_rect().width or epos[1] <= 0-epaket.get_rect().height :
         epos=startpos(epaket.get_rect().width,epaket.get_rect().height)
         eges=zges()[0],zges()[1]
      if ktingapos[0] >=800 or ktingapos[1] >=800 or ktingapos[0] <= 0-ktinga.get_rect().width or ktingapos[1] <= 0-ktinga.get_rect().height :
         kges=zges()[0],zges()[1]
         ktinga=pygame.image.load("Defender/ktinga.png")
         ktinga=pygame.transform.rotate(ktinga,(270-math.atan2(kges[1],kges[0])*180/math.pi))
         ktingapos=startpos(ktinga.get_rect().width,ktinga.get_rect().height)
      if birdofpreypos[0] >=800 or birdofpreypos[1] >=800 or birdofpreypos[0] <= 0-birdofprey.get_rect().width or birdofpreypos[1] <= 0-birdofprey.get_rect().height :
         bges=zges()[0],zges()[1]
         birdofprey=pygame.image.load("Defender/birdofprey.png")
         birdofprey=pygame.transform.rotate(birdofprey,(270-math.atan2(bges[1],bges[0])*180/math.pi))
         birdofpreypos=startpos(birdofprey.get_rect().width,birdofprey.get_rect().height)
      screen.blit(amaterie,amaterierect)
      font = pygame.font.Font("Defender/fm.ttf", 10)
      text = font.render(translate("Energie : ",sprache)+str(energie)+" gW", 100, (255,255,155))
      textpos = (0,0)
      screen.blit(text, textpos)
      text = font.render(translate("Zeit : ",sprache)+str(szeit), 100, (255,255,155))
      textpos = (0,10)
      screen.blit(text, textpos)
      text = font.render("Level : "+str(level), 100, (255,255,155))
      textpos = (0,20)
      screen.blit(text, textpos)
      pygame.gfxdraw.vline(screen,jpos[0],0,800,(255,0,0,125))
      pygame.gfxdraw.hline(screen,0,800,jpos[1],(255,0,0,125))
      if szeit>=hs:
         highscorebroken=True
         screen.blit(highscore,(300,0))
      if energie>=67:
         screen.blit(smileyf,(200,0))
      if energie<=66 and energie>=34:
         screen.blit(smileym,(200,0))
      if energie<=33 and energie>=0:
         screen.blit(smileyt,(200,0))
      if "Deutsch" in sprache:
         if menubuttonmo==False:
            screen.blit(menubuttonde,menubuttonpos)
         if menubuttonmo==True:
            screen.blit(menubuttondemo,menubuttonpos)
      if "Englisch" in sprache or "Franzoesisch" in sprache:
         if menubuttonmo==False:
            screen.blit(menubuttonen,menubuttonpos)
         if menubuttonmo==True:
            screen.blit(menubuttonenmo,menubuttonpos)
      if "Ruemaenisch" in sprache:
         if menubuttonmo==False:
            screen.blit(menubuttonru,menubuttonpos)
         if menubuttonmo==True:
            screen.blit(menubuttonrumo,menubuttonpos)
      pygame.display.update()
      pygame.display.flip()
      isi=100
      clock.tick(isi)
      datei=open("Defender/screenshot.txt","w")
      datei.write(str(screenshot))
      datei.close()
   try:
      pygame.mixer.quit()
   except:
      True
   if highscorebroken==True:
      datei=open("Defender/highscore.txt","w")
      datei.write(str(szeit))
      datei.close()
   clock = pygame.time.Clock()
   pygame.image.save(screen,"Defender/screen.png")
   close=pygame.image.load("Defender/close.png")
   close2=pygame.image.load("Defender/close2.png")
   for x in range(39):
      for y in range(39):
         si=close.get_at((x,y))
         se=si[3]-(si[3]/2)
         close2.set_at((x,y),(si[0],si[1],si[2],se))
   for x in range(39):
      for y in range(39):
         si=close.get_at((x,y))
         se=si[3]-(si[3]/4)
         close.set_at((x,y),(si[0],si[1],si[2],se))
   returnl=pygame.image.load("Defender/return.png")
   return2l=pygame.image.load("Defender/return2.png") 
   for x in range(39):
      for y in range(39):
         si=returnl.get_at((x,y))
         se=si[3]-(si[3]/2)
         return2l.set_at((x,y),(si[0],si[1],si[2],se))
   for x in range(39):
      for y in range(39):
         si=returnl.get_at((x,y))
         se=si[3]-(si[3]/4)
         returnl.set_at((x,y),(si[0],si[1],si[2],se))
   configs=pygame.image.load("Defender/configs.png")
   configs2=pygame.image.load("Defender/configs2.png")
   for x in range(39):
      for y in range(39):
         si=configs.get_at((x,y))
         se=si[3]-(si[3]/2)
         configs2.set_at((x,y),(si[0],si[1],si[2],se))
   for x in range(39):
      for y in range(39):
         si=configs.get_at((x,y))
         se=si[3]-(si[3]/4)
         configs.set_at((x,y),(si[0],si[1],si[2],se))
   markfont = pygame.font.Font('Defender/fm.ttf', 12)
   closemark = markfont.render(translate("Beenden",sprache), True, (0,255,0))
   returnmark = markfont.render(translate("Wiederholen",sprache), True, (0,255,0))
   menumark = markfont.render(translate("Menue",sprache), True, (0,255,0))
   cmr=closemark.get_rect()
   rmr=returnmark.get_rect()
   mmr=menumark.get_rect()
   cmr.center=(400,525)
   rmr.center=(320,525)
   mmr.center=(480,525)
   gofi = pygame.font.Font('Defender/fm.ttf', 100)
   gs = gofi.render('Game', True, (0,255,0))
   osi = gofi.render('Over', True,(0,255,0))
   gr = gs.get_rect()
   orr = osi.get_rect()
   gr.center = (400, 365)
   orr.center = (400, 425)
   for x in range(orr.width):
      for y in range(orr.height):
         si=osi.get_at((x,y))
         se=si[3]-(si[3]/2)
         osi.set_at((x,y),(si[0],si[1],si[2],se))
   for x in range(gr.width):
      for y in range(gr.height):
         si=gs.get_at((x,y))
         se=si[3]-(si[3]/2)
         gs.set_at((x,y),(si[0],si[1],si[2],se))
   screen.blit(gs, gr)
   screen.blit(osi, orr)
   pygame.mouse.set_visible(1)
   pygame.display.set_caption("Defender:Game Over","Defender:Game Over")
   go=True
   while d==True and go==True:
      screen.blit(pygame.image.load("Defender/screen.png"),(0,0))
      screen.blit(close,(380,475))
      screen.blit(returnl,(300,475))
      screen.blit(configs,(460,475))
      screen.blit(zeichen,zeichenpos)
      for e in pygame.event.get():
          if e.type==pygame.QUIT:
             go=False
             pygame.quit()
          if e.type == pygame.KEYDOWN:
             if e.key == K_ESCAPE:
                go=False
                pygame.quit()
             if e.key == K_RETURN:
                main()
          drauf=False
          pressed=pygame.mouse.get_pressed()
          if zeichenrect.collidepoint(pos)==True :
             if oncircle((750,10),pos,10)==True:
                zeichen=zeichen1
                drauf=True
                if pressed[0]==True or pressed[1]==True or pressed[2]==True:
                   d=True
                   pygame.quit()
             if oncircle((770,10),pos,10)==True:
                zeichen=zeichen2
                drauf=True
                if pressed[0]==True or pressed[1]==True or pressed[2]==True:
                   fullscreen(False,(800,800))
             if oncircle((790,10),pos,10)==True:
                zeichen=zeichen3
                drauf=True
                if pressed[0]==True or pressed[1]==True or pressed[2]==True:
                   fullscreen(True,(800,800))
          if drauf==False:
             zeichen=zeichen0
      pos = pygame.mouse.get_pos()[0]+12,pygame.mouse.get_pos()[1]+12
      pressed=pygame.mouse.get_pressed()
      if oncircle((400,495),pos,20)==True:
         close=close2
         if pressed[0]==True or pressed[1]==True or pressed[2]==True:
            go=False
            pygame.quit()
         pygame.draw.rect(screen,(75,75,75),cmr)
         screen.blit(closemark,cmr)
      else:
         #pygame.draw.rect(screen,(255,255,255),cmr)
         close=pygame.image.load("Defender/close.png")
      if oncircle((480,495),pos,20)==True:
         configs=configs2
         if pressed[0]==True or pressed[1]==True or pressed[2]==True:
            main(True)
         pygame.draw.rect(screen,(75,75,75),mmr)
         screen.blit(menumark,mmr)
      else:
         #pygame.draw.rect(screen,(255,255,255),mmr)
         configs=pygame.image.load("Defender/configs.png")
      if oncircle((320,495),pos,20)==True:
         returnl=return2l
         if pressed[0]==True or pressed[1]==True or pressed[2]==True:
            main(False)
         pygame.draw.rect(screen,(75,75,75),rmr)
         screen.blit(returnmark,rmr)
      else:
         #pygame.draw.rect(screen,(255,255,255),rmr)
         returnl=pygame.image.load("Defender/return.png")
      pygame.display.update()
      clock.tick(100)
def error():
   screen.fill((0,0,0))
   screen.blit(gs, gr)
   screen.blit(os, orr)
   screen.blit(gsi, gri)
   screen.blit(osi, orri)
   screen.blit(exitlogo,(380,380))
   pygame.display.update()
   clock.tick(100)
   for e in pygame.event.get():
         if e.type==pygame.QUIT:
            e=False
            pygame.quit()
         if e.type == pygame.KEYDOWN:
            if e.key == K_ESCAPE:
               e=False
               pygame.quit()
            if e.key == K_RETURN:
               try:
                  main(False)
                  e=False
               except:
                  e=True
#try:
main(True)
"""except:
   try:
      clock = pygame.time.Clock()
      screen=pygame.display.set_mode((800,800))
      pygame.display.set_icon(pygame.image.load("Defender/defendericon5.png"))
      pygame.display.set_caption("Defender:Error/Fehler/Erroare/Erreur","Defender:Error/Fehler/Erroare/Erreur")
      exitlogo=pygame.image.load("Defender/error.png")
      gof = pygame.font.Font('Defender/fm.ttf', 12)
      gs = gof.render('Internal Error:Press Esc to exit', True, (255,0,0))
      os = gof.render('Interner Fehler:Druecken sie Esc zum Beenden', True,(255,0,0))
      gr = gs.get_rect()
      orr = os.get_rect()
      gr.center = (400, 425)
      orr.center = (400, 435)
      gsi = gof.render('Erreur :Appuyez sur Echap pour quitter', True, (255,0,0))
      osi = gof.render('Eroare interna: Apasati Esc pentru a iesi', True,(255,0,0))
      gri = gsi.get_rect()
      orri = osi.get_rect()
      gri.center = (400, 445)
      orri.center = (400, 455)
      pygame.mouse.set_visible(0)
      e=True
      while e==True:
         error()
   except:
      pygame.quit()"""
