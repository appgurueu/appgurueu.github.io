import java.util.*;
import java.io.*;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import javax.sound.sampled.*;


class Cube {
    protected String group;
    protected double bumpy;
    protected double sticky;
    protected double[] vector;
    protected double weight;
    protected double[] pos;
    protected double[] size;
    protected double connectedsticky;
    protected double density;
    public Cube(String group,double bumpy,double sticky,double[] vector,double weight, double[] pos, double[] size,double connectedsticky, double density) {
    }
}

class Sound {
    protected String path;
    protected AudioFormat format;
    protected AudioInputStream sound2;
    protected SourceDataLine ausgabe;
    protected File soundfile;
    protected DataLine.Info data;
    protected byte buffer[]=new byte[1000000];
    protected boolean isplaying=false;
    protected boolean stop=false;
    protected int speed=5;
    protected int count=0;

    public Sound(String path2) {
        try {
        path=path2;
        soundfile=new File(path);
        sound2 = AudioSystem.getAudioInputStream(soundfile);
        format=sound2.getFormat();
        data=new DataLine.Info(SourceDataLine.class,format);
        ausgabe=(SourceDataLine) AudioSystem.getLine(data);
        buffer=new byte[1000000];
        } catch (Exception bug) {
            System.out.println(bug);
        }
    }
    public void reload(String path2) {
        try {
        path=path2;
        soundfile=new File(path);
        sound2 = AudioSystem.getAudioInputStream(soundfile);
        format=sound2.getFormat();
        data=new DataLine.Info(SourceDataLine.class,format);
        ausgabe=(SourceDataLine) AudioSystem.getLine(data);
        buffer=new byte[1000000];
        } catch (Exception bug) {
            System.out.println(bug);
        }
    }
    public void setspeed(int speedn) {
        speed=speedn;
    }
    public boolean isPlaying() {
        return isplaying;
    }
    public void stop() {
        stop=true;
    }
    public void play() {
        try {
        ausgabe.open(format);
        ausgabe.start();
        isplaying=true;
        stop=false;
        count=0;
        while ((count=sound2.read(buffer,0,buffer.length)) != -1) {
            if (stop==true) {
                break;
            }
            /*try {
            Thread.sleep(speed);
            } catch(InterruptedException bug) {
            Thread.currentThread().interrupt();
            System.out.println(bug);
            }*/
            if (count > 0) {
                ausgabe.write(buffer, 0, count);
            } 
        }
        count=0;
        ausgabe.drain();
        ausgabe.close();
        isplaying=false;
        } catch (LineUnavailableException bug) {
            System.out.println(bug);
        } catch (IOException bug) {
            System.out.println(bug);
        }
    }
}

class Recorder {
    protected String type;
    protected AudioFileFormat.Type soundtype;
    protected AudioFormat format;
    protected TargetDataLine eingabe;
    protected File writefile;
    protected DataLine.Info data;
    protected boolean isrecording=false;
    protected boolean stop=false;

    public Recorder(String pathn,String typen) {
        try {
        writefile=new File(pathn);
        format=new AudioFormat(44100.0F,16,1,true,false);
        data=new DataLine.Info(TargetDataLine.class,format);
        if (typen=="AIFC") {
            soundtype = AudioFileFormat.Type.AIFC;
        }
        if (typen=="AIFF") {
            soundtype = AudioFileFormat.Type.AIFF;
        }
        if (typen=="WAVE") {
            soundtype = AudioFileFormat.Type.WAVE;
        }
        if (typen=="AU") {
            soundtype = AudioFileFormat.Type.AU;
        }
        if (typen=="SND") {
            soundtype = AudioFileFormat.Type.SND;
        }
        eingabe=(TargetDataLine) AudioSystem.getLine(data);
        } catch (Exception bug) {
            System.out.println(bug);
        }
    }
    public void format(float rate, int bits,int channels, boolean signed, boolean endian) {
        format=new AudioFormat(rate,bits,channels,signed,endian);
    }
    public void settype(String typen) {
        if (typen=="AIFC") {
            soundtype = AudioFileFormat.Type.AIFC;
        }
        if (typen=="AIFF") {
            soundtype = AudioFileFormat.Type.AIFF;
        }
        if (typen=="WAVE") {
            soundtype = AudioFileFormat.Type.WAVE;
        }
        if (typen=="AU") {
            soundtype = AudioFileFormat.Type.AU;
        }
        if (typen=="SND") {
            soundtype = AudioFileFormat.Type.SND;
        }
    }
    public void setname(String pathn) {
        writefile = new File(pathn);
    }
    public boolean isRecording() {
        return isrecording;
    }
    public void stop() {
        try {
        isrecording=false;
        eingabe.stop();
        eingabe.close();
        } catch (Exception bug){
            System.out.println(bug);
        }
    }
    public void record() {
        try {
            isrecording=true;
            eingabe.open(format);
            eingabe.start();
            AudioSystem.write(new AudioInputStream(eingabe),soundtype,writefile);
        } catch (Exception bug){
            System.out.println(bug);
        }
    }
}

class Point {
    protected int x;
    protected int y;
    protected int z;
    public Point(int xn, int yn, int zn) {
        x=xn;
        y=yn;
        z=zn;
    }
}
class Vertex {
    protected Point p1;
    protected Point p2;
    protected Point p3;
    public Vertex(Point p1n ,Point p2n , Point p3n) {
        p1=p1n;
        p2=p2n;
        p3=p3n;
    }
}
class myAutils{
    public myAutils() {
    }
    public Integer[][] append(Integer[][] array,Integer[] element) {
         Integer[][] rarray = new Integer[array.length+1][];
         for (int iter7=0;iter7 < array.length;iter7=iter7+1) {
             rarray[iter7]=array[iter7];     
         }
         rarray[array.length]=element;
         
         return rarray;
         
    }
    public Integer[][] remove(Integer[][] array,int iterator) {
         try {
         Integer[][] rarray = new Integer[array.length-1][];
         
         int rarray_iter=-1;
         for (int iter8=0;iter8 < array.length;iter8=iter8+1) {
             rarray_iter=rarray_iter+1;
             if (iter8==iterator) {
                 rarray_iter=rarray_iter-1;
             }
             else {
                 System.out.println(Integer.toString(rarray_iter)+" : "+Integer.toString(rarray.length)+"_________"+Integer.toString(iter8)+" : "+Integer.toString(array.length));
                 rarray[rarray_iter]=array[iter8];
             }     
         }
         rarray_iter=0;
         return rarray;
         }
         catch (java.lang.IndexOutOfBoundsException bug) {
         System.out.println(bug);
         System.out.println(Arrays.toString(array));
         return array;
         }
    }
}


class Max {
     public double x;
     public double y;
     public double speed;
     public double[] velo;
     public Max(xn,yn,speedn) {
          x=xn;
          y=yn;
          speed=speedn;
     }
     public double[] kreispunkt_berechnen(double winkel, double mittelpunktx, double mittelpunkty, double radius) { //Unterfunktion
          x=mittelpunktx+Math.cos(Math.toRadians(winkel))*radius;
          y=mittelpunkty-Math.sin(Math.toRadians(winkel))*radius;
          return new double[] {x,y};
     }
     public double[] rotate(double angle, double xn, double yn, double mittelpunktx, double mittelpunkty) { //Rotieren eines Punktes
          b=Math.abs(mittelpunktx-xn);
          h=Math.abs(mittelpunkty-yn);
          r=Math.sqrt((b*b)+(h*h));
          ermittelter_winkel=Math.toDegrees(Math.atan2(b,h));
          System.out.println(ermittelter_winkel);
          return kreispunkt_berechnen((ermittelter_winkel+angle+90), mittelpunktx, mittelpunkty, r);  
     }
     public double abstand(double xi, double yi) {
          return Math.sqrt(Math.abs((x-xi)*(x-xi))+Math.abs((y-yi)*(y-yi)));
     }
     public boolean test(Minnie minnie,Luecke luecke,Buhnenreihe buhnen) {
          double max_d_to_l=abstand(buhnen.x,luecke.y);
          double min_d_to_l=minnie.abstand(buhnen.x,luecke.y);
          if (min_d_to_l/min.speed > max_d_to_l/max.speed) {
              return true;
          }
          else {
              return false;
          }
     }
          
     public void align(Luecke luecke,Buhnenreihe buhnen) {
          double[] newvelo=rotate(Math.atan2(luecke.y,buhnen.x),0.0d,speed,0,0);
          velo=newvelo;
     }
     public void run() {
          x=x+velo[0];
          y=y+velo[1];
     }
}

class Minnie {
     public double x;
     public double y;
     public double speed;
     public double[] velo;
     public Minnie(xn,yn,speedn) {
          x=xn;
          y=yn;
          speed=speedn;
     }
     public double[] kreispunkt_berechnen(double winkel, double mittelpunktx, double mittelpunkty, double radius) { //Unterfunktion
          x=mittelpunktx+Math.cos(Math.toRadians(winkel))*radius;
          y=mittelpunkty-Math.sin(Math.toRadians(winkel))*radius;
          return new double[] {x,y};
     }
     public double[] rotate(double angle, double xn, double yn, double mittelpunktx, double mittelpunkty) { //Rotieren eines Punktes
          b=Math.abs(mittelpunktx-xn);
          h=Math.abs(mittelpunkty-yn);
          r=Math.sqrt((b*b)+(h*h));
          ermittelter_winkel=Math.toDegrees(Math.atan2(b,h));
          System.out.println(ermittelter_winkel);
          return kreispunkt_berechnen((ermittelter_winkel+angle+90), mittelpunktx, mittelpunkty, r);  
     }
     public double abstand(double xi, double yi) {
          return Math.sqrt(Math.abs((x-xi)*(x-xi))+Math.abs((y-yi)*(y-yi)));
     }
     public boolean test(Minnie minnie,Luecke luecke,Buhnenreihe buhnen) {
          double max_d_to_l=abstand(buhnen.x,luecke.y);
          double min_d_to_l=minnie.abstand(buhnen.x,luecke.y);
          if (min_d_to_l/min.speed > max_d_to_l/max.speed) {
              return true;
          }
          else {
              return false;
          }
     }
          
     public void align(Luecke luecke,Buhnenreihe buhnen) {
          double[] newvelo=rotate(Math.atan2(luecke.y,buhnen.x),0.0d,speed,0,0);
          velo=newvelo;
     }
     public void run() {
          x=x+velo[0];
          y=y+velo[1];
     }
}

class Luecke {
     public boolean maxi;
     public double y;
     public Luecke(boolean maxin, double yn) {
         maxi=maxin;
         y=yn;
     }
}
class Buhnenreihe {
     public Luecke[] luecken;
     public double x;
     public Buhnenreihe(Luecke[] lueckenn, double x) {
         luecken=lueckenn;
         x=xn;
     }
}
     
public class Buhnenrennen {
     public String path = "path";
     public Scanner input = new Scanner(System.in);
     public String line;
     public myAutils autils = new myAutils();
     public Buhnenreihe[] buhnen;
     public double[] maxpos;
     public double[] minniepos;
     public double[] maxvelo;
     public double[] minvelo;
     public double[] kreispunkt_berechnen(double winkel, double mittelpunktx, double mittelpunkty, double radius) { //Unterfunktion
          x=mittelpunktx+Math.cos(Math.toRadians(winkel))*radius;
          y=mittelpunkty-Math.sin(Math.toRadians(winkel))*radius;
          return new double[] {x,y};
     }
     public double[] rotate(double angle, double xn, double yn, double mittelpunktx, double mittelpunkty) { //Rotieren eines Punktes
          b=Math.abs(mittelpunktx-xn);
          h=Math.abs(mittelpunkty-yn);
          r=Math.sqrt((b*b)+(h*h));
          ermittelter_winkel=Math.toDegrees(Math.atan2(b,h));
          System.out.println(ermittelter_winkel);
          return kreispunkt_berechnen((ermittelter_winkel+angle+90), mittelpunktx, mittelpunkty, r);
     }
     public double entfernung(double[] p1, double[] p2) {
          double xdif=p1[0]-p2[0];
          double ydif=p1[1]-p2[1];
          return Math.sqrt((xdif*xdif)+(ydif*ydif));
     }
     public void loop(Buhnenreihe[] buhnen, int buhnenreihe) { //Kürzesten Weg ermitteln
          for (Luecke luecke:buhnen[buhnenreihe].luecken) {
               R
          }
     }
     public Buhnenrennen() {
          System.out.println("Pfad eingeben : ");
          path = input.nextLine();
          /*Recorder i=new Recorder("aufnahme.wav","WAVE");
          i.record();
          try {
          Thread.sleep(10000);
          } catch(InterruptedException bug) {
          Thread.currentThread().interrupt();
          System.out.println(bug);
          }
          i.stop();*/
          try{
             BufferedReader leser = new BufferedReader(new File(path));
             int line=0;
             while (leser.readLine() != null) {
                 line++;
                 line=leser.readLine();
                 String[] values=line.split(" ");
                 Double[] coords={Double.parseFloat(values[1]),Double.parseFloat(values[2])};
                 if (line >= 2) {
                     if (values[0]=="X") {
                         maxpos=coords;
                     }
                     if (values[0]=="M") {
                         minniepos=coords;
                     }
                 }
             }       
          } catch(IOException bug){
             System.out.println(bug);
             System.exit(9);
          }
     }
     public boolean possible() {
          
     }
     public static void main(String args[]){
          new Buhnenrennen();
     }
}
