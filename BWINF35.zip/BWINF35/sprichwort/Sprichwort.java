public class Sprichwort {
     public int a; //Zwischenwerte
     public int b;
     public int c;
     public int k;
     public int M;
     public int d;
     public int N;
     public int p;
     public int q;
     public int e;
     public int O; //
     public int J=2016; //Jahreszahl
     public int gregOstern; //Greg Ostern
     public int juliOstern; //Juli Ostern
     public int weihnachten=-7;
     public int unterschied(int Jahr, int Monat) { //Weihnachten berechnen(Unterschied der Kalender)
            int JH=Jahr/100;
            if (Monat <= 2) {
                JH--;
            }
            int a=JH/4;
            int b=JH % 4;
            int TD=3*a+b-2;
            return TD;
     }
     public int gauss_computing(int Jahr, boolean julian) { //Ostern berechnen nach Gauss
            a = Jahr % 19;
            b = Jahr % 4;  
            c = Jahr % 7;  
            k = Jahr/100;
            if (julian==true) {
                M = 15;
                d = ((10 * a) + M) % 30;
                N = 6;
            }
            else {
                p = ((8 * k) + 13) / 25;
                q = k / 4;
                M = (15 + k - p - q) % 30;
                d = ((19 * a) + M) % 30;
                N = (4 + k - q) % 7;
            }
            e = ((2 * b) + (4 * c) + (6 * d) + N) % 7;
            O = (22 + d + e);
            if (O > 56) {
                O=56;
            }
            return O;
     }
     public Sprichwort() { 
            int dif; //Unterschied
            int tbm; //Tage bis Ostern, da die gaussche Osterformel den xten März returnt
            while (true) {
                J=J+1; //Jahr hochzählen
                gregOstern=gauss_computing(J,false); //Ostern berechen
                dif=unterschied(J-1,12);
                if (J % 4 != 0 || J % 100 == 0) { //Schaltjahre !
                    tbm=31+28;
                }
                else {
                    tbm=31+29;
                }
                if (weihnachten+dif==tbm+gregOstern) { //Ist Weihnachten zum gleichen Datum ?
                    System.out.println("Im Jahre "+Integer.toString(J)+" : Das orthodoxe Weihnachtsfest fällt mit dem katholischen Osterfest zusammen");
                    break;
                }
                if (J > 100000000) {
                    System.out.println("Das orthodoxe Weihnachtsfest und das katholische Osterfest werden in den nächsten "+Integer.toString(J-2016)+" Jahren nicht zusammenfallen.");
                    break;
                }
            }
            J=2016;
            while (true) {
                J=J+1; //Hochzählen
                juliOstern=gauss_computing(J,true); //Ostern
                if (J % 4 != 0 || J % 100 == 0) { //Schaltjahre !
                    tbm=31+28;
                }
                else {
                    tbm=31+29;
                }
                if (weihnachten==tbm+juliOstern) { //Ist Weihnachten zum gleichen Datum ?
                    System.out.println("Im Jahre "+Integer.toString(J)+" : Das katholische Weihnachtsfest fällt mit dem orthodoxen Osterfest zusammen");
                    break;
                }
                if (J > 100000000) {
                    System.out.println("Das katholische Weihnachtsfest und das orthodoxe Osterfest werden in den nächsten "+Integer.toString(J-2016) +" Jahren nicht zusammenfallen.");
                    break;
                }
            }
            
     }
     
     
     public static void main(String args[]){
            new Sprichwort();
     }
}
