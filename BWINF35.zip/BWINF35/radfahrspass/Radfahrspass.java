//Ntige Imports
import java.util.*;
import java.io.*;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;


public class Radfahrspass { //Hauptklasse
       public Scanner input = new Scanner(System.in); //Eingabe
       public String value; //Zwischenwert
       public int plusse=0; //Plusse
       public int minusse=0; //Minusse
       public int flatpos=0; //Möglichkeiten
       public int speed=0; //Geschwindigkeit
       public boolean possible=false; //Möglich ?
       public boolean liegengeblieben=false; //Liegengeblieben ?
       public BufferedReader parcours; //Leser
       public BufferedWriter ausgabe; //Ausgabe
       public String path; //Pfad
       public double y; //Zwischenwert
       public int z; //Zwischenwert
       public Radfahrspass() { 
          System.out.println("Pfad eingeben : ");
          path = input.nextLine(); //Eingeben
          try {
          parcours = new BufferedReader(new InputStreamReader(new FileInputStream(path),"UTF-8"),128); //Leser : Pfad,UTF-8 und jeweils 128 byte in Zwischenspeicher lesen
          z = parcours.read(); //Erstes Zeichen lesen
          while (z != -1) {
              value = new String(new char[] {(char)z}); //Zu String konvertieren
              if (value.equals("/")) { //Wenn bergauf
                  speed--; //Verlangsamen
              }
              if (value.equals("\\")) { //Wenn bergab
                  speed++; //Beschleunigen
              }
              if (value.equals("_")) { //Wenn flach
                  flatpos++; //Eine Möglichkeit zur Regulierung mehr
              }
              if (flatpos >= speed) { //Wenn es mehr Möglichkeiten als Geschwindigkeit gibt, dies schließt aus das hier zu viele Minusse verwendet werden
                  y=Math.floor(((flatpos-speed)/2.0d)+0.5d); //Zusätzliche Plusse berechnen
                  plusse=plusse+(int)y; //Zu Plussen addieren
                  speed=speed+(int)y; //Geschwindigkeit erhöhen
                  flatpos=flatpos-(int)y; //Möglichkeiten abziehen
              }
              if (speed < 0) { //Wenn die Geschwindigkeit kleiner als null ist
                  liegengeblieben=true; //Ist der Parcour unmöglich
                  break; //Liegengeblieben.
              }
              if (speed==0) { //Wenn ich liegen bleibe
                  if (flatpos > 0) { //Wenn ich davor hätte beschleunigen können
                      flatpos--; //Eine Möglichkeit weniger
                      plusse++; //Ein Plus mehr
                      speed++; //Und schneller.
                  }
              }
              
              z = parcours.read(); //Zeichen lesen
              if (z==-1) { //Wenn zu Ende
                  break; //Zu Ende
              }
              
          }
          if (speed==0 && liegengeblieben==false) { //Wenn er stehen, nicht liegen geblieben ist
              System.out.println("Stehengeblieben");
              if (flatpos % 2==0) { //Wenn man die Möglichkeiten gerecht aufteilen kann
                  plusse=flatpos/2; //Aufteilen
                  minusse=flatpos/2; //Aufteilen
                  flatpos=0; //Keine Möglichkeiten mehr
                  possible=true; //Möglich
              }
              else {
                  possible=false; //Andernfalls unmöglich
              }
          }
          else if (liegengeblieben==false) { //Wenn man am Ende nicht 0 hatte, aber nicht liegen geblieben ist
              if (flatpos > speed) { //Wenn man mehr Möglichkeiten hat, als man braucht
                  if (speed < 0) { //Wenn man zu langsam ist
                      plusse=Math.abs(speed); //Alles nötige beschleunigen
                      flatpos=flatpos-speed; //Möglichkeiten
                      if (flatpos % 2==0) { //Wenn man den Rest aufteilen kann
                          plusse=plusse+(flatpos/2); //Aufteilen
                          minusse=minusse+(flatpos/2); //Aufteilen
                          flatpos=0; //Keine Möglichkeiten mehr
                          possible=true; //Möglich
                      }
                      else { //Ansonsten unmöglich
                          possible=false;
                      }
                  }
                  else { //Wenn man zu schnell ist 
                      minusse=Math.abs(speed); //Verlangsamen, wo es geht
                      flatpos=flatpos-speed; 
                      if (flatpos % 2==0) { //Wenn man den Rest aufteilen kann
                          plusse=plusse+(flatpos/2); //Aufteilen
                          minusse=minusse+(flatpos/2); //Aufteilen
                          flatpos=0; //Nix übrig
                          possible=true; //Möglich
                      }
                      else {
                          possible=false; //Ansonsten nicht
                      }
                  }
              }
              if (flatpos==speed) { //Wenn man genauso viel zu schnell ist wie man verlangsamen kann...
                  possible=true;
                  minusse=flatpos; //Einfach Minusse !
                  flatpos=0;
                  speed=0;
             }
          }
          parcours.close(); //Datei schliessen
          } catch(IOException bug) {
          System.out.println(bug);
          System.exit(9);
          }
          if (possible==true) { //Ausgabe...
              System.out.println("Dieser Parcours ist bewältigebar");
          }
          else {
              System.out.println("Dieser Parcours ist unmöglich");
          }
          if (possible==true)  {
              speed=0;
              try {
              parcours = new BufferedReader(new InputStreamReader(new FileInputStream(path), "UTF-8"),128); //Einlesen
              } catch(IOException bug) {
              System.out.println(bug);
              System.exit(9);
              }
              try {
              ausgabe = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(path+"loesung.txt"), "UTF-8"),128); //Ausgabe
              z = parcours.read(); //Einlesen
              while (z != -1) {
                   value = new String(new char[] {(char)z}); //Konvertieren
                   if (value.equals("/")) { //Übernehmen
                       speed--;
                       ausgabe.write("/");
                   }
                   if (value.equals("\\")) { //Übernehmen
                       speed++;
                       ausgabe.write("\\");
                   }
                   if (value.equals("_")) { //Hier werden die Plusse und Minusse eingesezt.
                       if (plusse != 0) {
                           plusse--;
                           speed++;
                           ausgabe.write("+");
                       }
                       else {
                           if (minusse != 0) {
                               minusse--;
                               speed--;
                               ausgabe.write("-");
                           }
                       }
                   }
                   if (speed < 0) { //Wenn liegengeblieben
                       break;
                   }
                   z = parcours.read(); //Einlesen
                   if (z==-1) { //Abbrechen wenn zuende
                       break;
                   }
               }
               if (speed==0) { //Wenn am Ende stehen geblieben
                   System.out.println("Das ist nicht zu fassen ! Es hat geklappt !");
                   
               }
               else {
                   System.out.println("Wieso klappt es nicht !");
               }
          parcours.close(); //Schließen
          ausgabe.close();
          } catch(IOException bug) {
              System.out.println(bug);
              System.exit(9);
              }
          }
          
          
       }
       public static void main(String args[]){
            new Radfahrspass(); //Deskriptor aufrufen
       }
}
