//Bibliotheken importieren für Fenster usw.
import javax.swing.JFrame;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.*;
import javax.imageio.ImageIO;
import javax.swing.JPanel;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.Random;
import java.util.Arrays;
import java.awt.EventQueue;
import javax.swing.JFrame;

public class Lightsout extends JFrame implements MouseListener, KeyListener {
     protected BufferedImage ledon; //Bild LED an
     protected BufferedImage ledoff; //Bild LED aus
     protected boolean gameover=false; //Spiel vorbei ?
     protected boolean normal=true; //Klassischer Modus(umliegende LEDs) ?
     protected boolean setup=false; //Konfiguration ?
     Random zufall = new Random(); //Zufall
     protected int score=0; //Züge
     protected int sizex=5; //Größe X
     protected int sizey=5; //Größe Y
     protected int arraylength=sizex*sizey; //Länge des Arrays mit LEDs
     protected int state=0; //Status der LED, der später immer angepasst wird
     protected int dec=0; //Zahl, die später eine Zufallszahl werden wird
     protected Integer[] newelement; //Array "Neues Element", ein Array, das an erster Stelle x-Koordinate der LED, an Zweiter y-Koordinate der LED und an Dritter Status der LED beinhalten wird
     Integer[][] leds = new Integer[arraylength][]; //Array "LEDs" initialisieren mit "arraylength"
     public void reload_lights(Integer[][] leds) { //"LEDs" Array füllen mit LEDs entsprechend Größe X, Größe Y mit zufällig bestimmten Staten, die sich aber bei der Konfiguration noch ändern lassen
         for(int xpos = 0; xpos < sizex; xpos = xpos+1){ //X-Koordinaten entsprechend X-Größe entlanggehen
              for(int ypos = 0; ypos < sizey; ypos = ypos+1){ //Für jede dieser X-Koordinaten noch mal Y-Koordinaten entsprechend Y-Größe entlanggehen
                  zufall = new Random(); //Zufall
                  dec=zufall.nextInt(5); //Zufallszahl
                  if (dec==2) { //Wenn die Zufallszahl zwei ist, soll der Status der LED an sein
                      state=1; //Statusvariable auf an setzen
                  }
                  else { //Ansonsten soll er aus sein
                      state=0; //Statusvariable auf aus setzen
                  }
                  Integer[] newelement = {xpos,ypos+1,state}; //LED-Array mit soeben bestimmter X-Koordinate, Y-Koordinate + 1, weil darüber ja noch Text kommen soll, und der Statusvariable
                  leds[(ypos*sizex)+xpos]=newelement; //Entsprechende Stelle des LED-Arrays mit "Neuem Element" füllen
                  newelement=null; //"Neues Element" freigeben für Ersetzen
              }
          }
          setup=true; //Danach Konfiguration des generierten Levels
     }
     public void mousePressed(MouseEvent m) {
     }
     public void mouseClickedinSetup(MouseEvent m) { //Wenn Maus geklickt
         int mouseposx=(int) (m.getX()); //Maus X-Koordinate
         int mouseposy=(int) (m.getY()); //Maus Y-Koordinate
         if (m.getButton() == m.BUTTON1) { //Wenn "Standard" erste Maus-Taste geklickt
             for (int iter2=0 ; iter2 < leds.length ; iter2=iter2+1) { //Für LED in LEDs
                 if (mouseposx >= (leds[iter2][0]*20) && mouseposx < (leds[iter2][0]*20)+20) { //Wenn LED x auf Maus x
                     if (mouseposy >= (leds[iter2][1]*20) && mouseposy < (leds[iter2][1]*20)+20) { //Wenn LED y auf Maus y
                         score=score+1;
                         if (leds[iter2][2]==0) { //Status der LED ändern
                             leds[iter2][2]=1;
                         }
                         else { //Status der LED ändern
                             leds[iter2][2]=0;
                         }
                     }
                 }
             } 
         }
     }
     public void mouseClickedinGame(MouseEvent m) { //Wenn im Spiel geklickt wird
         int mouseposx=(int) (m.getX()); //Maus X-Koordinate
         int mouseposy=(int) (m.getY()); //Maus Y-Koordinate
         if (m.getButton() == m.BUTTON1) { //Wenn "Standard" erste Maus-Taste geklickt
             for (int iter2=0 ; iter2 < leds.length ; iter2=iter2+1) { //Für LED in LEDs
                 if (mouseposx >= (leds[iter2][0]*20) && mouseposx < (leds[iter2][0]*20)+20) { //Wenn LED x auf Maus x
                     if (mouseposy >= (leds[iter2][1]*20) && mouseposy < (leds[iter2][1]*20)+20) { //Wenn LED y auf Maus y
                         score=score+1; //Mit score sind Züge gemeint, ein Zug mehr
                         if (leds[iter2][2]==0) { //Status dieser LED ändern
                             leds[iter2][2]=1;
                         }
                         else { //Status dieser LED ändern
                             leds[iter2][2]=0;
                         }
                         for (int iter3=0 ; iter3 < leds.length ; iter3=iter3+1) { //Was ist mit den anderen LEDs
                              if (!(iter3==iter2)) { //Alle nur nicht diese
                                  if (normal==true) { //Wenn normaler Modus
                                      if (leds[iter3][0]-1==leds[iter2][0] && leds[iter3][1]==leds[iter2][1]) { //LED links ändern
                                          if (leds[iter3][2]==0) {
                                              leds[iter3][2]=1;
                                          }
                                          else {
                                              leds[iter3][2]=0;
                                          }
                                      }
                                      if (leds[iter3][0]+1==leds[iter2][0] && leds[iter3][1]==leds[iter2][1]) { //LED rechts ändern
                                          if (leds[iter3][2]==0) {
                                              leds[iter3][2]=1;
                                          }
                                          else {
                                              leds[iter3][2]=0;
                                          }
                                      }
                                      if (leds[iter3][1]-1==leds[iter2][1] && leds[iter3][0]==leds[iter2][0]) { //LED oben ändern
                                          if (leds[iter3][2]==0) {
                                              leds[iter3][2]=1;
                                          }
                                          else {
                                              leds[iter3][2]=0;
                                          }
                                      }
                                      if (leds[iter3][1]+1==leds[iter2][1] && leds[iter3][0]==leds[iter2][0]) { //LED unten ändern 
                                          if (leds[iter3][2]==0) {
                                              leds[iter3][2]=1;
                                          }
                                          else {
                                              leds[iter3][2]=0;
                                          }
                                      }
                                  }
                                  if (normal==false) { //Wenn nicht normaler Modus
                                      if (leds[iter3][0]<=leds[iter2][0] && leds[iter3][1]<=leds[iter2][1]) { //Wenn LED im Rechteck liegt, ändern
                                          if (leds[iter3][2]==0) {
                                              leds[iter3][2]=1;
                                          }
                                          else {
                                              leds[iter3][2]=0;
                                          }
                                      }
                                  }
                              }
                         }
                     }
                 }
             }  
         }
         if (m.getButton() == m.BUTTON3) { //Wenn rechte Maustaste gedrückt
             for (int xpos2 = 0; xpos2 < 20; xpos2 = xpos2+1) { //Für Quadrat x 1-20
                 for (int ypos2 = 0; ypos2 < 20; ypos2 = ypos2+1) { //Für Quadrat y 1-20
                      if (mouseposx >= xpos2*20 && mouseposx < (xpos2*20)+20) { //Wenn in Quadrat x
                          if (mouseposy >= (ypos2*20)+20 && mouseposy < (ypos2*20)+40) { //Wenn in Quadrat y
                              sizex=xpos2+1; //Größe ändern
                              sizey=ypos2+1; //Größe ändern
                              arraylength=sizex*sizey; //Länge des Arrays anpassen
                          }
                      }
                 }
             }       
             leds = new Integer[arraylength][]; //LEDs resetten
             reload_lights(leds); //LEDs resetten
             score=0; //Züge resetten
         }
     }
     public void mouseClicked(MouseEvent m) { //Entscheiden, welche Funktion aufgerufen wird, jenachdem ob Setup ist oder nicht
         if (setup==false) {
             mouseClickedinGame(m);
         }
         else {
             mouseClickedinSetup(m);
         }
     }
     public void mouseReleased(MouseEvent m) {
     }
     public void mouseEntered(MouseEvent m) {
     }
     public void mouseExited(MouseEvent m) {
     }
     public void keyTyped(KeyEvent e) {  
     }
     public void keyReleased(KeyEvent e) { //Taste losgelassen
         if (setup==false && gameover==false) { //Wenn kein Setup und Spiel nicht vorbei, also im Spiel
             if (e.getKeyCode() == KeyEvent.VK_SPACE) { //Wenn Leertaste gedrückt
                 if (normal==true) {
                     normal=false;
                 }
                 else {
                     normal=true;
                 } 
                 leds = new Integer[arraylength][]; //LEDs resetten
                 reload_lights(leds); //LEDs resetten
                 score=0; //Züge resetten
             }
         }
         if (setup==true) { //Wenn setup
             if (e.getKeyCode() == KeyEvent.VK_F) { //Wenn f gedrückt ("fertig")
                 setup=false; //Setup beenden
                 score=0; //Züge resetten
             }
         }
         if (gameover==true) { //Wenn Spiel vorbei
             if (e.getKeyCode() == KeyEvent.VK_R) { //Wenn r gedrückt ("nochmal")
                 leds = new Integer[arraylength][]; //LEDs resetten
                 reload_lights(leds); //LEDs resetten
                 gameover=false; //Das Spiel ist nicht mehr vorbei
                 score=0; //Züge resetten
             }
         }
     }
     public void keyPressed(KeyEvent e) { 
     } 
     public Lightsout(){ 
          super("Lightsout");
          reload_lights(leds); //LEDs resetten
          
          try {
          ledoff = ImageIO.read(new File ("grafiken/ledoff.png")); //Bild für LED aus laden
          } catch(IOException bug) { //Wenns nicht klappt, Ersatzbild erstellen (das schöner als das Original ist)
          ledoff=new BufferedImage(20, 20, BufferedImage.TYPE_INT_RGB);
          Graphics2D ledoff_graphics=ledoff.createGraphics();
          ledoff_graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
          ledoff_graphics.setColor(Color.WHITE);
          ledoff_graphics.fillRect(0,0,20,20);
          ledoff_graphics.setColor(Color.GRAY);
          ledoff_graphics.fillOval(1,1,18,18);
          ledoff_graphics.setColor(Color.BLACK);
          ledoff_graphics.drawOval(1,1,18,18);
          ledoff_graphics.setColor(Color.WHITE);
          ledoff_graphics.fillOval(4,4,6,6);
          System.out.println("Ein Bild wurde nicht gefunden. Deshalb wurde jetzt ein Ersatzbild erstellt.");
          System.out.println(bug);
          }
          try {
          ledon = ImageIO.read(new File ("grafiken/ledon.png")); //Bild für LED an laden
          } catch(IOException bug) { //Wenns nicht klappt, Ersatzbild erstellen (das schöner als das Original ist)
          ledon=new BufferedImage(20, 20, BufferedImage.TYPE_INT_RGB);
          Graphics2D ledon_graphics=ledon.createGraphics();
          ledon_graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
          ledon_graphics.setColor(Color.WHITE);
          ledon_graphics.fillRect(0,0,20,20);
          ledon_graphics.setColor(Color.RED);
          ledon_graphics.fillOval(1,1,18,18);
          ledon_graphics.setColor(Color.BLACK);
          ledon_graphics.drawOval(1,1,18,18);
          ledon_graphics.setColor(Color.WHITE);
          ledon_graphics.fillOval(4,4,6,6);
          System.out.println("Ein Bild wurde nicht gefunden. Deshalb wurde jetzt ein Ersatzbild erstellt.");
          System.out.println(bug);
          }

          requestFocus(); //Fokus anfordern, also das das Fenster auf die Eingaben Zugriff hat
          addKeyListener(this); //Tasten abhören
          addMouseListener(this); //Maus abhören
          
          setContentPane(new Zeichenflaeche()); //Zeichenfläche setzen

          setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //Wenn es abgeschossen wird, schliesst sich das Fenster

          setSize(400, 420); //Größe festlegen für 20x20 Spielfeld und 20px Schriftzug oben
          
          setResizable(false); //Größe des Fensters nicht änderbar

          setVisible(true); //Sichtbar machen

          while (true) { //Endlosschleife fürs Updaten des Fensters
              repaint();
              try {
              Thread.sleep(40); //Circa 25 FPS
              } catch(InterruptedException bug) {
              Thread.currentThread().interrupt();
              System.out.println(bug);
              }
          }
     }

      
     class Zeichenflaeche extends JPanel { //Zeichenfläche
        protected Font scorefont = new Font("Sans",Font.BOLD,11); //Standardschriftart
        protected Font gameoverfont = new Font("Sans",Font.BOLD,14); //Schrift, wenn man "gewonnen" hat
        public Zeichenflaeche() {
        }
        public void setup(Graphics g) { //Was wird angezeigt wenn im Setup
           g.setFont(scorefont); //Standardfont
           g.setColor(Color.BLACK); //In Schwarz
           String ticker="Klick=ändern f=fertig"; //Infos
           for (int iter=0 ; iter < leds.length ; iter=iter+1) { //LEDs anzeigen
               if (leds[iter][2]==0) {
                   g.drawImage(ledoff, leds[iter][0]*20, leds[iter][1]*20, this);
               }
               if (leds[iter][2]==1) {
                   g.drawImage(ledon, leds[iter][0]*20, leds[iter][1]*20, this);
               }
           }
           g.drawString(ticker, 3, 15); //Infos anzeigen
        }
        public void inGame(Graphics g) { //Wenn im Spiel
           g.setFont(scorefont); //Standardfont
           g.setColor(Color.BLACK); //In Schwarz
           String scorestring="Züge: "+Integer.toString(score); //String für Züge
           String sizexstring="X: "+Integer.toString(sizex); //String für Größe X
           String sizeystring="Y: "+Integer.toString(sizey); //String für Größe Y
           String ticker=scorestring+" "+sizexstring+" "+sizeystring+" Rechtsklick=Größe "+"Leertaste=Modus"; //Infos
           gameover=true;
           for (int iter4=0 ; iter4 < leds.length ; iter4=iter4+1) { //Wenn mindestens eine LED noch an ist, ist das Spiel nicht vorbei. Ansonsten schon.
               if (leds[iter4][2]==1) {
                   gameover=false;
               }
           }
           for (int iter=0 ; iter < leds.length ; iter=iter+1) { //LEDs anzeigen
               if (leds[iter][2]==0) {
                   g.drawImage(ledoff, leds[iter][0]*20, leds[iter][1]*20, this);
               }
               if (leds[iter][2]==1) {
                   g.drawImage(ledon, leds[iter][0]*20, leds[iter][1]*20, this);
               }
           }
           g.drawString(ticker, 3, 15); //Infos anzeigen
        }
        public void gameOver(Graphics g) { //Wenn das Spiel vorbei ist
           g.setFont(gameoverfont); //Gewonnen-Schriftart
           g.setColor(Color.GREEN); //In Grün
           String wonstring="Du hast mit nur Züge/n gewonnen : "+Integer.toString(score)+" r=nochmal"; //Infos
           g.drawString(wonstring, 3, 15); //Infos anzeigen
        }
        public void paintComponent(Graphics g) { //Jenachdem was gerade ist entsprechende Funktion aufrufen, machts übersichtlicher
           if (setup==true) {
               setup(g);
           }
           else {
               if (gameover==false) {
                   inGame(g);
               }
               if (gameover==true) {
                   gameOver(g);
               }
           }
        }   
     }
     public static void main(String args[]) {
            new Lightsout(); //Alles starten
     }
}
