import javax.swing.JFrame; //Einige Imports damit es das Fenster und die Keyprüfung usw. gibt
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.*;
import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.EventQueue;
import javax.swing.JFrame;
import java.util.*;

public class Rhinozelfant extends JFrame implements KeyListener {
     public BufferedImage rhinozelfant; //Rhinozelfantenbild
     public BufferedImage rhinozelfant_detected; //Eingefärbtes Bild
     public String path = "path"; //Pfad um das Bild zu laden
     public Scanner input = new Scanner(System.in); //Eingabe
     public int color; //Farbe des Pixels
     public int vergleichsfarbe; //Farbe der umliegenden Pixel
     public Integer width; //Breite des Bildes
     public Integer height; //Höhe des Bildes
     public int xscroll=0; //Scroll X
     public int yscroll=0; //Scroll Y
     
     public void keyTyped(KeyEvent e) { //Wird gebraucht von KeyListener, könnte man vermutlich overriden
     }
     public void keyReleased(KeyEvent e) { //Wird gebraucht von KeyListener, könnte man vermutlich overriden
     }
     public void keyPressed(KeyEvent e) { //Wird eine Taste gedrückt
         if (e.getKeyCode() == KeyEvent.VK_LEFT) { //Linke Pfeiltaste
             xscroll=xscroll-100; //100 Pixel nach links scrollen
         }
         if (e.getKeyCode() == KeyEvent.VK_RIGHT) { //Rechte Pfeiltaste
             xscroll=xscroll+100; //100 Pixel nach rechts scrollen
         }
         if (e.getKeyCode() == KeyEvent.VK_UP) { //Obere Pfeiltaste
             yscroll=yscroll-100; //100 Pixel nach oben scrollen
         }
         if (e.getKeyCode() == KeyEvent.VK_DOWN) { //Untere Pfeiltaste
             yscroll=yscroll+100; //100 Pixel nach unten scrollen
         }
     }
     public int get_at(int x,int y) { //Funktion, um nicht jedesmal rhinozelfant.getRGB(x, y) schreiben zu müssen
         return rhinozelfant.getRGB(x, y);
     }
     public boolean check_at(int px, int py, int dir) { //Prüft einen der schematisch dargestellten Fälle
         color=get_at(px,py);
         boolean retvar=false;
         if (dir==1) {
             if (color==get_at(px-1,py) && color==get_at(px,py-1) && color==get_at(px-1,py-1)) {
                 retvar=true;
             }
         }
         if (dir==2) {
             if (color==get_at(px+1,py) && color==get_at(px,py-1) && color==get_at(px+1,py-1)) {
                 retvar=true;
             }
         }
         if (dir==3) {
             if (color==get_at(px+1,py) && color==get_at(px,py+1) && color==get_at(px+1,py+1)) {
                 retvar=true;
             }
         }
         if (dir==4) {
             if (color==get_at(px-1,py) && color==get_at(px,py+1) && color==get_at(px-1,py+1)) {
                 retvar=true;
             }
         }
         return retvar;
     }
     public boolean check_schuppe(int px, int py) { //Prüft ob es eine Schuppe ist indem es die Fälle prüft, allerdings die Fälle nicht prüft, wenn die zu prüfenden Pixel dort lägen, wo es keine Pixel gibt
         boolean dir1=true;
         boolean dir2=true;
         boolean dir3=true;
         boolean dir4=true;
         boolean schuppe=false;
         if (px==0) {
             dir1=false;
             dir4=false;
         }
         if (py==0) {
             dir1=false;
             dir2=false;
         }
         if (px==width-1) {
             dir2=false;
             dir3=false;
         }
         if (py==height-1) {
             dir3=false;
             dir4=false;
         }
         if (dir1==true) {
             if (check_at(px,py,1)==true) {
                    schuppe=true;
             }
         }
         if (dir2==true) {
             if (check_at(px,py,2)==true) {
                 schuppe=true;
             }
         }
         if (dir3==true) {
             if (check_at(px,py,3)==true) {
                 schuppe=true;
             }
         }
         if (dir4==true) {
             if (check_at(px,py,4)==true) {
                 schuppe=true;
             }
         }
         return schuppe;
     }
     public Rhinozelfant() { 
          super("Rhinozelfant");
         
          System.out.println("Pfad eingeben : ");
          path = input.nextLine(); //Pfad eingeben
          
          try {
          rhinozelfant = ImageIO.read(new File (path));
          } catch(IOException bug) { //Falscher Pfad
          System.out.println(bug);
          System.exit(9);
          }
          
          width=rhinozelfant.getWidth(); //Höhe ermitteln
          height=rhinozelfant.getHeight(); //Breite ermitteln
          if (width < 2 || height < 2) { //Ist das Bild kleiner als eine Schuppe
              System.out.println("Was soll das ?");
              System.exit(9);
          }
          rhinozelfant_detected=new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);

          for (int x = 0 ; x < width ; x=x+1) { //Für jede x-Koordinate des Bildes...
                for (int y = 0 ; y < height ; y=y+1) { //Die y-Koordinaten entlanggehen
                    if (check_schuppe(x,y)==true) { //Prüfen, ob es eine Schuppe ist
                        rhinozelfant_detected.setRGB(x,y,Color.WHITE.getRGB()); //Weiß einfärben
                    }
                    else { //Wenn es keine Schuppe ist
                        rhinozelfant_detected.setRGB(x,y,get_at(x,y)); //Gleiche Farbe wie beim Original nehmen
                    }
                }
            }
          try { //Versuchen, das Ergebnis zu speichern
          File ergebnis = new File(path+"gescannt.jpg"); //Pfad+"gescannt.jpg"
          ImageIO.write(rhinozelfant_detected, "jpg", ergebnis); //Speichern als jpg
          } catch(IOException bug) {
          System.out.println(bug); //Wenns mal nicht klappt
          }

          requestFocus();
          setContentPane(new Zeichenflaeche());
          setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
          setSize(width,height); //Größe festlegen
          setResizable(false);
          setVisible(true); 
          addKeyListener(this); //Tasten abhören

          while (true){
              repaint(); //Erneut anzeigen
              try {
              Thread.sleep(250); //Viertel Sekunde warten
              } catch(InterruptedException bug) {
              Thread.currentThread().interrupt();
              System.out.println(bug);
              }
          }
     }
     class Zeichenflaeche extends JPanel{
         public Zeichenflaeche() {
         }      
         public void paintComponent(Graphics g){
             g.drawImage(rhinozelfant_detected,xscroll,yscroll,this); //Geprüftes Bild anzeigen, mit Scroll
         }   
     }
     public static void main(String args[]){
            new Rhinozelfant(); //Ganzes starten
     }
}
