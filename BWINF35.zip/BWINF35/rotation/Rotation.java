//Bibliotheken...
import javax.swing.JFrame;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.*;
import javax.imageio.ImageIO;
import javax.swing.JPanel;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.Random;
import java.util.Arrays;
import java.util.*;
import java.awt.EventQueue;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.awt.geom.AffineTransform;
import java.awt.image.AffineTransformOp;
//Bibliotheken fürs Lesen und Speichern von Dateien importieren
import java.util.*;
import java.io.*;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.FileWriter;

class Stringhelper {
    public Stringhelper() {
    }
    public String getstring(String string,int beginning,int ending) {
         if (string.length() != 0) {
         String newstring="";
         for (int iter=Math.abs(beginning); iter < ending && iter < string.length(); iter=iter+1) {
              newstring=newstring+Character.toString(string.charAt(iter));
         }
         return newstring;
         }
         else {
         return "";
         }
    }
}

class ahelper {
    public ahelper() {
    }
    public Element[] append(Element[] array,Element element) {
         try{
         if (array != null) {
         Element[] rarray = new Element[array.length+1];
         for (int iter=0;iter < array.length;iter++) {
             rarray[iter]=array[iter];     
         }
         rarray[array.length]=element;
         return rarray;
         }
         else {
         return new Element[] {element};
         }
         }
         catch (Exception bug)  {
         return new Element[] {element};
         }
         
    }
    public Element[][] aoappend(Element[][] array,Element[] element) {
         try{
         if (array != null) {
         Element[][] rarray = new Element[array.length+1][];
         for (int iter=0;iter < array.length;iter++) {
             rarray[iter]=array[iter].clone();     
         }
         rarray[array.length]=element.clone();
         return rarray;
         }
         else {
         return new Element[][] {element};
         }
         }
         catch (Exception bug)  {
         return new Element[][] {element};
         }
         
    }
    public Element[][] getaoa(Element[][] array,int beginning,int ending) {
         Element[][] rarray = new Element[ending-beginning][];
         int rc=0;
         for (int iter=beginning;iter < ending && iter < array.length;iter++) {
             rarray[rc]=array[iter];
             rc++;
         }
         return rarray;
    }
    public boolean check(Element[] array1,Element[] array2) {
         boolean retvar=true;
         for (int i=0; i < array1.length; i++) {
              if (array1[i].equals(array2[i])==false) {
                  retvar=false;
              }
         }
         return retvar;
    }
}

class Element {
     public int x;
     public int y;
     public String type;
     public double ermittelter_winkel;
     public double xing;
     public double ying;
     public double b;
     public double h;
     public double r;
     public double[] result;
     public Element(int xn, int yn, String typen) {
          this.x=xn;
          this.y=yn;
          this.type=typen;
     }
     public boolean equals(Element e2) {
          if (this.x==e2.x && this.y==e2.y && this.type.equals(e2.type)) {
              return true;
          }
          else {
              return false;
          }
     }
     public void rotate90(boolean right, double cp) {
          double relx=0;
          double rely=0;
          double rotx=0;
          double roty=0;
          if (right==true) { //clockwise
              relx=x-cp;
              rely=y-cp;
              rotx=(rely*-1)+cp;
              roty=relx+cp;
          }
          if (right==false) {
              relx=x-cp;
              rely=y-cp;
              roty=(relx*-1)+cp;
              rotx=rely+cp;
          }
          this.x=(int)(Math.round(rotx));
          this.y=(int)(Math.round(roty));
     }
}

class Simulator {
     public double x;
     public double y;
     public double ermittelter_winkel;
     public double b;
     public double h;
     public double r;
     public double[] result;
     public Simulator() {
     }
     public void apply_gravity_to_objs(Element[] objs) {
          int maxy=0; //Größter Y-Wert
          for (int iteri=0; iteri < objs.length; iteri++) { //Ermitteln, wie tief sich das am weitesten unten liegende Objekt befindet
               if (maxy < objs[iteri].y) {
                   maxy=objs[iteri].y;
               }
          }
          int miny=maxy;
          for (int itery=maxy; itery >= 0; itery--) { //Mit den am weitesten unten liegenden Elementen beginnen
               for (int typ=0; typ < 10; typ++) { //Stabweise fallen lassen
                    miny=maxy; //Wenn es nicht aufgehalten wird
                    for (int iter=0; iter < objs.length; iter++) { //Für Element in Elemente
                         if (objs[iter].y==itery) { //Wenn es eines der Objekte in der Reihe ist die jetzt aufgerufen wird
                             if (objs[iter].type.equals(Integer.toString(typ))) { //Wenn es zum Stäbchen gehört
                                 for (int iter2=0; iter2 < objs.length; iter2++) { //Alle anderen Elemente durchgehen, liegt nichts darunter
                                      if (iter != iter2) { //Wenn nicht gleiches Objekt
                                          if (objs[iter].x==objs[iter2].x) { //Wenn X-Koordinate gleich
                                              if (objs[iter2].y > objs[iter].y) { //Wenn darunter
                                                  if (objs[iter2].y <= miny) { //Wenn es aufgehalten wird, dann wo
                                                      miny=objs[iter2].y-1; //Wo frühestens
                                                  }
                                              }
                                          }
                                      }
                                 }
                             }    
                        }
                    }
                    for (int iter=0; iter < objs.length; iter++) { //Für Element in Elemente
                         if (objs[iter].y==itery) { //Wenn es eines der Objekte in der Reihe ist die jetzt aufgerufen wird
                             if (objs[iter].type.equals(Integer.toString(typ))) { //Wenn es zum Stäbchen gehört
                                 objs[iter].y=miny; //Alle Elemente des Stabes können nicht weiter fallen !
                             }
                         }
                    }
               }
          }
     }
     public Element[] simulate(Element[] objs, boolean right,double cp) {
          for (Element obj:objs) {
               obj.rotate90(right,cp);
          }
          apply_gravity_to_objs(objs);
          return objs;
     }
     public Element[] apply_gravity(Element[] objs) {
          apply_gravity_to_objs(objs);
          return objs;
     }
     public boolean check(Element[] objs) {
          int maxy=0;
          boolean returnvar=false;
          for (int iter=0; iter < objs.length; iter++) {
               if (maxy < objs[iter].y) {
                   maxy=objs[iter].y;
               }
          }
          for (Element obj:objs) {
               if (obj.y==maxy && obj.type.equals("#")==false) {
                   returnvar=true;
               }
          }
          return returnvar;
     }   
}
public class Rotation extends JFrame {
     public Stringhelper shelper=new Stringhelper();
     public String path = "path"; //Pfad
     public Scanner input = new Scanner(System.in); //Eingabe
     public String line=""; //Linie
     public double cp;
     public double w;
     public double h;
     public Simulator simulator=new Simulator();
     public Element[] base;
     public Element[] testbase;
     public Element[] bestbase;
     public Element[][] periode;
     public String beststring="";
     public String teststring="";
     public String value;
     public int startiter;
     public boolean brake=false;
     public boolean solution=false;
     public boolean nothinghasfallen=false;
     public ahelper autils=new ahelper();
     public String[] easy = {"r","l"};
     public boolean[] easybool = {false,true};
     public int maxiter=-1;
     public String abil="";
     public Element[][] cb;
     public void loop(int iter) {
         for (int l=0; l < 2; l++) {
              //cb=autils.getaoa(periode,0,iter+1);
              periode=autils.getaoa(periode,0,iter+1);
              //testbase=cb.clone(); //Basis zurücksetzen
              if (testbase==null) {
                  testbase=new Element[periode[iter].length];
              }
              if (periode[iter]==null) {
                  System.out.println("Scheiße"+Integer.toString(iter)+Arrays.toString(periode[iter]));
              }
              System.arraycopy(periode[iter], 0, testbase, 0, periode[iter].length);
              System.out.println(Arrays.toString(testbase));
              //cb=null;
              abil=shelper.getstring(abil,0,iter);
              //System.arraycopy(cb,0,periode,0,cb.length);
              simulator.simulate(testbase,easybool[l],cp);

              abil=abil+easy[l];
              /*for (int bc=0; bc < abil.length(); bc++) {
                   value = new String(new char[] {abil.charAt(bc)});
                   if (value.equals("l")) {
                       simulator.simulate(testbase,false,cp);
                   }
                   if (value.equals("r")) {
                       simulator.simulate(testbase,true,cp);
                   }
              }*/

              /*for (int i=0; i < periode.length; i++) {
                   if (autils.check(periode[i],testbase)==true) {
                       brake=true;
                       System.out.println("Periodizität");
                   }
              }*/

              if (simulator.check(testbase)==true) {
                  System.out.println(abil);
                  System.out.println(simulator.check(testbase));
                  brake=true;
                  solution=true;
                  if (iter < maxiter || maxiter==-1) {
                      beststring=abil;
                      System.arraycopy(testbase,0,bestbase,0,testbase.length);
                      maxiter=0;
                      System.out.println("Nach "+Integer.toString(iter+1)+" Zügen ist etwas herausgefallen");
                  }
                  solution=false;
              }
              //System.out.println(abil);
              //periode=autils.aoappend(periode,testbase);
              System.out.println(iter);
              //System.out.println(periode[1]);
              System.out.println(Arrays.toString(periode));
              System.arraycopy(new Element[][] {testbase},0,periode,1,1);
              if (brake==true) {
                  brake=false;
                  //break;
              }
              else if (iter<maxiter || maxiter==-1) {
                  loop(iter+1);
              }
              //System.gc();
         }
     }
     public Rotation() {
          super("Rotation");
          System.out.println("Pfad eingeben : ");
          path = input.nextLine();
          double wi=0.0d;
          try{
             BufferedReader leser = new BufferedReader(new FileReader(path));
             wi=Double.parseDouble(line=leser.readLine());
             int linec=0;
             while (line != null) {
                 line=leser.readLine();
                 try {
                 System.out.println(line);
                 w=line.length(); //Hier scheiterts wenn die Linie Null ist
                 h=h+1.0d;
                 for (int c=0; c < line.length(); c++) {
                      if (Character.toString(line.charAt(c)).equals(" ")==false) {
                          base=autils.append(base,new Element(c,linec,Character.toString(line.charAt(c))));
                      }
                 }
                 linec+=1;
                 }
                 catch (Exception bug) {
                 break;
                 }
             }     
          } catch(IOException bug){
             System.out.println(bug);
             System.exit(9);
          }
          if (cp % 2.0d == 0.0d) {
              cp=wi/2.0d-0.5;
          }
          else {
              cp=wi/2.0d+0.5;
          }
          //testbase=base;
          base=simulator.apply_gravity(base);
          //periode=autils.aoappend(periode,base.clone());
          periode=new Element[100][base.length];
          //System.out.println(Arrays.toString(periode));
          System.arraycopy(new Element[][] {base},0,periode,0,1);
          if (simulator.check(base)==true) {
              System.out.println("Mit 0 Drehungen : Es ist was herausgefallen");
          }
          
          loop(0);
          //System.out.println(simulator.check(bestbase));
          setContentPane(new Zef());
          setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
          setSize(400,400);
          setResizable(false);
          setVisible(true);
          while (true){
            try {
            Thread.sleep(33);
            } catch(InterruptedException bug) {
            Thread.currentThread().interrupt();
            System.out.println(bug);
            }
            repaint();
          }
     }
     class Zef extends JPanel {
             public Zef() {
             }
             public void paintComponent(Graphics g) {
                 for (Element obj:base) {
                      g.drawString(obj.type,obj.x*12,12+obj.y*12);
                 }
             }
          }
     public static void main(String[] args){
          new Rotation();
     }
}
