//Bibliotheken fürs Lesen und Speichern von Dateien importieren
import java.util.*;
import java.io.*;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.FileWriter;


class ahelper {
    public ahelper() {
    }
    public Integer[] append(Integer[] array,Integer element) {
         try{
         if (array != null) {
         Integer[] rarray = new Integer[array.length+1];
         for (int iter=0;iter < array.length;iter++) {
             rarray[iter]=array[iter];     
         }
         rarray[array.length]=element;
         return rarray;
         }
         else {
         return new Integer[] {element};
         }
         }
         catch (Exception bug)  {
         return new Integer[] {element};
         }
         
    }
}

class LVM { //LVM
     public Integer[] faecher=new Integer[10]; //Fächer
     public Integer[] fuellfolge; //Fächer
     public int iter=0;
     public Integer ausgabefach=0; //Ausgabefach
     public LVM() {
     }
     public void entleeren(int fachcount) {
         ausgabefach=ausgabefach+faecher[fachcount-1];
         if (iter==fuellfolge.length) {
             iter=0; //Wieder am Anfang
         }
         faecher[fachcount-1]=fuellfolge[iter];
         iter=iter+1; //Nächstes Element
     }
     public int verpacken() { //Verpacken
         int copied_ausgabefach=ausgabefach; //Ausgabefach kopieren
         ausgabefach=0; //Und zurücksetzen
         return copied_ausgabefach; //Ausgabefach zurückgeben
     }
}

public class Luftballons {
     public Scanner input = new Scanner(System.in); //Eingabe
     public LVM lvm=new LVM(); 
     public LVM testlvm;
     public LVM bestlvm;
     public String teststring;
     public String beststring;
     public ahelper autils;
     public boolean brake=false;
     public void loop(int iters) {
         for (int fc=1; fc < 11; fc++) {
              if (brake==true) {
                  break;
              }
              if (iters==20) {
                  bestlvm=null;
                  beststring="";
                  testlvm=lvm;
                  teststring="";
                  testlvm.verpacken();
                  testlvm=null;
                  teststring="";
                  testlvm=lvm;
                  brake=false;
              }
              
              
              teststring=teststring+" Entleere : "+Integer.toString(fc)+" : "+Integer.toString(testlvm.faecher[fc-1]);
              testlvm.entleeren(fc);
              if (testlvm.ausgabefach==20) {
                  bestlvm=testlvm;
                  beststring=teststring;
                  iters=-1;
                  brake=true;
                  break;
              }
              if (testlvm.ausgabefach > 20) {
                  //System.out.println(testlvm.ausgabefach);
                  if (bestlvm != null) {
                      if (testlvm.ausgabefach < bestlvm.ausgabefach) {
                          bestlvm=testlvm;
                          beststring=teststring;
                      }
                      else {
                          bestlvm=testlvm;
                          beststring=teststring;
                      }
                  }
                  testlvm.verpacken();
                  testlvm=null;
                  teststring="";
                  testlvm=lvm;
                  //continue;
              }
              if (iters==0) {
                  //brake=true;
                  //break;
              }
              else {
                  loop(iters-1);
              }
         }
     }  
     public Luftballons() { 
         ahelper autils=new ahelper();
         System.out.println("Pfad eingeben : ");
         String path=input.nextLine();
         try{
             BufferedReader leser = new BufferedReader(new FileReader(path));
             String line=leser.readLine();
             int linecount=0; 
             while (line != null) {
                 linecount+=1; //Linie zählen
                 if (linecount <= 10) {
                     lvm.faecher[linecount-1]=Integer.parseInt(line);
                 }
                 else {
                     lvm.fuellfolge=autils.append(lvm.fuellfolge, Integer.parseInt(line));
                 }
                 line=leser.readLine();
             }     
          } catch(Exception bug){
             System.out.println(bug);
             System.exit(9);
          }
          while (true) {
              loop(20);
              lvm=bestlvm;
              System.out.println(beststring);
              System.out.println("Es wurden "+Integer.toString(bestlvm.verpacken())+" Luftballons verpackt.");
              lvm.verpacken();
              bestlvm=null;
              beststring="";
              testlvm.verpacken();
              testlvm=null;
              teststring="";
              testlvm=lvm;
              //lvm.verpacken();
              try {
              Thread.sleep(1000);
              } catch(InterruptedException bug) {
              Thread.currentThread().interrupt();
              System.out.println(bug);
              }
          }   
     }
     
     
     public static void main(String args[]){
            new Luftballons();
     }
}




















































/*for (int i1=0; i1 < 10; i1++) {
              kombi[0]=
              for (int i1=0; i1 < 10; i1++) {
                   for (int i1=0; i1 < 10; i1++) {
                        for (int i1=0; i1 < 10; i1++) {
                             for (int i1=0; i1 < 10; i1++) {
                                  for (int i1=0; i1 < 10; i1++) {
                                       for (int i1=0; i1 < 10; i1++) {
                                            for (int i1=0; i1 < 10; i1++) {
                                                 for (int i1=0; i1 < 10; i1++) {
                                                      for (int i1=0; i1 < 10; i1++) {
              
                                                      }
                                                 }
                                            }
                                       }
                                  }
                             }
                        }
                   }
              }
         }*/
